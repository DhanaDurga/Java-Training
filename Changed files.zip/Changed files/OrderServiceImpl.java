package com.eatzos.service.impl;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.validation.Valid;

import com.eatzos.client.AvalaraClient;
import com.eatzos.config.AuthenticationConfig;
import com.eatzos.helper.AvalaraHelper;
import com.eatzos.model.*;
import com.eatzos.repository.*;
import com.eatzos.request.AvalaraCreateTransactionRequest;
import com.eatzos.response.AvalaraCreateTransactionResponse;
import com.eatzos.response.AvalaraTransactionLineItemResponse;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.eatzos.exception.BusinessException;
import com.eatzos.helper.AmazonClient;
import com.eatzos.helper.MultipartImage;
import com.eatzos.helper.NotificationHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.helper.VendorOrderConverterHelper;
import com.eatzos.request.BuyerOrderRequest;
import com.eatzos.request.BuyerOrderSaveRequest;
import com.eatzos.request.GroupedVendorOrderRequest;
import com.eatzos.request.ImagesRequest;
import com.eatzos.request.OrderItemSaveRequest;
import com.eatzos.request.OrderSaveRequest;
import com.eatzos.request.Pagination;
import com.eatzos.request.UpdateOrderStatusRequest;
import com.eatzos.response.BuyerOrderResponse;
import com.eatzos.response.ConnectedOrdersResponse;
import com.eatzos.response.RefundResponse;
import com.eatzos.response.VendorOrderItemResponse;
import com.eatzos.response.VendorOrderResponse;
import com.eatzos.response.VendorOrderResponseList;
import com.eatzos.service.ImageService;
import com.eatzos.service.OrderService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;
import com.shippo.model.Transaction;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import java.util.Comparator;
import com.eatzos.response.VendorOrderResponseMap;
import java.util.LinkedHashMap;
//import com.eatzos.response.VendorOrdersResponseVO;

import static com.eatzos.util.Constant.DEFAULT_LIMIT;
import static com.eatzos.util.Constant.DEFAULT_OFFSET;
import com.eatzos.response.VendorOrdersResponseListVO;

@Service(value = "orderService")
@Slf4j
public class OrderServiceImpl implements OrderService {

	private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

	@Autowired
	private OrdersRepository ordersRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private VendorAddressRepository vendorAddressRepository;

	@Autowired
	private StateRepository stateRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	ShippoTransactionDetailsRepository shippoTransactionDetailsRepository;

	@Autowired
	private VendorScheduleRepository vendorScheduleRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private VendorImageRepository vendorImageRepository;

	@Autowired
	private ImageRepository imageRepository;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private RefundImageRepository refundImageRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private BuyerAddressRepository buyerAddressRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ProductImageRepository productImageRepository;

	@Value("${mail.SellerinitiateRefundOrderEmail.template}")
	private String sellerInitiateRefundOrderEmailTemplate;

	@Value("${mail.AdmininitiateRefundOrderEmail.template}")
	private String adminInitiateRefundOrderEmailTemplate;

	@Value("${mail.BuyerinitiateRefundOrderEmail.template}")
	private String buyerInitiateRefundOrderEmailTemplate;

	@Value("${mail.initiateRefundOrderEmailToBuyer.subject}")
	private String initiateRefundOrderEmailSubjectToBuyer;

	@Value("${mail.initiateRefundOrderEmailToSeller.subject}")
	private String initiateRefundOrderEmailSubjectToSeller;

	@Value("${mail.initiateRefundOrderEmail.subject}")
	private String initiateRefundOrderEmailSubject;
	
	@Value("${seller.order.schedule.time}")
	private Integer orderScheduleTime;

	@Value("${mail.admin.user}")
	private String sendMailtoAdmin;

	@Value("${order.needattention.value}")
	private int needAttentionHours;

	@Value("${mail.BuyerCancelOrderEmail.template}")
	private String buyerCancelOrderEmailTemplate;

	@Value("${mail.BuyerCancelOrderEmail.subject}")
	private String buyerCancelOrderEmailSubject;

	@Value("${mail.SellerCancelOrderEmail.subject}")
	private String sellerCancelOrderTemplateSubject;

	@Value("${mail.SellerCancelOrderEmail.template}")
	private String sellerCancelOrderTemplate;

	@Value("${mail.orderCreationEmail.template}")
	private String createOrderEmailTemplate;

	@Value("${domain.url}")
	private String domain;

	@Value("${buyer.domain.url}")
	private String buyerDomain;

	@Value("${mail.BuyerSuccessfullPaymentOrderTemplate.subject}")
	private String BuyerSuccessfullPaymentOrderSubject;

	@Value("${mail.BuyerSuccessfullPaymentOrderTemplate.template}")
	private String BuyerSuccessfullPaymentOrderTemplate;

	@Value("${mail.sellerSuccessfullPaymentOrderTemplate.template}")
	private String sellerSuccessfullPaymentOrderTemplate;

	@Value("${mail.orderCreationEmail.subject}")
	private String createOrderEmailSubject;

	@Value("${mail.confirmOrderEmail.template}")
	private String confirmOrderEmailTemplate;

	@Value("${mail.confirmOrderEmail.subject}")
	private String confirmOrderEmailSubject;

	@Value("${mail.orderShipment.template}")
	private String confirmOrderShipmentTemplate;

	@Value("${mail.orderShipment.subject}")
	private String confirmOrderShipmentSubject;

	@Value("${mail.header.image}")
	private String mailHeaderImage;

	@Value("${shippo.key}")
	private String shippoKey;
	
	@Value("${eatzos.website.url}")
	private String webSiteUrl;
	
	@Value("${buyer.domain.buyerUserOrderList.url}")
	private String buyerUserOrderList;
	
	@Value("${buyer.support.faq}")
	private String buyerSupportFAQ;
	
	@Value("${buyer.trackOrder.url}")
	private String buyerTrackOrderUrl;
	
	@Value("${seller.manageOrder.url}")
	private String sellerManageOrderUrl;

	@Autowired
	private Configuration config;

	@Autowired
	NotificationHelper notificationHelper;

	@Autowired
	AmazonClient amazonClient;

	@Autowired
	private BuyerRepository buyerRepository;

	@Autowired
	private RefundRepository refundRepository;

	@Autowired
	private ImageService imageService;

	@Value("${s3.label.folder}")
	private String lableFolder;
	
	@Value("${aws.endpointUrl}")
	private String awsendpointUrl;
	
	@Value("${aws.s3.bucket}")
	private String awsbucketName;

	@Autowired
	private DiscountRedemptionRepository discountRedemptionRepository;

	@Autowired
	private DiscountRepository discountRepository;

	@Autowired
	private BuyerPaymentRepository buyerPaymentRepository;

	@Autowired
	private LookupRepository lookupRepository;
	
	@Autowired
	private BuyerPaymentMethodRepository buyerPaymentMethodRepository;
	
	@Autowired
	private AvalaraClient avalaraClient;

	@Autowired
	private AvalaraTxnSummaryRepository avalaraTxnSummaryRepository;

	@Autowired
	private AvalaraTxnLineSummaryRepository avalaraTxnLineSummaryRepository;
	
	@Autowired
	private DeliveryChargeRepository deliveryChargeRepository;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;

	@Override
	public Response save(OrderSaveRequest orders) throws Exception {
		logger.info("OrderServiceImpl save----starts----"+orders);
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(orders.getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (orders.getProductDetails() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_DETAILS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} else {
			User userDetails = userRepository.findByUserId(orders.getUserId());
			if (userDetails == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			Address shippingAddress = addressRepository.findAddressById(orders.getShippingAddressId());
			if (shippingAddress == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SHIPPING_ADDRESS_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			List<Integer> productIds = new ArrayList<Integer>();
			for (OrderItemSaveRequest orderDetail : orders.getProductDetails()) {
				productIds.add(orderDetail.getProductId());
			}
			// Get Unique VendorIds based on list of ProductIds
			List<Integer> vendorIds = productRepository.findVendorIdsByProductIds(productIds);
			if (vendorIds != null) {
				// Iteration for Each VendorIds
				for (Integer vendorId : vendorIds) {
					Vendor vendor = vendorRepository.findByVendorId(vendorId);
					Orders newOrder = prepareOrderDetails(userDetails, shippingAddress);
					newOrder.setVendor(vendor);
					newOrder.setVendorId(vendorId);
					List<OrderItem> itemsList = new ArrayList<OrderItem>();
					Long orderAmount = 0L;
					String deliveryMode = "";
					// String oldProductDelivery="";
					for (OrderItemSaveRequest orderDetail : orders.getProductDetails()) {
						Product product = productRepository.findByProductId(orderDetail.getProductId());
						if (product.getVendor().getVendorId() == vendorId) {
							if (product.getUnitCount() >= orderDetail.getQuantity()) {
								double itemTotalAmount = product.getPrice() * orderDetail.getQuantity();
								orderAmount = orderAmount + (int) itemTotalAmount;
								if (product.getIsDeliverable() == true) {
									deliveryMode = Constant.ORDER_DELIVERY_MODE;
								} else {
									deliveryMode = Constant.ORDER_PICKUP_MODE;
								}
								OrderItem OrderItem = new OrderItem();
								OrderItem.setProduct(product);
								OrderItem.setProductId(product.getProductId());
								OrderItem.setProductName(product.getProductName());
								OrderItem.setProductCode(product.getProductCode());
								OrderItem.setPrice(product.getPrice());
								OrderItem.setQuantity(orderDetail.getQuantity());
								OrderItem.setVendor(vendor);
								OrderItem.setVendorId(vendorId);
								OrderItem.setIsDeliveryEnable(product.getIsDeliverable());
								itemsList.add(OrderItem);
							} else {
								throw new BusinessException(Constant.RESPONSE_FAIL,
										Constant.ORDER_PRODUCT_NOT_AVAILABLE, Constant.RESPONSE_EMPTY_DATA, 1001);
							}
						} else {
							System.out.println("Invalid Vendor>>>>" + vendorId);
							System.out.println("Invalid Product>>>>" + product.getProductId());
						}
					}
					newOrder.setOrderAmount(orderAmount);
					newOrder.setDeliveryMode(deliveryMode);
					newOrder.setAddInstructions(orders.getAddInstruction());
					newOrder.setDeliveryOption(orders.getDeliveryOption());
					if (itemsList.size() > 0) {
						newOrder.setOrderItems(itemsList);
						newOrder.setTrackingNumber(CommonUtils.getRandomNumberString());
						newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
						newOrder = ordersRepository.save(newOrder);
						String scheduleDate = nextDeliverySchedule(newOrder,deliveryMode);
						if (!Strings.isNullOrEmpty(scheduleDate)) {
							newOrder.setExpectedScheduleDate(CommonUtils.stringToTimeStamp(scheduleDate));
							newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
							ordersRepository.save(newOrder);
						}
						System.out.println(scheduleDate);
						saveOrderItems(newOrder);
						// Send order creation email
						User user = userRepository.findByUserId(newOrder.getUser().getUserId());
						if (user != null) {
							// sendOrderCreationMail(user, newOrder);
							// sendSuccessfullPaymentOrderMail(user,newOrder,null);
						}
					} else {
						System.out.println("Item List Empty");
					}
				}
			} else {
				System.out.println("Item List saddsadadsa");
			}
		}
		logger.info("OrderServiceImpl save----ends----"+orders);
		return ResponseHelper.getSuccessResponse(Constant.ORDER_SAVED_SUCCESSFULLY, "", 200, Constant.RESPONSE_SUCCESS);
	}

	private Orders prepareOrderDetails(User userDetails, Address shippingAddress) {
		logger.info("OrderServiceImpl prepareOrderDetails----starts----"+userDetails,shippingAddress);
		Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
		Orders newOrder = new Orders();
		newOrder.setUser(userDetails);
		newOrder.setUserId(userDetails.getUserId());
		newOrder.setShippingLine1(shippingAddress.getLine1());
		newOrder.setShippingLine2(shippingAddress.getLine2());
		newOrder.setShippingCity(shippingAddress.getCity());
		newOrder.setShippingDistrict(shippingAddress.getDistrict());
		newOrder.setShippingStateId(shippingAddress.getStateId());
		newOrder.setShippingCountry(shippingAddress.getCountry());
		String shippingName;
		if (shippingAddress.getName() != null && !shippingAddress.getName().equals("")) {
			shippingName = shippingAddress.getName();
			newOrder.setShippingName(shippingName);
		} else {
			if (userDetails.getLastName() != null && !userDetails.getLastName().isEmpty()) {
				newOrder.setShippingName(userDetails.getFirstName() + " " + userDetails.getLastName());
			} else {
				newOrder.setShippingName(userDetails.getFirstName());
			}
		}

		newOrder.setShippingEmail(userDetails.getEmail());
		newOrder.setShippingMobile(userDetails.getMobileNumber());
		newOrder.setShippingZipcode(shippingAddress.getZipcode());
		newOrder.setCreatedAt(currentTime);
		newOrder.setOrderDate(currentTime);
		newOrder.setDeliveryCode("" + CommonUtils.getRandomNumber());
		newOrder.setOrderNumber("" + CommonUtils.getRandomNumber());
		newOrder.setAddressid(String.valueOf(shippingAddress.getId()));
		newOrder.setOrderStatus(Constant.ORDER_STATUS_CREATED);
		logger.info("OrderServiceImpl prepareOrderDetails----ends----");
		return newOrder;

	}

	public void saveOrderItems(Orders newOrder) {
		logger.info("OrderServiceImpl saveOrderItems----starts----"+newOrder);
		if (newOrder != null && newOrder.getOrderItems() != null) {
			for (OrderItem orderItem : newOrder.getOrderItems()) {
				orderItem.setOrder(newOrder);
				orderItem.setOrderId(newOrder.getOrderId());
				orderItemRepository.save(orderItem);
				updateProductUnitCount(orderItem.getProduct(), orderItem.getQuantity());
			}
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("OrderServiceImpl saveOrderItems----ends----");
	}

	public void updateProductUnitCount(Product product, Integer quantity) {
		logger.info("OrderServiceImpl updateProductUnitCount----starts----" + product, quantity);
		if (!product.getMadeToOrder()) {
			int totalUnitCount = product.getUnitCount();
			int calculatedCount = totalUnitCount - quantity;
			product.setUnitCount(calculatedCount);
			productRepository.save(product);
		}
		logger.info("OrderServiceImpl updateProductUnitCount----ends----");
	}

	public void updateOrAddProductUnitCount(Product product, Integer quantity) {
		logger.info("OrderServiceImpl updateOrAddProductUnitCount----starts----" + product, quantity);
		if (!product.getMadeToOrder()) {
			int totalUnitCount = product.getUnitCount();
			int calculatedCount = totalUnitCount + quantity;
			product.setUnitCount(calculatedCount);
			productRepository.save(product);
		}
		logger.info("OrderServiceImpl updateOrAddProductUnitCount----ends----");
	}

	@Override
	public Response getAll() throws Exception {
		logger.info("OrderServiceImpl getAll----starts----");
		List<Orders> list = new ArrayList<>();
		Iterable<Orders> ordersList = ordersRepository.findAll();
		ordersList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("OrderServiceImpl getAll----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getBuyerOrder(Integer offset, Integer limit) {
		logger.info("OrderServiceImpl getBuyerOrder----starts----");
		User accessUser;
		List<VendorOrderResponse> orderResponse = new ArrayList<>();
		VendorOrderResponseList vendorOrderResponseList = new VendorOrderResponseList();
		BuyerPaymentMethods buyerPaymentMethods = new BuyerPaymentMethods();
		Integer totalCount = 0;
		try {
			accessUser = userService.getUserByAccessToken();
			offset = offset != null ? offset : DEFAULT_OFFSET;
			limit = limit != null ? limit : DEFAULT_LIMIT;
			LinkedList<Orders> ordersList = ordersRepository.getUsers(accessUser.getUserId(), offset, limit);
			totalCount = ordersRepository.getUsersCount(accessUser.getUserId());
			//List<Buyer> buyerList = buyerRepository.findByUserUserId(accessUser.getUserId());
			if (CommonUtils.IsNullOrEmpty(ordersList)) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			for (Orders order : ordersList) {
				if (order.getVendor() != null) {
					List<VendorImage> vendorImageList = vendorImageRepository
							.findByVendorVendorIdAndIsActive(order.getVendor().getVendorId(), true);
					if (!CommonUtils.IsNullOrEmpty(vendorImageList)) {
						for (VendorImage vendorImage : vendorImageList) {
							Images images = imageRepository.findImageByImageIdAndUrlContainingAndStatus(
									vendorImage.getImage().getImageId(), "account", true);
							if (images != null) {
								order.setVendorLogo(images.getUrl());
							}
						}
					}
				}
				
				String transactionId = order.getTransactionId();
				BuyerPayment buyerPayment = buyerPaymentRepository.findByTransactionId(transactionId);
				if (buyerPayment != null) {
					buyerPaymentMethods = buyerPaymentMethodRepository.findByStripeAccountId(buyerPayment.getStripeId());					
				}

				orderResponse.add(VendorOrderConverterHelper.getResponseorderandPaymentFromEntity(order,buyerPaymentMethods));

				for (VendorOrderResponse response : orderResponse) {

					response.setShippo(shippoTransactionDetailsRepository.findByOrderId(response.getId().toString()));
					if (null != response.getOrderItemDetails()) {
						for (VendorOrderItemResponse item : response.getOrderItemDetails()) {
							if (null != item) {
								List<ProductImage> productImageList = productImageRepository.findByProductProductIdAndIsActive(item.getProductId(), true);
								if (null !=productImageList && !productImageList.isEmpty()) {
									response.setProductImageUrl(productImageList.get(0).getImage().getUrl());
								} else {
									response.setProductImageUrl("");
								}
							}
						}
					}
					
					if (null != response.getRefundResponse()) {
						for (RefundResponse refundResponse : response.getRefundResponse()) {
							if (null != refundResponse) {
								if (refundResponse.getRefundReasonId() != null
										&& !refundResponse.getRefundReasonId().isEmpty()) {
									Integer refundReasonId = Integer.valueOf(refundResponse.getRefundReasonId());
									Lookup lookup = lookupRepository.findLookupById(refundReasonId);
									if (lookup != null) {
										Lookup lookupResponse = new Lookup();
										lookupResponse.setId(lookup.getId());
										lookupResponse.setType(lookup.getType());
										lookupResponse.setValue(lookup.getValue());
										refundResponse.setRefundReason(lookupResponse);
									}

									List<RefundImage> refundImageList = refundImageRepository
											.findByRefundRefundIdAndIsActive(refundResponse.getRefundId(), true);
									if (null != refundImageList && !refundImageList.isEmpty()) {
										refundResponse.setRefundImageUrl(refundImageList.get(0).getImage().getUrl());
									} else {
										refundResponse.setRefundImageUrl("");
									}
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			System.out.println("getBuyerOrder======>>" + e);
			e.printStackTrace();
		}
		vendorOrderResponseList = VendorOrderConverterHelper.getResponseFromResponseList(orderResponse, totalCount);
		logger.info("OrderServiceImpl getBuyerOrder----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorOrderResponseList, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getAllVendorOrders(String status, String searchString, Pagination pagination, String fromDate,
			String toDate) throws Exception {
		logger.info("OrderServiceImpl getAllVendorOrders----starts----"+status,searchString,pagination,fromDate,toDate);
		boolean validDate = false;
		Date startDate = null;
		Date endDate = null;
		VendorOrdersResponseListVO vendorOrdersResponseVO = new VendorOrdersResponseListVO();		
		List<VendorOrdersResponseListVO> vendorOrdersResponseListVO = new ArrayList<>();
		VendorOrderResponseMap vendorOrderResponseMap = new VendorOrderResponseMap();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		int offset = 0;
		int limit = Constant.DEFAULT_PAGINATION_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		if (vendor != null) {
			Pageable paging = PageRequest.of(offset, limit);
			if (fromDate != null && toDate != null) {
				validDate = CommonUtils.endDateAfterStartDate1(fromDate, toDate);
				startDate = CommonUtils.convertDate(fromDate + " 00:00:00");
				endDate = CommonUtils.convertDate(toDate + " 23:59:00");
			}
			System.out.println("validDate>>>>" + validDate);
			if (fromDate != null && toDate != null && !validDate) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_FROM_TO_DATE,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			List<Orders> list = new ArrayList<>();
			List<Orders> orderList = null;
			Integer totalCount = 0;
			List<Orders> orderListCount = new ArrayList<>();
			if (searchString != null) {
				if (status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.searchByOrderDt(vendor.getVendorId(), searchString.toLowerCase(),
								startDate, endDate, offset, limit);
						orderListCount = ordersRepository.searchByOrderDtCount(vendor.getVendorId(),
								searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.searchByOrder(vendor.getVendorId(), searchString.toLowerCase(),
								offset, limit);
						orderListCount = ordersRepository.searchByOrderCount(vendor.getVendorId(),
								searchString.toLowerCase());
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
					if (validDate) {
						orderList = ordersRepository.searchByOrderStatusDt(vendor.getVendorId(), status,
								searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusDtCount(vendor.getVendorId(), status,
								searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.searchByOrderStatus(vendor.getVendorId(), status,
								searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(), status,
								searchString.toLowerCase());
					}

				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {

//					List<String> refundStatus = Arrays.asList(new String[] { Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//							Constant.ORDER_STATUS_REFUNDED_APPROVED, Constant.ORDER_STATUS_REFUNDED_COMPLETED });
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(),
								refundStatus, searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(),
								Constant.REFUND_STATUS_COMPLETED, searchString.toLowerCase());
	//							Constant.ORDER_STATUS_REFUNDED_COMPLETED, searchString.toLowerCase());
								
					}

				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			} else {

				if (status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.findByOrderAllStatusDt(vendor.getVendorId(), startDate, endDate,
								offset, limit);
						orderListCount = ordersRepository.findByOrderAllStatusDtCount(vendor.getVendorId(), startDate,
								endDate);

					} else {
						orderList = ordersRepository.findByVendorVendorIdOrderByOrderIdDesc(vendor.getVendorId(),
								paging);
						totalCount = ordersRepository.countByVendorVendorIdOrderByOrderIdDesc(vendor.getVendorId());
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
					if (validDate) {
						orderList = ordersRepository.findByOrderStatusDt(vendor.getVendorId(), status, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.findByOrderStatusDtCount(vendor.getVendorId(), status,
								startDate, endDate);
					} else {
						orderList = ordersRepository.findByVendorVendorIdAndOrderStatusOrderByOrderIdDesc(
								vendor.getVendorId(), status, paging);
						totalCount = ordersRepository
								.countByVendorVendorIdAndOrderStatusOrderByOrderIdDesc(vendor.getVendorId(), status);
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {
//					List<String> refundStatus = Arrays.asList(new String[] { Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//							Constant.ORDER_STATUS_REFUNDED_APPROVED, Constant.ORDER_STATUS_REFUNDED_COMPLETED });
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, startDate,
								endDate);
					} else {
						orderList = ordersRepository.findByVendorVendorIdAndRefundStatusInOrderByOrderIdDesc(
								vendor.getVendorId(), refundStatus, paging);
						totalCount = ordersRepository.countByVendorVendorIdAndRefundStatusInOrderByOrderIdDesc(
								vendor.getVendorId(), refundStatus);
					}
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}
			if (!CommonUtils.IsNullOrEmpty(orderList)) {
				for (Orders order : orderList) {
					State state = stateRepository.findStateById(order.getShippingStateId());
					if (state != null) {
						order.setShippingState(state.getName());
					}
					//List<OrderItem> itemList = orderItemRepository.findByOrderOrderId(order.getOrderId());
					order.setOrderItems(order.getOrderItems());
                    setVendorAddress(order.getVendor());
					list.add(order);

//					ShippoTransactionDetails shippo = shippoTransactionDetailsRepository
//							.findByOrderId(order.getOrderId().toString());

				}
			}
			if (!CommonUtils.IsNullOrEmpty(orderListCount)) {
				totalCount = orderListCount.size();
			}

			VendorOrderResponseList convertedOrder = VendorOrderConverterHelper.getResponseListFromEntityList(list,
					totalCount);

			Map<Integer, Orders> ordersMap = list.stream().collect(Collectors.toMap(Orders::getOrderId, Function.identity()));

			for (VendorOrderResponse response : convertedOrder.getOrderResponse()) {
				String cardNumber = null;
				Orders orders = ordersMap.get(response.getId());
				String transactionId = orders.getTransactionId();
				BuyerPayment buyerPayment = buyerPaymentRepository.findByTransactionId(transactionId);
				if (buyerPayment != null) {
					BuyerPaymentMethods buyerPaymentMethods = buyerPaymentMethodRepository.findByStripeAccountId(buyerPayment.getStripeId());
					if (buyerPaymentMethods != null) {
						cardNumber = buyerPaymentMethods.getCardNumber();
					}
				}

				response.setShippo(shippoTransactionDetailsRepository.findByOrderId(response.getId().toString()));
				response.setCardNumber(cardNumber);
				
				if (orders.getDeliveryMode() != null) {
					if ("Pick-Up".equalsIgnoreCase(orders.getDeliveryMode())) {
						response.setInstruction(orders.getInstruction());
						response.setLocationName(orders.getLocationName());
						response.setPickupLine1(orders.getPickupLine1());
						response.setPickupLine2(orders.getPickupLine2());
						response.setPickupCity(orders.getPickupCity());
						response.setPickupDistrict(orders.getPickupDistrict());
						response.setPickupState(orders.getPickupState());
						response.setPickupStateCode(orders.getPickupStateCode());
						response.setPickupZipcode(orders.getPickupZipcode());
						response.setPickupCountry(orders.getPickupCountry());
					}
					// Total delivery charge amount calculated
					if ("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
						if (orders.getDeliveryCharge() != null) {
							int deliveryChargeId = orders.getDeliveryCharge().getDeliveryChargeId();
							if (deliveryChargeId != 0) {
								DeliveryCharge deliveryOrders = deliveryChargeRepository
										.findByDeliveryChargeId(deliveryChargeId);
								if (deliveryOrders != null) {
									Double totalDeliveryCharge = deliveryOrders.getDeliveryChargeAmt();
									response.setTotalDeliveryCharge(totalDeliveryCharge);
								}
							}
						}
					}
				}

				if(null!= response && null != response.getOrderItemDetails()) {

				for (VendorOrderItemResponse item : response.getOrderItemDetails()) {
					if (null != item) {
						List<ProductImage> productImageList = new ArrayList<ProductImage>();
						productImageList = productImageRepository.findByProductProductIdAndIsActive(item.getProductId(), true);
						if(null !=productImageList && !productImageList.isEmpty()) {
						response.setProductImageUrl(productImageList.get(0).getImage().getUrl());
						}else {
							response.setProductImageUrl("");
						}
					}
				}

				}
				
				if(Constant.ORDER_STATUS_DELIVERED.equalsIgnoreCase(orders.getOrderStatus())) {
					if(!CommonUtils.IsNullOrEmpty(orders.getRefund())) {
						setRefundDetailsList(orders,response);
					}
				}
			}

			if(convertedOrder.getOrderResponse()!= null) {
			Map<String, List<VendorOrderResponse>> vendorResponseMap = new LinkedHashMap<String, List<VendorOrderResponse>>(
					convertedOrder.getOrderResponse().size());
			vendorResponseMap = convertedOrder.getOrderResponse().stream()
					//.sorted(Comparator.comparing(VendorOrderResponse::getId).reversed())
					.collect(Collectors.groupingBy(VendorOrderResponse::getVendorName));

			vendorOrderResponseMap.setVendorResponseMap(vendorResponseMap);
			//vendorOrderResponseMap.setTotalCount(totalCount);
			}
			// VendorOrderConverterHelper.getResponseListFromEntity(list);
			if (vendorOrderResponseMap != null && !vendorOrderResponseMap.getVendorResponseMap().isEmpty()) {
				for (Map.Entry<String, List<VendorOrderResponse>> entry : vendorOrderResponseMap.getVendorResponseMap()
						.entrySet()) {					
					vendorOrdersResponseVO.setSellerName(entry.getKey());
					vendorOrdersResponseVO.setVendorOrdersResponse(entry.getValue());					
				}
				vendorOrdersResponseVO.setTotalCount(totalCount);				
				vendorOrdersResponseListVO.add(vendorOrdersResponseVO);
			}			
			logger.info("OrderServiceImpl getAllVendorOrders----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorOrdersResponseListVO, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
	}

    private void setVendorAddress(Vendor vendor) {
        logger.info("OrderServiceImpl setVendorAddress----starts----"+vendor);
        VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndType(vendor.getVendorId(),Constant.PRIMARY);
        if (vendorAddress != null) {
            vendor.setVendorAddress(vendorAddress.getAddress());
        }
        logger.info("OrderServiceImpl setVendorAddress----ends----");
    }

	@Override
	public Response findById(Integer id) throws Exception {
		logger.info("OrderServiceImpl findById----starts----"+id);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		Orders orders = ordersRepository.findOrdersByOrderId(id);
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.UOM_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		//AUTHORIZED PERSON TO ACCESS ORDER VALIDATION.
		User user = userRepository.findByUserId(orders.getUser().getUserId());
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}		
		if(user.getEmail() != null && !StringUtils.isEmpty(user.getEmail()) && !user.getEmail().equals(currentUserName)){
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCESS_DENIED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		String cardNumber = null;
		String transactionId = orders.getTransactionId();
		BuyerPayment buyerPayment = buyerPaymentRepository.findByTransactionId(transactionId);
		if (buyerPayment != null) {
			BuyerPaymentMethods buyerPaymentMethods = buyerPaymentMethodRepository.findByStripeAccountId(buyerPayment.getStripeId());
			if (buyerPaymentMethods != null) {
				cardNumber = buyerPaymentMethods.getCardNumber();
			}
		}
		setVendorAddress(orders.getVendor());
		VendorOrderResponse vendorOrderResponse = VendorOrderConverterHelper.getResponseFromEntity(orders);
		if ("Pick-Up".equalsIgnoreCase(orders.getDeliveryMode())) {
			setPickupAddressOnVendorResponse(orders, vendorOrderResponse);
		}
		
		vendorOrderResponse.setShippo(shippoTransactionDetailsRepository.findByOrderId(vendorOrderResponse.getId().toString()));
		vendorOrderResponse.setCardNumber(cardNumber);
		setInstructionNameAndLocation(orders, vendorOrderResponse);
		if (null != vendorOrderResponse.getOrderItemDetails()) {
			for (VendorOrderItemResponse item : vendorOrderResponse.getOrderItemDetails()) {
				if (null != item) {
					List<ProductImage> productImageList = productImageRepository.findByProductProductIdAndIsActive(item.getProductId(), true);
					if (null !=productImageList && !productImageList.isEmpty()) {
						vendorOrderResponse.setProductImageUrl(productImageList.get(0).getImage().getUrl());
					} else {
						vendorOrderResponse.setProductImageUrl("");
					}
				}
			}
		}

		if(Constant.ORDER_STATUS_DELIVERED.equalsIgnoreCase(orders.getOrderStatus())) {
			if(!CommonUtils.IsNullOrEmpty(orders.getRefund())) {
				setRefundDetailsList(orders,vendorOrderResponse);
			}
		}
		
		if("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
			setConnectedDeliveryOrders(orders, vendorOrderResponse);
		}
		logger.info("OrderServiceImpl findById----ends----"+id);
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				vendorOrderResponse, 200, Constant.RESPONSE_SUCCESS);
	}

	private void setConnectedDeliveryOrders(Orders orders, VendorOrderResponse vendorOrderResponse) {
		if (orders.getDeliveryCharge() != null) {
			int deliveryChargeId = orders.getDeliveryCharge().getDeliveryChargeId();
			List<Orders> deliveryOrders = ordersRepository
					.findByDeliveryChargeDeliveryChargeIdAndOrderIdNot(deliveryChargeId, orders.getOrderId());
			List<ConnectedOrdersResponse> connectedOrdersList = new ArrayList<>();
			String cardNumber = null;
			if (deliveryOrders != null && deliveryOrders.size() > 0) {
				for (Orders order : deliveryOrders) {
					setVendorAddress(order.getVendor());
					ConnectedOrdersResponse connectedOrder = VendorOrderConverterHelper
							.getConnectedOrdersResponseFromEntity(order);
					// Product image fetch
					List<ProductImage> productImageList = productImageRepository
							.findByProductProductIdAndIsActive(connectedOrder.getProductid(), true);
					if (null != productImageList && !productImageList.isEmpty()) {
						connectedOrder.setProductImageUrl(productImageList.get(0).getImage().getUrl());
					} else {
						connectedOrder.setProductImageUrl("");
					}

					BuyerPayment buyerPayment = buyerPaymentRepository
							.findByTransactionId(order.getTransactionId().toString());
					if (buyerPayment != null) {
						BuyerPaymentMethods buyerPaymentMethods = buyerPaymentMethodRepository
								.findByStripeAccountId(buyerPayment.getStripeId());
						if (buyerPaymentMethods != null) {
							cardNumber = buyerPaymentMethods.getCardNumber();
							connectedOrder.setCardNumber(cardNumber);
						}
					}
					connectedOrdersList.add(connectedOrder);

				}
			}
			vendorOrderResponse.setTotalDeliveryCharge(orders != null && orders.getDeliveryCharge() != null
					&& orders.getDeliveryCharge().getDeliveryChargeAmt() != null
							? orders.getDeliveryCharge().getDeliveryChargeAmt()
							: 0.0);
			vendorOrderResponse.setConnectedOrders(connectedOrdersList);
		}
	}

	private void setRefundDetailsList(Orders orders, VendorOrderResponse vendorOrderResponse) {
		List<RefundResponse> refundList=new ArrayList<RefundResponse>();
		for(Refund refunds : orders.getRefund()) {
			if(null!=refunds) {
			RefundResponse refundDetails = new RefundResponse();
			Lookup lookupResponse = new Lookup();
			refundDetails.setRefundId(refunds.getRefundId());
			refundDetails.setOrderId(refunds.getOrderId());
			refundDetails.setRefundStatus(CommonUtils.setRefundStatusCustomized(refunds.getStatus()));			
			refundDetails.setRejectionReason(refunds.getRejectionReason());
			refundDetails.setRefundAmount(refunds.getRefundAmount());
			refundDetails.setCreatedAt(refunds.getCreatedAt());
			refundDetails.setUpdatedAt(refunds.getUpdatedAt());
			refundDetails.setBuyerEmail(refunds.getBuyerEmail());
			refundDetails.setOrderNumber(orders.getOrderNumber());
			refundDetails.setComments(refunds.getComments());
			refundDetails.setRefundReasonId(refunds.getRefundReason());
			refundDetails.setStatus(refunds.getStatus());
				if (refunds.getRefundReason() != null && !refunds.getRefundReason().isEmpty()) {
					Integer refundReasonId = Integer.valueOf(refunds.getRefundReason());
					Lookup lookup = lookupRepository.findLookupById(refundReasonId);
					if (lookup != null) {
						lookupResponse.setId(lookup.getId());
						lookupResponse.setType(lookup.getType());
						lookupResponse.setValue(lookup.getValue());
						refundDetails.setRefundReason(lookupResponse);
					}
				}			
			List<RefundImage> refundImageList = refundImageRepository.findByRefundRefundIdAndIsActive(refunds.getRefundId(), true);
				if (null !=refundImageList && !refundImageList.isEmpty()) {
					refundDetails.setRefundImageUrl(refundImageList.get(0).getImage().getUrl());
				} else {
					refundDetails.setRefundImageUrl("");
				}
			refundList.add(refundDetails);
		}
			vendorOrderResponse.setRefundResponse(refundList);
		}
		
	}

	private void setPickupAddressOnVendorResponse(Orders orders, VendorOrderResponse vendorOrderResponse) {
		vendorOrderResponse.setPickupLine1(orders.getPickupLine1());
		vendorOrderResponse.setPickupLine2(orders.getPickupLine2());
		vendorOrderResponse.setPickupCity(orders.getPickupCity());
		vendorOrderResponse.setPickupDistrict(orders.getPickupDistrict());
		vendorOrderResponse.setPickupState(orders.getPickupState());
		vendorOrderResponse.setPickupStateCode(orders.getPickupStateCode());
		vendorOrderResponse.setPickupZipcode(orders.getPickupZipcode());
		vendorOrderResponse.setPickupCountry(orders.getPickupCountry());
	}

	private void setInstructionNameAndLocation(Orders orders, VendorOrderResponse vendorOrderResponse) {
		if (orders.getDeliveryMode() != null) {
			if ("Pick-Up".equalsIgnoreCase(orders.getDeliveryMode())) {
				vendorOrderResponse.setInstruction(orders.getInstruction());
				vendorOrderResponse.setLocationName(orders.getLocationName());
			}
		}
	}

	@Override
	public Response updateStatus(Integer id, String orderStatus) {
		logger.info("OrderServiceImpl updateStatus----starts----"+id,orderStatus);
		if (StringUtils.isEmpty(id)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(orderStatus)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		int count = ordersRepository.updateStatus(orderStatus, id, CommonUtils.GetCurrentTimeStamp());
		if (count == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("OrderServiceImpl updateStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);

	}

	@Override
	public Response getAllByOrderStatus(String orderStatus) throws Exception {
		logger.info("OrderServiceImpl getAllByOrderStatus----starts----"+orderStatus);
		List<Orders> orderList = new ArrayList<>();
		orderList = ordersRepository.findByOrderStatus(orderStatus);
		if (CommonUtils.IsNullOrEmpty(orderList)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("OrderServiceImpl getAllByOrderStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, orderList, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response updateOrderStatus(@Valid UpdateOrderStatusRequest updateOrderStatus) throws Exception {
		logger.info("OrderServiceImpl updateOrderStatus----starts----"+updateOrderStatus);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		ArrayList<Integer> errorList = new ArrayList<>();
		ArrayList<Integer> successList = new ArrayList<>();
		Map<String, ArrayList<Integer>> map = new HashMap<>();

		if (StringUtils.isEmpty(updateOrderStatus.getOrderId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(updateOrderStatus.getStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		for (int orderId : updateOrderStatus.getOrderId()) {
			String orderStatus = updateOrderStatus.getStatus();
			if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
					|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
					|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
					|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
					|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
				Orders orders = ordersRepository.findByOrderId(orderId);
				if (existingVendor.getVendorId().equals(orders.getVendor().getVendorId())) {
					int count = ordersRepository.updateStatus(updateOrderStatus.getStatus(), orderId,
							CommonUtils.GetCurrentTimeStamp());
					if (count == 0) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					successList.add(orderId);
				} else {
					errorList.add(orderId);
				}
//				if(orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)) {
//					ShippoTransactionDetails ShippoTransactionDetail =shippoTransactionDetailsRepository.findByOrderId(String.valueOf(orderId));
//					if(null!=ShippoTransactionDetail) {
//						ShippoTransactionDetail.setOrderId(null);
//						shippoTransactionDetailsRepository.save(ShippoTransactionDetail);
//					}
//				}

			} else {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_INVALID_STATUS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}
		map.put("errorList", errorList);
		map.put("successList", successList);
		logger.info("OrderServiceImpl updateOrderStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, map, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response orderStatusUpdate(@Valid UpdateOrderStatusRequest updateOrderStatus) throws Exception {
		logger.info("OrderServiceImpl orderStatusUpdate----starts----"+updateOrderStatus);
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		ShippoTransactionDetails shippoTransactionDetails = null;

		if (StringUtils.isEmpty(updateOrderStatus.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(updateOrderStatus.getStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		String orderStatus = updateOrderStatus.getStatus();
		if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)) {
			Orders orders = ordersRepository.findByOrderId(updateOrderStatus.getId());
			if (existingVendor.getVendorId().equals(orders.getVendor().getVendorId())) {
				if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)) {
					ordersRepository.updateStatus(updateOrderStatus.getStatus(), updateOrderStatus.getId(),
							CommonUtils.GetCurrentTimeStamp());

					// Send Conform Email

					User user = userRepository.findByUserId(orders.getUser().getUserId());
					if (user != null) {
						sendOrderConformationMail(user, orders);
					}
				} else if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)) {
					if (updateOrderStatus.getDeliveryCode() != null) {
						Orders oldOrder = ordersRepository.findByOrderIdAndDeliveryCode(updateOrderStatus.getId(),
								updateOrderStatus.getDeliveryCode());
						if (oldOrder != null) {
							ordersRepository.updateStatus(updateOrderStatus.getStatus(), updateOrderStatus.getId(),
									CommonUtils.GetCurrentTimeStamp(), CommonUtils.GetCurrentTimeStamp());
						} else {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_DELIVERY_CODE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}

					} else {
						ordersRepository.updateStatus(updateOrderStatus.getStatus(), updateOrderStatus.getId(),
								CommonUtils.GetCurrentTimeStamp());
					}
					
					//update delivery status on delivery_charge table
					if("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
						if (orders.getDeliveryCharge() != null) {
							int deliveryChargeId = orders.getDeliveryCharge().getDeliveryChargeId();
							DeliveryCharge deliveryCharge=deliveryChargeRepository.findByDeliveryChargeId(deliveryChargeId);
							deliveryCharge.setIsDelivered(true);
							deliveryCharge.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
							deliveryChargeRepository.save(deliveryCharge);
						}
					}
				} else if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
					User user = userRepository.findByUserId(orders.getUser().getUserId());
					orders.setOrderStatus(updateOrderStatus.getStatus());
					orders.setShippingUrl(updateOrderStatus.getShippingUrl());
					// orders.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					orders.setTrackingNumber(updateOrderStatus.getTrackingNumber());
					if (updateOrderStatus.getExpectedDeliveryDate() != null) {
						orders.setExpectedScheduleDate(CommonUtils.stringToTimestampConversion(
								CommonUtils.convertStringToTimestamp(updateOrderStatus.getExpectedDeliveryDate())));
					}
					orders.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					if (Strings.isNullOrEmpty(orders.getShippingUrl())) {
						orders.setShippingUrl(buyerDomain);
					}
					ordersRepository.save(orders);
					shippoTransactionDetails = createTransaction(updateOrderStatus.getShipoTransId(),
							updateOrderStatus.getId());
					sendOrderShipmentMail(user, orders);
				} else {
					ordersRepository.updateStatus(updateOrderStatus.getStatus(), updateOrderStatus.getId(),
							CommonUtils.GetCurrentTimeStamp());
				}

			} else {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("OrderServiceImpl orderStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ORDER_UPDATED, shippoTransactionDetails, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getCountByStatus(String orderStatus) throws Exception {
		logger.info("OrderServiceImpl getCountByStatus----starts----"+orderStatus);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		Map<String, Integer> map = new HashMap<>();
		int count = 0;
		if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_NEEDATTENTION)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)
				|| orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {
			if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)) {
				count = ordersRepository.countByVendorVendorId(existingVendor.getVendorId());
			} else if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_NEEDATTENTION)) {
				count = ordersRepository.countByVendorVendorIdAndOrderStatus(existingVendor.getVendorId(),
						Constant.ORDER_STATUS_INPROGRESS);
			} else if (orderStatus.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {

//				List<String> refundStatus = Arrays.asList(new String[] { Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//						Constant.ORDER_STATUS_REFUNDED_APPROVED, Constant.ORDER_STATUS_REFUNDED_COMPLETED });
				List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
						Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED});
				count = ordersRepository.countByVendorVendorIdAndOrderStatusIn(existingVendor.getVendorId(),
						refundStatus);
			} else {
				count = ordersRepository.countByVendorVendorIdAndOrderStatus(existingVendor.getVendorId(), orderStatus);
			}
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		map.put("count", count);
		logger.info("OrderServiceImpl getCountByStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, map, 200, Constant.RESPONSE_SUCCESS);

	}

	@Override
	public Response cancelOrder(@Valid UpdateOrderStatusRequest updateOrderStatus) throws Exception {
		logger.info("OrderServiceImpl cancelOrder----starts----"+updateOrderStatus);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (StringUtils.isEmpty(updateOrderStatus.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(updateOrderStatus.getCancelReason())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Orders orders = ordersRepository.findByOrderId(updateOrderStatus.getId());
		if (existingVendor.getVendorId().equals(orders.getVendor().getVendorId())) {
			int count = ordersRepository.cancelOrder(updateOrderStatus.getCancelReason(), updateOrderStatus.getId(),
					CommonUtils.GetCurrentTimeStamp());
			if (count == 0) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}
			if (!CommonUtils.IsNullOrEmpty(orders.getOrderItems())) {
				for (OrderItem orderItem : orders.getOrderItems()) {
					updateOrAddProductUnitCount(orderItem.getProduct(), orderItem.getQuantity());
				}
			}
			// Send cancel order email
			User user = userRepository.findByUserId(orders.getUser().getUserId());
			if (user != null) {
				sendCancelORRefundOrderMail(user.getEmail(), user.getFirstName(), updateOrderStatus.getCancelReason(),
						buyerCancelOrderEmailSubject, buyerCancelOrderEmailTemplate, orders);
				sendCanceOrderToVendor(orders, updateOrderStatus.getCancelReason());
			}

		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("OrderServiceImpl cancelOrder----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
	}

	@Async("specificTaskExecutor")
	public void sendCanceOrderToVendor(Orders order, String reason) {
		logger.info("OrderServiceImpl sendCanceOrderToVendor----starts----"+order,reason);
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();
		mailMap.put("reason", null != reason ? reason : ""); // Seller Name
		mailMap.put("name",
				order.getVendor().getUser().getFirstName() + " " + order.getVendor().getUser().getLastName()); // Seller
																												// Name
		mailMap.put("orderId", order.getOrderId());
		mailMap.put("buyerName", order.getUser().getFirstName() + " " + order.getUser().getLastName());

		try {
			Template mailTemplate = config.getTemplate(sellerCancelOrderTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", order.getVendor().getUser().getEmail());
			notificationMap.put("subject", sellerCancelOrderTemplateSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				log.info("Mail Sending Failed");
			}

		} catch (IOException | TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendCanceOrderToVendor----ends----");
		// Call Mail Service

	}

	@Async("specificTaskExecutor")
	public void sendCancelORRefundOrderMail(String email, String firstName, String reason, String subject,
			String template, Orders order) {
		logger.info("OrderServiceImpl sendCancelORRefundOrderMail----starts----"+email,firstName,reason,subject,template,order);
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();
		mailMap.put("imgUrl", mailHeaderImage);
		mailMap.put("name", firstName);
		mailMap.put("orderId", order.getOrderId());
		mailMap.put("reason", null != reason ? reason : "");
		// Template mailTemplate = config.getTemplate(template);
		String html;
		try {
			Template mailTemplate = config.getTemplate(template);
			html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);

			// Call Mail Service
			notificationMap.put("userMail", email);
			notificationMap.put("subject", subject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);

			if (!isMailSent) {
				log.info("Unable to send sendCancelORRefundOrderMail Mail");
			}

		} catch (IOException | TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendCancelORRefundOrderMail----ends----");
	}

	@Async("specificTaskExecutor")
	public void sendRefundOrderMail(String reason, String subject, String template, Orders order, String toaddress) {
		logger.info("OrderServiceImpl sendRefundOrderMail----starts----"+reason,subject,template,order,toaddress);
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();
		mailMap.put("imgUrl", mailHeaderImage);
		mailMap.put("sellerName", order.getVendor().getUser().getFirstName());
		mailMap.put("buyerName", order.getUser().getFirstName());
		mailMap.put("orderNo", order.getOrderId());
		List<Orders> orderList = new ArrayList<Orders>();
		orderList.add(order);
		mailMap.put("buyerOrder", orderList);
		mailMap.put("orderItem", order.getOrderItems());
		mailMap.put("dateOfRefundRequest", LocalDateTime.now().format(Constant.MAIL_DATE_FORMATTER));

		mailMap.put("reason", null != reason ? reason : "");
		// Template mailTemplate = config.getTemplate(template);
		String html;
		try {
			Template mailTemplate = config.getTemplate(template);
			html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);

			// Call Mail Service
			notificationMap.put("userMail", toaddress);
			notificationMap.put("subject", subject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);

			if (!isMailSent) {
				log.info("Unable to send sendCancelORRefundOrderMail Mail");
			}

		} catch (IOException | TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendRefundOrderMail----ends----");
	}

	@Async("specificTaskExecutor")
	public void sendOrderConformationMail(User user, Orders order) {
		logger.info("OrderServiceImpl sendOrderConformationMail----starts----"+user,order);
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("imgUrl", mailHeaderImage);
			mailMap.put("name", user.getFirstName());
			mailMap.put("orderNumber", order.getOrderNumber());
			Template mailTemplate = config.getTemplate(confirmOrderEmailTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", user.getEmail());
			notificationMap.put("subject", confirmOrderEmailSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendOrderConformationMail----ends----");
	}

	@Async("specificTaskExecutor")
	public void sendOrderShipmentMail(User user, Orders order) {
		logger.info("OrderServiceImpl sendOrderShipmentMail----starts----"+user,order);
		Address shippingAddress = null;
		String stateName = null;
		//BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserId(user.getUserId());
		//BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserIdAndDefalt(user.getUserId(),"Y");
		BuyerAddress buyerAddress = buyerAddressRepository.findByAddressId(Integer.parseInt(order.getAddressid()));
		if (buyerAddress != null) {
			shippingAddress = buyerAddress.getAddress();
		}
		if (shippingAddress == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SHIPPING_ADDRESS_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (shippingAddress.getStateId() != null) {
			State state = stateRepository.findStateById(shippingAddress.getStateId());
			if (state != null) {
				stateName = state.getName();
			}
		}
		try {
			List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
			List<Product> orderItemList = null;
			Double totalAmount = 0.0;
			Double totalOrderAmount = 0.0;
			// for(Orders order : orderList) {
			BuyerOrderResponse orderMail = new BuyerOrderResponse();
			orderItemList = new ArrayList<>();
			if (!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
				for (OrderItem orderItem : order.getOrderItems()) {
					if (orderItem != null) {
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						product.setQuantity(orderItem.getQuantity());
						Double productTotalAmount = 0.0;
						productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
						totalAmount = totalAmount + orderItem.getPrice();
						product.setTotalAmount(productTotalAmount);
						product.setProductTotalAmount(productTotalAmount);
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						orderItemList.add(product);
					}
				}
				orderMail.setDeliveryMode(order.getDeliveryMode());
				orderMail.setOrderNumber(order.getOrderNumber());
				orderMail.setOrderAmount(order.getOrderAmount());
				orderMail.setShippingCost(order.getShippingCost());
				orderMail.setDiscount(order.getDiscountAmount());
				orderMail.setTotalTax(order.getTotalTax());
				orderMail.setTotalAmountWithShipping(order.getOrderAmount() + order.getShippingCost() + order.getTotalTax() - order.getDiscountAmount());
				totalOrderAmount = totalOrderAmount + orderMail.getTotalAmountWithShipping();
				if (order.getExpectedScheduleDate() != null && !order.getDeliveryMode().equals("Shipping")) {
					// orderMail.setDeliveryTime(CommonUtils.extractTimeDelivery(order.getExpectedScheduleDate().toString()));
					orderMail.setDeliveryTime(CommonUtils.convertTimeStamptoStringFormat(CommonUtils.convertStringToTimestamp(order.getScheduleDateTime())));
				}
				orderMail.setTotalOrderAmount(totalOrderAmount);
				orderMail.setTrackingNumber(order.getDeliveryCode());
				orderMail.setDeliveryCode(order.getDeliveryMode());
				orderMail.setVendorName(order.getVendor().getName());
				orderMail.setOrderPlacedOn(
						CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
				orderMail.setProductList(orderItemList);
			}
			buyerOrder.add(orderMail);
			// }
			/*
			 * if(!CommonUtils.IsNullOrEmpty(buyerOrder)) { return buyerOrder; }
			 */
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("buyerOrder", buyerOrder);
//			mailMap.put("trackingUrl", order.getShippingUrl());
			mailMap.put("trackingUrl", webSiteUrl.concat(buyerTrackOrderUrl+order.getOrderId()));
			mailMap.put("ExpectedDeliveryDate", CommonUtils.convertTimeStamptoStringFormat(order.getExpectedScheduleDate()));
			// mailMap.put("name", user.getFirstName()+" "+user.getLastName());
			mailMap.put("name", user.getFirstName() + " " + user.getLastName());
			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("vendorName",
					order.getVendor().getUser().getFirstName() + " " + order.getVendor().getUser().getLastName());
			mailMap.put("city", shippingAddress.getCity());
			mailMap.put("totalOrderAmount", totalOrderAmount);
			mailMap.put("state", stateName);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("orderCount", buyerOrder.size());
			mailMap.put("loginurl", buyerDomain);
			mailMap.put("shippingName", order.getShippingName());
			Template mailTemplate = config.getTemplate(confirmOrderShipmentTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			//notificationMap.put("userMail", "vinayagam@strinkit.com");
			 notificationMap.put("userMail", user.getEmail());
			notificationMap.put("subject", confirmOrderShipmentSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendOrderShipmentMail----ends----");
	}

	@Async("specificTaskExecutor")
	public void sendOrderCreationMail(User user, Orders order, Address shippingAddress, String stateName) {
		logger.info("OrderServiceImpl sendOrderCreationMail----starts----"+user,order,shippingAddress,stateName);
		try {

			List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
			List<Product> orderItemList = null;
			Double totalAmount = 0.0;
			BuyerOrderResponse orderMail = new BuyerOrderResponse();
			orderItemList = new ArrayList<>();
			if (!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
				for (OrderItem orderItem : order.getOrderItems()) {
					if (orderItem != null) {
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						totalAmount = totalAmount + orderItem.getPrice();
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						orderItemList.add(product);
					}
				}
				orderMail.setOrderNumber(order.getOrderNumber());
				orderMail.setOrderAmount(order.getOrderAmount());
				orderMail.setTrackingNumber(order.getDeliveryCode());
				orderMail.setOrderPlacedOn(
						CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
				orderMail.setProductList(orderItemList);
			}
			buyerOrder.add(orderMail);
			/*
			 * if(!CommonUtils.IsNullOrEmpty(buyerOrder)) { return buyerOrder; }
			 */
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("buyerOrder", buyerOrder);
			mailMap.put("name",
					order.getVendor().getUser().getFirstName() + " " + order.getVendor().getUser().getLastName());
			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("city", shippingAddress.getCity());
			mailMap.put("state", stateName);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("loginurl", domain);
			Template mailTemplate = config.getTemplate(createOrderEmailTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", order.getVendor().getUser().getEmail());
			// notificationMap.put("userMail", "vinayagam@strinkit.com");
			notificationMap.put("subject", createOrderEmailSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				log.info("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info(CommonUtils.getStracktraceTostring(e));
			System.out.println(e.getMessage());
		}
		logger.info("OrderServiceImpl sendOrderCreationMail----ends----");
	}

	@Async("specificTaskExecutor")
	public void sendSuccessfullPaymentOrderMail(User user, List<Orders> orderList, Address shippingAddress,
			String stateName, Discount discount) {
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMail----starts----" + user, orderList, shippingAddress,
				stateName);
		try {
			Map<String, List<BuyerOrderResponse>> mailPreparationMap = new HashMap<>();
			Map<Integer, List<Orders>> orderMap = new HashMap<>();

			for (Orders orders : orderList) {
				Vendor vendor = orders.getVendor();
				Integer vendorId = vendor.getVendorId();

				// Check if the vendorId already exists in the map
				if (orderMap.containsKey(vendorId)) {
					// If the vendorId already exists, add the orders to the existing list
					List<Orders> ordersList = orderMap.get(vendorId);
					ordersList.add(orders);
				} else {
					// If the vendorId doesn't exist, create a new list and add the orders to it
					List<Orders> ordersList = new ArrayList<>();
					ordersList.add(orders);
					orderMap.put(vendorId, ordersList);
				}
			}

			List<Product> orderItemList = null;
			Double totalAmount = 0.0;
			Double totalOrderAmount = 0.0;
			Integer preparationTime = 0;
			Integer orderId = 0;
			String vendorName = "";

			for (Map.Entry<Integer, List<Orders>> entry : orderMap.entrySet()) {
				Integer vendorId = entry.getKey();
				List<Orders> ordersList = entry.getValue();				
				List<BuyerOrderResponse> buyerOrder = new ArrayList<>();

				for (Orders order : ordersList) {
					orderId = order.getOrderId();
					vendorName = order.getVendor().getName();					
					BuyerOrderResponse orderMail = new BuyerOrderResponse();
					Address VendorshippingAddress = new Address();
					orderItemList = new ArrayList<>();
					if (!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
						for (OrderItem orderItem : order.getOrderItems()) {
							if (orderItem != null) {
								Product product = new Product();
								product.setProductName(orderItem.getProductName());
								product.setPrice(orderItem.getPrice());
								product.setDeliveryMode(orderItem.getDeliveryMode());

								if (orderItem.getExpectedScheduleDay() != null) {
									String[] arr = orderItem.getExpectedScheduleDay().split(" ");
									String dateTime = null;
									if (arr.length > 1) {
										dateTime = CommonUtils.dayToDate(arr[0]) + " " + arr[1] + " " + arr[2] + " - "
												+ arr[4] + " " + arr[5];
									} else if (arr.length == 1) {
										orderItem.setExpectedScheduleDay(orderItem.getExpectedScheduleDay().substring(1,
												orderItem.getExpectedScheduleDay().length() - 1));
										dateTime = CommonUtils.dayToDate(orderItem.getExpectedScheduleDay());
									}

									product.setDeliveryTime(dateTime);
								}
								product.setQuantity(orderItem.getQuantity());
								Double productTotalAmount = 0.0;
								productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
								totalAmount = totalAmount + orderItem.getPrice();
								product.setTotalAmount(productTotalAmount);
								product.setProductTotalAmount(productTotalAmount);
								product.setProductDescription(orderItem.getProduct().getProductDescription());
								product.setTax(orderItem.getTax());
								if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
									product.setProductDescription("Good");
								}
								List<ProductImage> productImageList = new ArrayList<>();
								productImageList = productImageRepository.findByProductProductIdAndIsActive(orderItem.getProduct().getProductId(), true);
								product = CommonUtils.productImageURLForMailTemplate(product, productImageList);
								orderItemList.add(product);
							}
						}
						orderMail.setDeliveryMode(order.getDeliveryMode());
						orderMail.setOrderNumber(order.getOrderNumber());
						orderMail.setOrderAmount(order.getOrderAmount());
						orderMail.setShippingCost(order.getShippingCost());
						orderMail.setTotalTax(order.getTotalTax());
						orderMail.setDiscount(order.getDiscountAmount());
						if (discount != null) {
							orderMail.setDiscountName(discount.getName());
						} else {
							orderMail.setDiscountName("");
						}
						orderMail.setTotalAmountWithShipping(order.getOrderAmount() + order.getShippingCost()
								+ order.getTotalTax() - order.getDiscountAmount());
						totalOrderAmount = totalOrderAmount + orderMail.getTotalAmountWithShipping();
//																if (order.getExpectedScheduleDate() != null && order.getDeliveryMode().equals("Shipping")) {
//																	orderMail.setDeliveryTime(order.getScheduleDateTime());
//																}

						if (order.getScheduleDateTime() != null && !order.getDeliveryMode().equals("Shipping")) {
							String[] arr = order.getScheduleDateTime().split(" ");
							if (arr.length == 1) {
								orderMail.setDeliveryTime(arr[0].toString());
							} else {
								String day = CommonUtils.convertTimeStamptoStringFormat(
										CommonUtils.stringToTimeStampWithOutTimes(arr[0].toString()));
								orderMail.setDeliveryTime(
										day + " " + arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4] + " " + arr[5]);
							}
						}

						orderMail.setTotalOrderAmount(totalOrderAmount);
						orderMail.setTrackingNumber(order.getDeliveryCode());
						orderMail.setDeliveryCode(order.getDeliveryMode());
						orderMail.setVendorName(order.getVendor().getName());
						orderMail.setOrderPlacedOn(
								CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
						if (order.getDeliveryMode().equalsIgnoreCase("Pick-Up")) {
							orderMail.setLine1(order.getPickupLine1());
							if (Strings.isNullOrEmpty(order.getPickupLine2())) {
								orderMail.setLine2("");
							} else {
								orderMail.setLine2(order.getPickupLine2());
							}
							orderMail.setCity(order.getPickupCity());
							orderMail.setZipcode(order.getPickupZipcode());
							orderMail.setCountry(order.getPickupCountry());
							orderMail.setInstruction(order.getInstruction());
							orderMail.setLocationName(order.getLocationName());
							orderMail.setState(order.getPickupState());
						} else {
							orderMail.setLine1(shippingAddress.getLine1());
							if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
								orderMail.setLine2("");
							} else {
								orderMail.setLine2(shippingAddress.getLine2());
							}
							orderMail.setCity(shippingAddress.getCity());
							orderMail.setZipcode(shippingAddress.getZipcode());
							orderMail.setCountry(shippingAddress.getCountry());
							State state = stateRepository.findStateById(shippingAddress.getStateId());
							if (state != null) {
								orderMail.setState(state.getName());
							}

						}
						orderMail.setProductList(orderItemList);
						orderMail.setOrders(order);
						if (order != null && order.getDeliveryCharge() != null) {
							orderMail.setTotalDeliveryCharge(order.getDeliveryCharge().getDeliveryChargeAmt() != null
									? order.getDeliveryCharge().getDeliveryChargeAmt()
									: 0.0);
						} else {
							orderMail.setTotalDeliveryCharge(0.0);
						}
					  }
					buyerOrder.add(orderMail);
				}
				mailPreparationMap.put(vendorName, buyerOrder);
			}
			/*
			 * if(!CommonUtils.IsNullOrEmpty(buyerOrder)) { return buyerOrder; }
			 */
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			
			mailMap.put("mailPreparationMap", mailPreparationMap);
			mailMap.put("name", user.getFirstName() + " " + user.getLastName());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("orderCount", orderList.size());
			// mailMap.put("loginurl", webSiteUrl);
			mailMap.put("loginurl", webSiteUrl.concat(buyerTrackOrderUrl + orderId));
			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("city", shippingAddress.getCity());
			//calculate total delivery charge for all orders
			Double deliveryChargeAmt = getAllVendorDeliveryCharge(mailPreparationMap);
			logger.info("deliveryChargeAmt all vendor"+deliveryChargeAmt);
			mailMap.put("totalOrderAmount", totalOrderAmount+deliveryChargeAmt);
			mailMap.put("state", stateName);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("buyerUserOrderList", webSiteUrl.concat(buyerUserOrderList));
			mailMap.put("buyerSupportFAQ", webSiteUrl.concat(buyerSupportFAQ));

			Template mailTemplate = config.getTemplate(BuyerSuccessfullPaymentOrderTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", user.getEmail());
			// notificationMap.put("userMail", "yanivthy@gmail.com");
			notificationMap.put("subject", BuyerSuccessfullPaymentOrderSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//													throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//															500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMail----ends----");
    }

	private Double getAllVendorDeliveryCharge(Map<String, List<BuyerOrderResponse>> mailPreparationMap) {
		Double deliveryChargeAmt = 0.0;
		 Map<String, Double> totalDeliveryChargeMap = new HashMap<>();

	        for (Map.Entry<String, List<BuyerOrderResponse>> entry : mailPreparationMap.entrySet()) {
	            String key = entry.getKey();
	            List<BuyerOrderResponse> responses = entry.getValue();

	            // Check if the totalDeliveryCharge for this key has already been fetched
	            if (!totalDeliveryChargeMap.containsKey(key)) {         
	                Double totalDeliveryCharge = responses.stream()
	                        .findFirst()
	                        .map(BuyerOrderResponse::getTotalDeliveryCharge)
	                        .orElse(0.0);	               
	                deliveryChargeAmt = deliveryChargeAmt + totalDeliveryCharge;
	                totalDeliveryChargeMap.put(key, totalDeliveryCharge);
	            }
	        }
		return deliveryChargeAmt;
	}

	@Async("specificTaskExecutor")
	public void sendSuccessfullPaymentOrderMailToSeller(User user, Orders order, Address shippingAddress,
			String stateName, Orders newOrder,String addressId) {
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMailToSeller----starts----"+user,order,shippingAddress,stateName,newOrder);
		try {
			List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
			List<Product> orderItemList = null;
			Address SellerAddress = null;
			Double totalAmount = 0.0;
			Double totalOrderAmount = 0.0;
					// for(Orders order : orderList) {
			BuyerOrderResponse orderMail = new BuyerOrderResponse();
			orderItemList = new ArrayList<>();
			if (!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
				for (OrderItem orderItem : order.getOrderItems()) {
					if (orderItem != null) {
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						product.setQuantity(orderItem.getQuantity());
						Double productTotalAmount = 0.0;
						productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
						totalAmount = totalAmount + orderItem.getPrice();
						product.setTotalAmount(productTotalAmount);
						product.setTax(orderItem.getTax());
						product.setProductTotalAmount(productTotalAmount);
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						double shippingCostWithTotalAmt = productTotalAmount + order.getShippingCost();							
						product.setTotalAmount(shippingCostWithTotalAmt + order.getTotalTax());
						
						List<ProductImage> productImageList = new ArrayList<>();
						productImageList = productImageRepository.findByProductProductIdAndIsActive(orderItem.getProduct().getProductId(), true);
						product = CommonUtils.productImageURLForMailTemplate(product, productImageList);
						product.setOrderNumber(order.getOrderNumber());
						orderItemList.add(product);
					}
				}
				orderMail.setDeliveryMode(order.getDeliveryMode());
				orderMail.setOrderNumber(order.getOrderNumber());
				orderMail.setOrderAmount(order.getOrderAmount());
				orderMail.setShippingCost(order.getShippingCost());
				orderMail.setTotalTax(order.getTotalTax());
				orderMail.setTotalAmountWithShipping(order.getOrderAmount() + order.getShippingCost() + order.getTotalTax());
				totalOrderAmount = totalOrderAmount + orderMail.getTotalAmountWithShipping();
				if (order.getScheduleDateTime() != null && !order.getDeliveryMode().equals("Shipping")) {
					// orderMail.setDeliveryTime(CommonUtils.extractTimeDelivery(order.getExpectedScheduleDate().toString()));
					//String day = CommonUtils.sellerMailDateFormat(order.getExpectedScheduleDate().toString());
					String[] arr = order.getScheduleDateTime().split(" ");
					if(arr.length==1) {
						orderMail.setDeliveryTime(arr[0].toString());
					} else {
						String day = CommonUtils.convertTimeStamptoStringFormat(CommonUtils.stringToTimeStampWithOutTimes(arr[0].toString()));
						orderMail.setDeliveryTime(day+" "+arr[1]+" "+arr[2]+" "+arr[3]+" "+arr[4]+" "+arr[5]);
					}
				}

				//added by raja
				if (order.getDeliveryMode().equalsIgnoreCase("Pick-Up")) {
							orderMail.setLine1(order.getPickupLine1());
							if (Strings.isNullOrEmpty(order.getPickupLine2())) {
								orderMail.setLine2("");
							} else {
								orderMail.setLine2(order.getPickupLine2());
							}
							orderMail.setCity(order.getPickupCity());
							orderMail.setZipcode(order.getPickupZipcode());
							orderMail.setCountry(order.getPickupCountry());
							orderMail.setState(order.getPickupState());
				} else {
					//shipping and delivery address
					orderMail.setLine1(shippingAddress.getLine1());
					if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
						orderMail.setLine2("");
					} else {
						orderMail.setLine2(shippingAddress.getLine2());
					}
					orderMail.setCity(shippingAddress.getCity());
					orderMail.setZipcode(shippingAddress.getZipcode());
					orderMail.setCountry(shippingAddress.getCountry());
					State state = stateRepository.findStateById(shippingAddress.getStateId());
					if (state != null) {
						orderMail.setState(state.getName());
					}
					//orderMail.setState(stateName);
				}

				orderMail.setTotalOrderAmount(totalOrderAmount);
				orderMail.setTrackingNumber(order.getDeliveryCode());
				orderMail.setDeliveryCode(order.getDeliveryMode());
				orderMail.setVendorName(order.getVendor().getName());
				orderMail.setOrderPlacedOn(
						CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
				orderMail.setProductList(orderItemList);
				orderMail.setTotalDeliveryCharge(order.getTotalDeliveryCharge());
			}
			buyerOrder.add(orderMail);
			// }
			/*
			 * if(!CommonUtils.IsNullOrEmpty(buyerOrder)) { return buyerOrder; }
			 */
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("buyerOrder", buyerOrder);
			// mailMap.put("name", user.getFirstName()+" "+user.getLastName());
			mailMap.put("name",
					newOrder.getVendor().getUser().getFirstName() + " " + newOrder.getVendor().getUser().getLastName());
			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("city", shippingAddress.getCity());
			mailMap.put("totalOrderAmount", totalOrderAmount);
			mailMap.put("state", stateName);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("orderCount", buyerOrder.size());
			mailMap.put("loginurl", domain.concat(sellerManageOrderUrl));
			Template mailTemplate = config.getTemplate(sellerSuccessfullPaymentOrderTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			// notificationMap.put("userMail", email);
			notificationMap.put("userMail", newOrder.getVendor().getUser().getEmail());
			//notificationMap.put("userMail", "yanivthy@gmail.com");
			notificationMap.put("subject", BuyerSuccessfullPaymentOrderSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMailToSeller----ends----");
	}
	
	
	//Group by same vendor for delivery merge
	@Async("specificTaskExecutor")
	public void sendSuccessfullPaymentOrderMailToSellerCombineDelivery(User user, List<Orders> deliveryList, Address shippingAddress,
			String stateName, String addressId) {
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMailToSeller----starts----" + user, deliveryList,
				shippingAddress, stateName);
		try {
			Orders order = new Orders();
			if (!CommonUtils.IsNullOrEmpty(deliveryList)) {
				order = deliveryList.get(0);
			}
			List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
			List<Product> orderItemList = null;
			Double totalAmount = 0.0;
			Double totalOrderAmount = 0.0;
			BuyerOrderResponse orderMail = new BuyerOrderResponse();
			orderItemList = new ArrayList<>();
			for (Orders deliveryItems : deliveryList) {
				if (!CommonUtils.IsNullOrEmpty(deliveryItems.getOrderItems())) {
					for (OrderItem orderItem : deliveryItems.getOrderItems()) {
						if (orderItem != null) {
							Product product = new Product();
							product.setProductName(orderItem.getProductName());
							product.setPrice(orderItem.getPrice());
							product.setDeliveryMode(orderItem.getDeliveryMode());
							product.setDeliveryTime(orderItem.getExpectedScheduleDay());
							product.setQuantity(orderItem.getQuantity());
							Double productTotalAmount = 0.0;
							productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
							totalAmount = totalAmount + orderItem.getPrice();
					//		product.setTotalAmount(productTotalAmount);
							product.setTax(deliveryItems.getTotalTax());
							product.setProductTotalAmount(productTotalAmount);
							product.setProductDescription(orderItem.getProduct().getProductDescription());
							if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
								product.setProductDescription("Good");
							}
							double shippingCostWithTotalAmt = productTotalAmount + deliveryItems.getShippingCost();							
							product.setTotalAmount(shippingCostWithTotalAmt + deliveryItems.getTotalTax());
							List<ProductImage> productImageList = new ArrayList<>();							
							productImageList = productImageRepository.findByProductProductIdAndIsActive(orderItem.getProduct().getProductId(), true);							
							product = CommonUtils.productImageURLForMailTemplate(product, productImageList);
							product.setOrderNumber(deliveryItems.getOrderNumber());
							orderItemList.add(product);
						}
					}
				}
			}
			orderMail.setDeliveryMode(order.getDeliveryMode());
			orderMail.setOrderNumber(order.getOrderNumber());
			orderMail.setOrderAmount(order.getOrderAmount());
			orderMail.setShippingCost(order.getShippingCost());
			orderMail.setTotalTax(order.getTotalTax());
			orderMail
					.setTotalAmountWithShipping(order.getOrderAmount() + order.getShippingCost() + order.getTotalTax());
			totalOrderAmount = totalOrderAmount + orderMail.getTotalAmountWithShipping();
			if (order.getScheduleDateTime() != null && !order.getDeliveryMode().equals("Shipping")) {
				String[] arr = order.getScheduleDateTime().split(" ");
				if (arr.length == 1) {
					orderMail.setDeliveryTime(arr[0].toString());
				} else {
					String day = CommonUtils.convertTimeStamptoStringFormat(
							CommonUtils.stringToTimeStampWithOutTimes(arr[0].toString()));
					orderMail.setDeliveryTime(
							day + " " + arr[1] + " " + arr[2] + " " + arr[3] + " " + arr[4] + " " + arr[5]);
				}
			}

			// added by raja
			if (order.getDeliveryMode().equalsIgnoreCase("Pick-Up")) {
				orderMail.setLine1(order.getPickupLine1());
				if (Strings.isNullOrEmpty(order.getPickupLine2())) {
					orderMail.setLine2("");
				} else {
					orderMail.setLine2(order.getPickupLine2());
				}
				orderMail.setCity(order.getPickupCity());
				orderMail.setZipcode(order.getPickupZipcode());
				orderMail.setCountry(order.getPickupCountry());
				orderMail.setState(order.getPickupState());
			} else {
				// shipping and delivery address
				orderMail.setLine1(shippingAddress.getLine1());
				if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
					orderMail.setLine2("");
				} else {
					orderMail.setLine2(shippingAddress.getLine2());
				}
				orderMail.setCity(shippingAddress.getCity());
				orderMail.setZipcode(shippingAddress.getZipcode());
				orderMail.setCountry(shippingAddress.getCountry());
				State state = stateRepository.findStateById(shippingAddress.getStateId());
				if (state != null) {
					orderMail.setState(state.getName());
				}
			}

			orderMail.setTotalOrderAmount(totalOrderAmount);
			orderMail.setTrackingNumber(order.getDeliveryCode());
			orderMail.setDeliveryCode(order.getDeliveryMode());
			orderMail.setVendorName(order.getVendor().getName());
			orderMail.setOrderPlacedOn(CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
			orderMail.setProductList(orderItemList);
			orderMail.setTotalDeliveryCharge(order.getTotalDeliveryCharge());
			buyerOrder.add(orderMail);
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("buyerOrder", buyerOrder);
			mailMap.put("name",
					order.getVendor().getUser().getFirstName() + " " + order.getVendor().getUser().getLastName());
			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("city", shippingAddress.getCity());
			mailMap.put("totalOrderAmount", totalOrderAmount);
			mailMap.put("state", stateName);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("orderCount", buyerOrder.size());
			mailMap.put("loginurl", domain.concat(sellerManageOrderUrl));
			Template mailTemplate = config.getTemplate(sellerSuccessfullPaymentOrderTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", order.getVendor().getUser().getEmail());
			notificationMap.put("subject", BuyerSuccessfullPaymentOrderSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendSuccessfullPaymentOrderMailToSeller----ends----");
	}

	private String deliveryOptionMail(Orders newOrder, String deliveryMode) throws ParseException {
		logger.info("OrderServiceImpl deliveryOptionMail----starts----"+newOrder,deliveryMode);
		boolean flag = false;
		VendorSchedule vendorSchedule = null;
		String nxtDay = CommonUtils.getNextDay();
		for (int i = 1; i <= 7; i++) {
			if (flag) {
				break;
			}
			for (int k = 1; k <= 3; k++) {
				if (flag) {
					break;
				}
				if (nxtDay.equals(Constant.MONDAY)) {
					vendorSchedule = vendorScheduleRepository.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.TUESDAY;
						break;
					} else {
						nxtDay = Constant.MONDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.TUESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.WEDNESDAY;
						break;
					} else {
						nxtDay = Constant.TUESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.WEDNESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.THURSDAY;
						break;
					} else {
						nxtDay = Constant.WEDNESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.THURSDAY)) {
					vendorSchedule = vendorScheduleRepository.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.FRIDAY;
						break;
					} else {
						nxtDay = Constant.THURSDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.FRIDAY)) {
					vendorSchedule = vendorScheduleRepository.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.SATURDAY;
						break;
					} else {
						nxtDay = Constant.FRIDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SATURDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.SUNDAY;
						break;
					} else {
						nxtDay = Constant.SATURDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SUNDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryMode, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.MONDAY;
						break;
					} else {
						nxtDay = Constant.SUNDAY;
						continue;
					}
				}
			}
		}
		String convertedTime = deliveryMode + "(" + nxtDay + " "
				+ CommonUtils.convertedTime(CommonUtils.getNextDayTime()) + ")";
		// String convertedTime = newOrder.getDeliveryMode()+"("+nxtDay +"
		// "+vendorSchedule.getFromTime()+":00-"+vendorSchedule.getToTime()+":00)";
		logger.info("OrderServiceImpl deliveryOptionMail----ends----");
		return convertedTime;
	}

	private String deliveryOption(Orders newOrder) throws ParseException {
		logger.info("OrderServiceImpl deliveryOption----starts----"+newOrder);
		boolean flag = false;
		VendorSchedule vendorSchedule = null;
		String nxtDay = CommonUtils.getNextDay();
		for (int i = 1; i <= 7; i++) {
			if (flag) {
				break;
			}
			for (int k = 1; k <= 3; k++) {
				if (flag) {
					break;
				}
				if (nxtDay.equals(Constant.MONDAY)) {
					vendorSchedule = vendorScheduleRepository.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.TUESDAY;
						break;
					} else {
						nxtDay = Constant.MONDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.TUESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.WEDNESDAY;
						break;
					} else {
						nxtDay = Constant.TUESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.WEDNESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.THURSDAY;
						break;
					} else {
						nxtDay = Constant.WEDNESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.THURSDAY)) {
					vendorSchedule = vendorScheduleRepository.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.FRIDAY;
						break;
					} else {
						nxtDay = Constant.THURSDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.FRIDAY)) {
					vendorSchedule = vendorScheduleRepository.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.SATURDAY;
						break;
					} else {
						nxtDay = Constant.FRIDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SATURDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.SUNDAY;
						break;
					} else {
						nxtDay = Constant.SATURDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SUNDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, newOrder.getDeliveryMode(), k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						if (!(CommonUtils.fromToTimeCheck(vendorSchedule.getFromTime(),
								CommonUtils.getNextDayTime()) < 0)) {
							flag = true;
						}
					}
					if (k == 3) {
						nxtDay = Constant.MONDAY;
						break;
					} else {
						nxtDay = Constant.SUNDAY;
						continue;
					}
				}
			}
		}
		String convertedTime = newOrder.getDeliveryMode() + "(" + nxtDay + " "
				+ CommonUtils.convertedTime(CommonUtils.getNextDayTime()) + ")";
		logger.info("OrderServiceImpl deliveryOption----ends----");
		return convertedTime;
	}

	private String nextDeliverySchedule(Orders newOrder,String deliveryType) throws ParseException {
		logger.info("OrderServiceImpl nextDeliverySchedule----starts----"+newOrder);
		boolean flag = false;
		Integer value = 1;
		VendorSchedule vendorSchedule = null;
		String nxtDay = CommonUtils.getNextDay();
		for (int i = 1; i <= 7; i++) {
			value = i - 1;
			if (flag) {
				break;
			}
			for (int k = 1; k <= 3; k++) {
				if (flag) {
					break;
				}
				if (nxtDay.equals(Constant.MONDAY)) {
					vendorSchedule = vendorScheduleRepository.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.TUESDAY;
						break;
					} else {
						nxtDay = Constant.MONDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.TUESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.WEDNESDAY;
						break;
					} else {
						nxtDay = Constant.TUESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.WEDNESDAY)) {
					vendorSchedule = vendorScheduleRepository.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.THURSDAY;
						break;
					} else {
						nxtDay = Constant.WEDNESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.THURSDAY)) {
					vendorSchedule = vendorScheduleRepository.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.FRIDAY;
						break;
					} else {
						nxtDay = Constant.THURSDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.FRIDAY)) {
					vendorSchedule = vendorScheduleRepository.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.SATURDAY;
						break;
					} else {
						nxtDay = Constant.FRIDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SATURDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.SUNDAY;
						break;
					} else {
						nxtDay = Constant.SATURDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SUNDAY)) {
					vendorSchedule = vendorScheduleRepository.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(
							nxtDay, deliveryType, k, newOrder.getVendor().getVendorId());
					if (vendorSchedule != null) {
						flag = true;
					}
					if (k == 3) {
						nxtDay = Constant.MONDAY;
						break;
					} else {
						nxtDay = Constant.SUNDAY;
						continue;
					}
				}
			}
		}

		String convertedTime = CommonUtils.NextScheduledDate(value);
		logger.info("OrderServiceImpl nextDeliverySchedule----ends----");
		return convertedTime;
	}

	@Override
	public String nextDeliveryScheduleDay(String deliveryMode, Integer vendorId, boolean check,
										  Integer preparationTime) throws ParseException {
		logger.info("OrderServiceImpl nextDeliveryScheduleDay----starts----"+deliveryMode,vendorId,check,preparationTime);
		boolean flag = false;
		boolean dayCheckFlag = false;
		Integer value = 1;
		VendorSchedule vendorSchedule = null;
		Integer scheduleTime = 0;

		if(preparationTime!=null && preparationTime != 0) {
			scheduleTime = orderScheduleTime + preparationTime;
		} else {
			scheduleTime = orderScheduleTime;
		}
		String nxtDay = CommonUtils.getNextScheduleDay(scheduleTime);

		for (int i = 1; i <= 7; i++) {
			value = i - 1;
			if (flag) {
				break;
			}
			for (int k = 1; k <= 3; k++) {
				if (flag) {
					break;
				}
				if (nxtDay.equals(Constant.MONDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						// String time = CommonUtils.getNextDayTime();
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.TUESDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.MONDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.TUESDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.WEDNESDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.TUESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.WEDNESDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.THURSDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.WEDNESDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.THURSDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.FRIDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.THURSDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.FRIDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}

					}
					if (k == 3) {
						nxtDay = Constant.SATURDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.FRIDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SATURDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.SUNDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.SATURDAY;
						continue;
					}
				} else if (nxtDay.equals(Constant.SUNDAY)) {
					vendorSchedule = vendorScheduleRepository
							.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(nxtDay, deliveryMode, k, vendorId);
					if (vendorSchedule != null) {
						String time = (null != preparationTime && 0 != preparationTime)
								? CommonUtils.getPreparationTime(preparationTime)
								: CommonUtils.getNextDayTime();
						String[] arr = time.split(":");
						String[] fromTime = vendorSchedule.getFromTime().split(":");
						String[] toTime = vendorSchedule.getToTime().split(":");
						if (dayCheckFlag) {
							flag = true;
						} else if (Integer.parseInt(fromTime[0]) == Integer.parseInt(arr[0])) {

							if (Integer.parseInt(fromTime[1]) >= Integer.parseInt(arr[1])) {
								flag = true;
							}
						} else if (Integer.parseInt(fromTime[0]) > Integer.parseInt(arr[0])) {
							flag = true;
						} else {
							flag = false;

						}
					}
					if (k == 3) {
						nxtDay = Constant.MONDAY;
						dayCheckFlag = true;
						break;
					} else {
						nxtDay = Constant.SUNDAY;
						continue;
					}
				}
			}
		}

		String convertedTime = null;
		String addressId = null;
		if (check) {
			if (vendorSchedule != null) {
				if(vendorSchedule.getVendorAddress()!=null && vendorSchedule.getVendorAddress().getAddress()!=null) {
					addressId = vendorSchedule.getVendorAddress().getAddress().getId().toString();
				}
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
				LocalTime checkLocalTime = LocalTime.parse(vendorSchedule.getToTime(), formatter);
				//String toTime = checkLocalTime.plusMinutes(01).toString();
				String toTime = checkLocalTime.toString();
				// convertedTime = nxtDay +" "+vendorSchedule.getFromTime()+":00 -
				// "+toTime+":00";O
				convertedTime = nxtDay + " " + CommonUtils.railwayTimeTo12Hour(vendorSchedule.getFromTime()) + " - "
						+ CommonUtils.railwayTimeTo12Hour(toTime);
			} else {
				convertedTime = "(" + nxtDay + ")";
			}
			return addressId;
		} else {
			if (vendorSchedule != null) {
				if(vendorSchedule.getVendorAddress()!=null && vendorSchedule.getVendorAddress().getAddress()!=null) {
					addressId = vendorSchedule.getVendorAddress().getAddress().getId().toString();
				}
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
				LocalTime checkLocalTime = LocalTime.parse(vendorSchedule.getToTime(), formatter);
				//String toTime = checkLocalTime.plusMinutes(01).toString();
				String toTime = checkLocalTime.toString();
				String row = nxtDay.toUpperCase();
				convertedTime = CommonUtils.dayToDate(row) + " "
						+ CommonUtils.railwayTimeTo12Hour(vendorSchedule.getFromTime()) + " - "
						+ CommonUtils.railwayTimeTo12Hour(toTime);
			} else {
				convertedTime = "(" + nxtDay + ")";
			}
		}
		logger.info("OrderServiceImpl nextDeliveryScheduleDay----ends----");
		return convertedTime;
	}

	@Override
	public Response buyerOrder(OrderSaveRequest orders) throws Exception {
		logger.info("OrderServiceImpl buyerOrder----starts----"+orders);
		List<Orders> orderList = new ArrayList<>();
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(orders.getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (orders.getProductDetails() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_DETAILS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (Strings.isNullOrEmpty(orders.getTransactionId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TRANSACTION_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		User userDetails = userRepository.findByUserId(orders.getUserId());
		if (userDetails == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Address shippingAddress = null;
		String stateName = null;
		//BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserId(userDetails.getUserId());
		BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserIdAndDefalt(userDetails.getUserId(),"Y");
		if (buyerAddress != null) {
			shippingAddress = buyerAddress.getAddress();
		}
		if (shippingAddress == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SHIPPING_ADDRESS_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (shippingAddress.getStateId() != null) {
			State state = stateRepository.findStateById(shippingAddress.getStateId());
			if (state != null) {
				stateName = state.getName();
			}
		}
		// Address shippingAddress =
		// addressRepository.findAddressById(orders.getShippingAddressId());
		List<Integer> productIds = new ArrayList<Integer>();
		for (OrderItemSaveRequest orderDetail : orders.getProductDetails()) {
			productIds.add(orderDetail.getProductId());
		}
		// Get Unique VendorIds based on list of ProductIds
		List<Integer> vendorIds = productRepository.findVendorIdsByProductIds(productIds);

		if (CommonUtils.IsNullOrEmpty(vendorIds)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_VENDOR_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		// Iteration for Each VendorIds
		for (Integer vendorId : vendorIds) {
			Vendor vendor = vendorRepository.findByVendorId(vendorId);
			Orders newOrder = prepareOrderDetails(userDetails, shippingAddress);
			newOrder.setVendor(vendor);
			newOrder.setVendorId(vendorId);
			List<OrderItem> itemsList = new ArrayList<OrderItem>();
			long orderAmount = 0;
			String deliveryMode = "";
			// String oldProductDelivery="";
			for (OrderItemSaveRequest orderDetail : orders.getProductDetails()) {
				Product product = productRepository.findByProductId(orderDetail.getProductId());
				if (product != null) {
					if (product.getVendor().getVendorId().intValue() == vendorId.intValue()) {
						double itemTotalAmount = product.getPrice() * orderDetail.getQuantity();
						orderAmount = orderAmount + (long) itemTotalAmount;
						if (product.getIsDeliverable() == true) {
							deliveryMode = Constant.ORDER_DELIVERY_MODE;
						} else {
							deliveryMode = Constant.ORDER_PICKUP_MODE;
						}
						OrderItem OrderItem = new OrderItem();
						OrderItem.setProduct(product);
						OrderItem.setProductId(product.getProductId());
						OrderItem.setProductName(product.getProductName());
						OrderItem.setProductCode(product.getProductCode());
						OrderItem.setPrice(product.getPrice());
						OrderItem.setQuantity(orderDetail.getQuantity());
						OrderItem.setVendor(vendor);
						OrderItem.setVendorId(vendorId);
						OrderItem.setIsDeliveryEnable(product.getIsDeliverable());
						OrderItem.setDeliveryMode(deliveryMode);
						String scheduleDate = nextDeliveryScheduleDay(deliveryMode, vendor.getVendorId(), false, 0);
						System.out.println("scheduleDate========>"+scheduleDate);
						if (!Strings.isNullOrEmpty(scheduleDate)) {
							OrderItem.setExpectedScheduleDay(scheduleDate);
							ordersRepository.save(newOrder);
						}
						itemsList.add(OrderItem);
					}
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}
			newOrder.setOrderAmount(orderAmount);
			newOrder.setDeliveryMode(deliveryMode);
			if (itemsList.size() > 0) {
				newOrder.setOrderItems(itemsList);
				newOrder.setTrackingNumber(CommonUtils.getRandomNumberString());
				newOrder.setTransactionId(orders.getTransactionId());
				newOrder.setBuyerPaid(true);
				newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				newOrder = ordersRepository.save(newOrder);
				String scheduleDate = nextDeliverySchedule(newOrder,deliveryMode);
				if (!Strings.isNullOrEmpty(scheduleDate)) {
					newOrder.setExpectedScheduleDate(CommonUtils.stringToTimeStamp(scheduleDate));
					newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					ordersRepository.save(newOrder);
				}
				System.out.println("scheduleDate========>"+scheduleDate);
				// saveOrderItems(newOrder);
				if (newOrder != null && newOrder.getOrderItems() != null) {
					for (OrderItem orderItem : newOrder.getOrderItems()) {
						orderItem.setOrder(newOrder);
						orderItem.setOrderId(newOrder.getOrderId());
						orderItemRepository.save(orderItem);
						updateProductUnitCount(orderItem.getProduct(), orderItem.getQuantity());
					}
					newOrder.setOrderItems(itemsList);
				}
				// Send order creation email

				if (userDetails != null) {
					sendOrderCreationMail(userDetails, newOrder, shippingAddress, stateName);
					orderList.add(newOrder);
					// sendSuccessfullPaymentOrderMail(user, newOrder,buyer);
				}
				List<Cart> cart = cartRepository.findByUserUserId(userDetails.getUserId());
				for (Cart delCart : cart) {
					cartRepository.delete(delCart);
				}
			}
		}
		if (!CommonUtils.IsNullOrEmpty(orderList)) {
			sendSuccessfullPaymentOrderMail(userDetails, orderList, shippingAddress, stateName, null);
			// return ResponseHelper.getSuccessResponse(Constant.ORDER_SAVED_SUCCESSFULLY,
			// order, 200, Constant.RESPONSE_SUCCESS);
		}
		// ---
		logger.info("OrderServiceImpl buyerOrder----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ORDER_SAVED_SUCCESSFULLY, Constant.RESPONSE_EMPTY_DATA, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response buyerOrderWithShipping(List<GroupedVendorOrderRequest> groupedVendorOrderRequest) throws Exception {
		logger.info("OrderServiceImpl buyerOrderWithShipping----starts----"+groupedVendorOrderRequest);

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		List<Orders> orderList = new ArrayList<>();
		if (groupedVendorOrderRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		User userDetails = null;
		Discount discount = null;
		Address shippingAddress = null;
		String stateName = null;
		for(GroupedVendorOrderRequest groupedVendorOrder : groupedVendorOrderRequest) {
			for(BuyerOrderRequest  orders : groupedVendorOrder.getBuyerOrderRequest()) {
			if (StringUtils.isEmpty(user.getUserId())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (orders == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_DETAILS_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (Strings.isNullOrEmpty(orders.getTransactionId())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TRANSACTION_ID_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			userDetails = userRepository.findByUserId(user.getUserId());
			if (userDetails == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}			
			String stateCode = null;
			BuyerAddress buyerAddress = buyerAddressRepository.findByAddressId(orders.getBuyerAddressId());
			//BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserIdAndDefalt(userDetails.getUserId(),"Y");

			if (buyerAddress != null) {
				shippingAddress = buyerAddress.getAddress();
			}
			if (shippingAddress == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SHIPPING_ADDRESS_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			if (shippingAddress.getStateId() != null) {
				State state = stateRepository.findStateById(shippingAddress.getStateId());
				if (state != null) {
					stateName = state.getName();
					stateCode = state.getStatecode();
				}
			}
			/*
			 * List<Integer> productIds = new ArrayList<Integer>(); for
			 * (BuyerOrderSaveRequest orderDetail : orders.getOrder()) {
			 * for(OrderItemSaveRequest OrderItemSaveRequest : orderDetail.getProduct()) {
			 * productIds.add(OrderItemSaveRequest.getProductId()); } }
			 *
			 * List<Integer> vendorIds =
			 * productRepository.findVendorIdsByProductIds(productIds);
			 *
			 * if(CommonUtils.IsNullOrEmpty(vendorIds)) { throw new
			 * BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_VENDOR_NOT_FOUND,
			 * Constant.RESPONSE_EMPTY_DATA, 1001); }
			 */
			int parentOrderId = 0;
			Map<Integer,Integer> vendorMap = new HashMap<>();
			
			List<Orders> deliveryList = new ArrayList<Orders>();
			String addressId = null;
			
			for (BuyerOrderSaveRequest buyerOrderSaveRequest : orders.getOrder()) {
				Vendor vendor = vendorRepository.findByVendorId(buyerOrderSaveRequest.getVendorId());
				Orders newOrder = prepareOrderDetails(userDetails, shippingAddress);
				newOrder.setVendor(vendor);
				newOrder.setVendorId(buyerOrderSaveRequest.getVendorId());
				newOrder.setShippingCost(Double.parseDouble(new DecimalFormat("##.##").format(buyerOrderSaveRequest.getShippingCost())));
				newOrder.setSelectedDeliveryType(buyerOrderSaveRequest.getSelectedDeliveryType());
				newOrder.setAddressid(String.valueOf(orders.getBuyerAddressId()));
				List<OrderItem> itemsList = new ArrayList<OrderItem>();
				DeliveryCharge deliveryCharge =new DeliveryCharge();
				
				//changes
				if(buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("D")) {
				   // vendorNew=buyerOrderSaveRequest.getVendorId();
					if(!vendorMap.containsKey(buyerOrderSaveRequest.getVendorId())) {
						deliveryCharge.setVendorId(buyerOrderSaveRequest.getVendorId());
						deliveryCharge.setTransactionId(orders.getTransactionId());
						deliveryCharge.setDeliveryChargeAmt(groupedVendorOrder.getTotalDeliveryCharge());
						 saveDeliveryCharge(deliveryCharge,newOrder);
						 vendorMap.put(buyerOrderSaveRequest.getVendorId(), deliveryCharge.getDeliveryChargeId());
					}else {
						int deliverId = 0;
						deliverId = vendorMap.get(buyerOrderSaveRequest.getVendorId());
						DeliveryCharge deliveryfee = deliveryChargeRepository.findByDeliveryChargeId(deliverId);
						newOrder.setDeliveryCharge(deliveryfee);
					}
				}
				
				double orderAmount = 0;
				double discountAmount = 0.0;
				String deliveryMode = "";
				// String oldProductDelivery="";
				Integer preparationTime = 0;
				
				for (OrderItemSaveRequest orderDetail : buyerOrderSaveRequest.getProduct()) {
					Product product = productRepository.findByProductId(orderDetail.getProductId());
					if (product != null) {
						if (product.getVendor().getVendorId().intValue() == buyerOrderSaveRequest.getVendorId()
								.intValue()) {
							double itemTotalAmount = product.getPrice() * orderDetail.getQuantity();
							orderAmount = orderAmount + itemTotalAmount;
							if (orderDetail.getDiscount() != null) {
								discountAmount = discountAmount + orderDetail.getDiscount();
							}
							if (product.getIsDeliverable() == true) {
								deliveryMode = Constant.ORDER_DELIVERY_MODE;
							} else {
								deliveryMode = Constant.ORDER_PICKUP_MODE;
							}
							OrderItem OrderItem = new OrderItem();
							OrderItem.setProduct(product);
							OrderItem.setProductId(product.getProductId());
							OrderItem.setProductName(product.getProductName());
							OrderItem.setProductCode(product.getProductCode());
							OrderItem.setPrice(product.getPrice());
							OrderItem.setQuantity(orderDetail.getQuantity());
							OrderItem.setVendor(vendor);
							OrderItem.setVendorId(buyerOrderSaveRequest.getVendorId());
							OrderItem.setIsDeliveryEnable(product.getIsDeliverable());
							OrderItem.setDeliveryMode(deliveryMode);
							OrderItem.setDiscount(orderDetail.getDiscount());
							OrderItem.setTax(setItemTaxAmount(buyerOrderSaveRequest.getTax(),orderDetail.getQuantity()));						
							
							if (preparationTime <= product.getPreparationTime()) {
								preparationTime = product.getPreparationTime();
							}

							String scheduleDate = nextDeliveryScheduleDay(deliveryMode, vendor.getVendorId(), false, 0);
							if (!Strings.isNullOrEmpty(scheduleDate)) {
								OrderItem.setExpectedScheduleDay(scheduleDate);
								// ordersRepository.save(newOrder);
							}
							OrderItem.setUom(product.getUom().getName());
							itemsList.add(OrderItem);
							
							}
							
							
					} else {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
				}
				newOrder.setOrderAmount(Double.parseDouble(new DecimalFormat("##.##").format(orderAmount)));
				newOrder.setDiscountAmount(Double.parseDouble(new DecimalFormat("##.##").format(discountAmount)));
				newOrder.setTotalTax(buyerOrderSaveRequest.getTax() != null ? Double.parseDouble(new DecimalFormat("##.##").format(buyerOrderSaveRequest.getTax())) : 0.0);
				String deliveryType = null;
				if (!Strings.isNullOrEmpty(buyerOrderSaveRequest.getSelectedDeliveryType())) {
					if (buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("S")) {
						newOrder.setDeliveryMode("Shipping");
						deliveryType = "Shipping";
					} else if (buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("D")) {
						newOrder.setDeliveryMode("Delivery");
						deliveryType = "Delivery";
					} else if (buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("P")) {
						newOrder.setDeliveryMode("Pick-Up");
						deliveryType = "Pickup";
					}
				} else {
					newOrder.setDeliveryMode("Pick-Up");
					deliveryType = "Pickup";
				}
				String scheduleDateTime = nextDeliveryScheduleDay(deliveryType, vendor.getVendorId(), false,
						preparationTime);
				newOrder.setScheduleDateTime(scheduleDateTime);				
				if(deliveryType.equals("Pickup")) {
					addressId = nextDeliveryScheduleDay(deliveryType, vendor.getVendorId(), true,
							preparationTime);
					if(addressId==null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PICK_UP_ADDRESS_NOT_FOUND,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					Integer sellerPickupAddressId = Integer.parseInt(addressId);
					setInstructionAndLocationAndPickUpAddress(newOrder,sellerPickupAddressId);
				}
							
				//vendor address details sve on order table.
				setShippingStateAndStateCode(stateName, stateCode, newOrder);
				setVendorAddress(vendor, newOrder);
				
				

				
				if (itemsList.size() > 0) {
					// newOrder.getOrderItems().clear();ALTER TABLE product ADD maxUnitCount1 INT
					// DEFAULT 0;
					// newOrder.getOrderItems().addAll(itemsList);
					newOrder.setOrderItems(itemsList);
					newOrder.setTrackingNumber(CommonUtils.getRandomNumberString());
					newOrder.setTransactionId(orders.getTransactionId());
					newOrder.setBuyerPaid(true);
					newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					if (parentOrderId == 0) {
						newOrder = ordersRepository.save(newOrder);
						parentOrderId = newOrder.getOrderId();
					}
					newOrder.setParentOrderId(parentOrderId);
					newOrder = ordersRepository.save(newOrder);

					if (buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("S")) {
						ShippoTransactionDetails shippoTransactionDetails = saveTransaction(
								buyerOrderSaveRequest.getShippoTransId(), newOrder.getOrderId());
					}
					
					String scheduleDate = nextDeliverySchedule(newOrder,deliveryType);
					if (!Strings.isNullOrEmpty(scheduleDate)) {
						newOrder.setExpectedScheduleDate(CommonUtils.stringToTimeStampConvert(scheduleDate));
						newOrder.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
						ordersRepository.save(newOrder);
					}
					System.out.println(scheduleDate);
					// saveOrderItems(newOrder);
					if (newOrder != null && newOrder.getOrderItems() != null) {
						for (OrderItem orderItem : newOrder.getOrderItems()) {
							orderItem.setOrder(newOrder);
							orderItem.setOrderId(newOrder.getOrderId());
							orderItemRepository.save(orderItem);
							updateProductUnitCount(orderItem.getProduct(), orderItem.getQuantity());
						}
						// newOrder.setOrderItems(itemsList);
					}
					// Avalara_createTransaction method
					//AvalaraCreateTransactionResponse transactionResponse = avalaraCreateTransaction(buyerAddress, vendor,newOrder);
					//Avalara response set on order and order items table
					//setAvalararesponseOrderAndItem(newOrder, transactionResponse);
					newOrder.setTotalDeliveryCharge(groupedVendorOrder.getTotalDeliveryCharge());
					orderList.add(newOrder);
					if(buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("D")) {
						deliveryList.add(newOrder);
					}					

					if (userDetails != null) {
						// sendOrderCreationMail(userDetails, newOrder,shippingAddress,stateName);

						// User userDetail = userRepository.findByUserId(newOrder.getUserId());
						// if (userDetail != null) {
						if(!buyerOrderSaveRequest.getSelectedDeliveryType().equalsIgnoreCase("D")) {
							sendSuccessfullPaymentOrderMailToSeller(userDetails, newOrder, shippingAddress, stateName,
									newOrder,addressId);
						}						
						// }
						// sendSuccessfullPaymentOrderMail(user, newOrder,buyer);
					}
				}
			}

			Integer discountId = orders.getDiscountId();
			discount = discountRepository.findDiscountById(discountId);
			if (discountId != null && parentOrderId != 0) {
				DiscountRedemption discountRedemption = new DiscountRedemption();
				discountRedemption.setUser(user);
				discountRedemption.setParentOrderId(parentOrderId);
				discountRedemption.setDiscount(discount);
				Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
				discountRedemption.setRedemptionDate(currentTime);
				discountRedemptionRepository.save(discountRedemption);
			}

			List<Cart> cart = cartRepository.findByUserUserId(userDetails.getUserId());
			for (Cart delCart : cart) {
				cartRepository.delete(delCart);
			}
			//seller email group by delivery type
			if(deliveryList != null && deliveryList.size() > 0)
				sendSuccessfullPaymentOrderMailToSellerCombineDelivery(userDetails, deliveryList, shippingAddress, stateName,
					addressId);
			
			}
			
			
		}		

		if (!CommonUtils.IsNullOrEmpty(orderList)) {

			//Buyer email
			sendSuccessfullPaymentOrderMail(userDetails, orderList, shippingAddress, stateName, discount);

			// sendSuccessfullPaymentOrderTosellerMail
			// return ResponseHelper.getSuccessResponse(Constant.ORDER_SAVED_SUCCESSFULLY,
			// order, 200, Constant.RESPONSE_SUCCESS);
		}
		// ---
		logger.info("OrderServiceImpl buyerOrderWithShipping----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ORDER_SAVED_SUCCESSFULLY, Constant.RESPONSE_EMPTY_DATA, 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	
	private void saveDeliveryCharge(DeliveryCharge deliveryCharge, Orders newOrder) {
		int deliveryID=0;			
			deliveryCharge.setDeliveryChargePaid(true);
			deliveryCharge.setDeliveryChargeRefund(false);
			deliveryCharge.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			deliveryCharge.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			DeliveryCharge deliveryFee=deliveryChargeRepository.save(deliveryCharge);
			deliveryID =deliveryFee.getDeliveryChargeId();
			System.out.println("DeliveryId 1st:"+deliveryID);
			newOrder.setDeliveryCharge(deliveryFee);
		
	}

	private Double setItemTaxAmount(Double totalTax, Integer qty) {
		Double itemTax = 0.0;
		if (totalTax != null && qty != null) {
			itemTax = totalTax / qty;
			DecimalFormat df = new DecimalFormat("##.##");
			String formattedTax = df.format(itemTax);
			return Double.valueOf(formattedTax);
		}
		return itemTax;
	}

	public void setAvalararesponseOrderAndItem(Orders newOrder, AvalaraCreateTransactionResponse transactionResponse) {
		double totalTax = 0;
		if (newOrder == null || transactionResponse == null || transactionResponse.getLines() == null || transactionResponse.getLines().isEmpty()) {
			logger.error("An error occurred during newOrder,transactionResponse is null");	       
	    }else {
			for (OrderItem orderItem : newOrder.getOrderItems()) {
				for (AvalaraTransactionLineItemResponse line : transactionResponse.getLines()) {
					if (line.getItemCode().equals(String.valueOf(orderItem.getProduct().getProductId()))) {
						orderItem.setTax(line.getTax());
						totalTax = totalTax + line.getTax();
						orderItemRepository.save(orderItem);
						break;
					}
				}
			}
			newOrder.setTotalTax(totalTax);
			newOrder.setAvalaraTxnId(transactionResponse.getId());
			ordersRepository.save(newOrder);
	    }
	}

	public AvalaraCreateTransactionResponse avalaraCreateTransaction(BuyerAddress buyerAddress, Vendor vendor,
			Orders newOrder) {
		try {

			VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndType(vendor.getVendorId(),
					Constant.PRIMARY);
			AvalaraCreateTransactionRequest avalaraCreateTransactionRequest = AvalaraHelper
					.buildSaveTaxRequest(newOrder, vendorAddress.getAddress(), buyerAddress.getAddress());
			AvalaraCreateTransactionResponse transactionResponse = avalaraClient
					.createTransaction(avalaraCreateTransactionRequest);

			AvalaraTxnSummary avalaraTxnSummary = AvalaraHelper.createTransactionSummary(transactionResponse);
			avalaraTxnSummary.setOrderDate(CommonUtils.convertTimeStamptoStringAvalara(newOrder.getOrderDate()));
			avalaraTxnSummary.setSellerName(newOrder.getVendor().getName());
			avalaraTxnSummary.setSellerState(newOrder.getVendorStateCode());
			avalaraTxnSummary.setOrder(newOrder);
			avalaraTxnSummaryRepository.save(avalaraTxnSummary);
			Set<AvalaraTxnLineSummary> lines = AvalaraHelper.createTransactionLineSummary(transactionResponse,
					avalaraTxnSummary, newOrder);
			avalaraTxnLineSummaryRepository.saveAll(lines);
			return transactionResponse;
		} catch (Exception e) {
			logger.error("An error occurred during Avalara transaction creation: " + e.getMessage());
		}
		return null;
	}

	private void setShippingStateAndStateCode(String stateName, String stateCode, Orders newOrder) {
		newOrder.setShipState(stateName);
		newOrder.setShippingStateCode(stateCode);
	}

	private void setVendorAddress(Vendor vendor, Orders newOrder) {
		if (vendor != null) {
			System.out.println("vendor id:"+vendor.getVendorId());
			VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndType(vendor.getVendorId(),
					Constant.PRIMARY);
			if (vendorAddress != null) {
				Address address = vendorAddress.getAddress();
				if (address != null) {
					newOrder.setVendorLine1(address.getLine1());
					newOrder.setVendorLine2(address.getLine2());
					newOrder.setVendorCity(address.getCity());
					newOrder.setVendorDistrict(address.getDistrict());
					if (address.getStateId() != null) {
						State state = stateRepository.findStateById(address.getStateId());
						if (state != null) {
							newOrder.setVendorState(state.getName());
							newOrder.setVendorStateCode(state.getStatecode());
						}
					}
					newOrder.setVendorZipcode(address.getZipcode());
					newOrder.setVendorCountry(address.getCountry());
				}
			}

		}
	}

	private void setInstructionAndLocationAndPickUpAddress(Orders newOrder, Integer sellerPickupAddressId) {		
			Address pickUpAddress = addressRepository.findAddressById(sellerPickupAddressId);
			if (pickUpAddress != null) {
				newOrder.setInstruction(pickUpAddress.getInstruction());
				newOrder.setLocationName(pickUpAddress.getLocationName());
				newOrder.setPickupLine1(pickUpAddress.getLine1());
				newOrder.setPickupLine2(pickUpAddress.getLine2());				
				newOrder.setPickupCity(pickUpAddress.getCity());
				newOrder.setPickupDistrict(pickUpAddress.getDistrict());
				if (pickUpAddress.getStateId() != null) {
					State state = stateRepository.findStateById(pickUpAddress.getStateId());
					if (state != null) {						
						newOrder.setPickupState(state.getName());
						newOrder.setPickupStateCode(state.getStatecode());
					}
				}		
				newOrder.setPickupZipcode(pickUpAddress.getZipcode());
				newOrder.setPickupCountry(pickUpAddress.getCountry());
			}		
	}

	@Override
	public Response checkOut(OrderSaveRequest orders) throws Exception {
		logger.info("OrderServiceImpl checkOut----starts----"+orders);
		Map<String, String> map = null;
		ArrayList<Map<String, String>> list = new ArrayList<>();
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (orders.getProductDetails() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_DETAILS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		for (OrderItemSaveRequest orderDetail : orders.getProductDetails()) {
			map = new HashMap<>();
			Product product = productRepository.findByProductIdAndApprovalStatus(orderDetail.getProductId(),Constant.PRODUCT_APPROVAL_STATUS_APPROVED);
			if (product == null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			if (product.getUnitCount() == 0) {
				map.put("productName", product.getProductName());
				if (product.getUnitCount() != null) {
					map.put("unitCount", "0");
				}
				if (product.getProductId() != null) {
					map.put("productId", product.getProductId().toString());
				}
				if (product.getIsOutOfStock()) {
					map.put("outOfStock", "true");
				} else {
					map.put("outOfStock", "false");
				}
				list.add(map);
			} else if (product.getUnitCount() < orderDetail.getQuantity()) {
				map.put("productName", product.getProductName());
				if (product.getUnitCount() != null) {
					map.put("unitCount", product.getUnitCount().toString());
				}
				if (product.getProductId() != null) {
					map.put("productId", product.getProductId().toString());
				}
				map.put("outOfStock", "true");
				list.add(map);
			} else if (product.getIsOutOfStock()) {
				map.put("outOfStock", "true");
				map.put("productName", product.getProductName());
				if (product.getProductId() != null) {
					map.put("productId", product.getProductId().toString());
				}
				list.add(map);
			} else if (!product.getStatus()) {
				map.put("status", "false");
				map.put("productName", product.getProductName());
				if (product.getProductId() != null) {
					map.put("productId", product.getProductId().toString());
				}
				list.add(map);
			}
		}

		if (!CommonUtils.IsNullOrEmpty(list)) {
			return ResponseHelper.getSuccessResponse(Constant.ORDER_CHECK_OUT_SUCCESSFULLY, list, 200,
					Constant.RESPONSE_SUCCESS);
		}
		logger.info("OrderServiceImpl checkOut----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ORDER_CHECK_OUT_SUCCESSFULLY, Constant.RESPONSE_EMPTY_DATA,
				200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response refundOrder(RefundRequest refundRequest) throws Exception {
		logger.info("OrderServiceImpl refundOrder----starts----"+refundRequest);
		Address shippingAddress = null;
		String stateName = null;
		User accessUser = userService.getUserByAccessToken();
		List<Buyer> buyerList = buyerRepository.findByUserUserId(accessUser.getUserId());
		Buyer activeUser = buyerList.size() > 0 ? buyerList.get(0) : null;

		if (null != activeUser) {
			Optional<Orders> orders = ordersRepository.findByOrderIdAndUserUserIdAndOrderStatus(
					refundRequest.getOrderId(), activeUser.getUser().getUserId(), Constant.ORDER_STATUS_DELIVERED);
			if (orders.isPresent()) {

				if (orders.get().getTransactionId() != null && !orders.get().getTransactionId().isEmpty()) {

//				int count = ordersRepository.updateOrderStatus(Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//							refundRequest.getOrderId(), CommonUtils.GetCurrentTimeStamp());
					int count = ordersRepository.updateOrderStatus(Constant.ORDER_STATUS_DELIVERED,
							refundRequest.getOrderId(), CommonUtils.GetCurrentTimeStamp());
					if (count == 0) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					User user = orders.get().getUser();// Send Refund Initiate order email
					if (user != null) {
						/*
						 * sendRefundOrderMail(refundRequest.getReason(),
						 * initiateRefundOrderEmailSubject,buyerInitiateRefundOrderEmailTemplate,orders.
						 * get(),sendMailtoAdminuser.getEmail());
						 * sendRefundOrderMail(refundRequest.getReason(),
						 * initiateRefundOrderEmailSubject,sellerInitiateRefundOrderEmailTemplate,orders
						 * .get(),sendMailtoAdmin orders.get().getVendor().getUser().getEmail() );
						 * sendRefundOrderMail(refundRequest.getReason(),
						 * initiateRefundOrderEmailSubject,adminInitiateRefundOrderEmailTemplate,orders.
						 * get(),sendMailtoAdmin);
						 */
						//BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserId(activeUser.getUser().getUserId());

						BuyerAddress buyerAddress = buyerAddressRepository.findByUserUserIdAndDefalt(activeUser.getUser().getUserId(),"Y");


						if (buyerAddress != null) {
							shippingAddress = buyerAddress.getAddress();
						}
						if (shippingAddress == null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SHIPPING_ADDRESS_NOT_FOUND,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						if (shippingAddress.getStateId() != null) {
							State state = stateRepository.findStateById(shippingAddress.getStateId());
							if (state != null) {
								stateName = state.getName();
							}
						}
						Lookup refundReasonLookup = lookupRepository.findLookupById(Integer.parseInt(refundRequest.getReason()));
						String refundReason;
						if (refundReasonLookup == null) {
							refundReason = refundRequest.getReason();
						} else {
							if ("other".equals(refundReasonLookup.getValue())) {
								refundReason = "(" + refundReasonLookup.getValue()  + ") - " + refundRequest.getComments();
							} else {
								refundReason = refundReasonLookup.getValue();
							}
						}
						sendRefundOrder(user, orders.get(), shippingAddress, stateName, orders.get(),
								refundReason, initiateRefundOrderEmailSubjectToBuyer,
								buyerInitiateRefundOrderEmailTemplate, sendMailtoAdmin/* user.getEmail() */, "buyer");
						sendRefundOrder(user, orders.get(), shippingAddress, stateName, orders.get(),
								refundReason, initiateRefundOrderEmailSubjectToSeller,
								sellerInitiateRefundOrderEmailTemplate, sendMailtoAdmin/* user.getEmail() */, "seller");
						sendRefundOrder(user, orders.get(), shippingAddress, stateName, orders.get(),
								refundReason, initiateRefundOrderEmailSubject,
								adminInitiateRefundOrderEmailTemplate, sendMailtoAdmin/* user.getEmail() */, "admin");
					}
					// Save Refund Details
					Refund refund = new Refund(Constant.REFUND_STATUS_PENDING, refundRequest.getReason(), refundRequest.getComments(),
							orders.get().getOrderId(), orders.get().getOrderAmount(), orders.get().getTransactionId(),
							orders.get().getUser().getMobileNumber(), orders.get().getUser().getEmail());
					refund = refundRepository.save(refund);

					if (refundRequest.getRefundImages() != null) {
						for (ImagesRequest imageRequest : refundRequest.getRefundImages()) {
							boolean isMoved = imageService.moveFilesFromS3(imageRequest.getImageId(),
									refund.getRefundId(), Constant.IMAGE_REFUND_TYPE, null);
							if (isMoved) {
								RefundImage RefundImages = new RefundImage();
								Images image = imageRepository.findByImageId(imageRequest.getImageId());
								RefundImages.setImage(image);
								RefundImages.setRefund(refund);
								RefundImages.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
								RefundImages.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
								refundImageRepository.save(RefundImages);

							} else {
								throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
										Constant.RESPONSE_EMPTY_DATA, 1001);
							}
						}

					}

				} else {
					// log.info("Order Transaction Shuuld not empty");
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}

			} else {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			logger.info("OrderServiceImpl refundOrder----ends----");
			return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.BUYER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

	}

	@Async("specificTaskExecutor")
	public void sendRefundOrder(User user, Orders order, Address shippingAddress, String stateName, Orders newOrder,
			String reason, String subject, String template, String toaddress, String role) {
		logger.info("OrderServiceImpl sendRefundOrder----starts----"+user,order,shippingAddress,stateName,newOrder,reason,subject,template,toaddress,role);
		try {
			List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
			List<Product> orderItemList = null;
			Double totalAmount = 0.0;
			Double totalOrderAmount = 0.0;
			// for(Orders order : orderList) {
			BuyerOrderResponse orderMail = new BuyerOrderResponse();
			orderItemList = new ArrayList<>();
			if (!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
				for (OrderItem orderItem : order.getOrderItems()) {
					if (orderItem != null) {
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						product.setQuantity(orderItem.getQuantity());
						Double productTotalAmount = 0.0;
						productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
						totalAmount = totalAmount + orderItem.getPrice();
						product.setTotalAmount(productTotalAmount);
						product.setProductTotalAmount(productTotalAmount);
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						orderItemList.add(product);
					}
				}
				orderMail.setDeliveryMode(order.getDeliveryMode());
				orderMail.setOrderNumber(order.getOrderNumber());
				orderMail.setOrderAmount(order.getOrderAmount());
				orderMail.setShippingCost(order.getShippingCost());
				orderMail.setTotalAmountWithShipping(order.getOrderAmount() + order.getShippingCost()+order.getTotalTax());
				totalOrderAmount = totalOrderAmount + orderMail.getTotalAmountWithShipping();
				orderMail.setTotalOrderAmount(totalOrderAmount);
				orderMail.setTotalTax(order.getTotalTax());
				orderMail.setTrackingNumber(order.getDeliveryCode());
				orderMail.setDeliveryCode(order.getDeliveryMode());
				orderMail.setVendorName(order.getVendor().getName());
				orderMail.setOrderPlacedOn(
						CommonUtils.getDay() + ", " + CommonUtils.timeStampFormat(order.getOrderDate()));
				orderMail.setProductList(orderItemList);
			}
			buyerOrder.add(orderMail);
			// }
			/*
			 * if(!CommonUtils.IsNullOrEmpty(buyerOrder)) { return buyerOrder; }
			 */
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("buyerOrder", buyerOrder);
			// mailMap.put("name", user.getFirstName()+" "+user.getLastName());
			if (role.equals("seller")) {
				mailMap.put("buyerName", user.getFirstName() + " " + user.getLastName());
				mailMap.put("name", newOrder.getVendor().getUser().getFirstName() + " "
						+ newOrder.getVendor().getUser().getLastName());
			} else if (role.equals("admin")) {
				mailMap.put("buyerName", user.getFirstName() + " " + user.getLastName());
				mailMap.put("name", "Admin");
			} else {
				mailMap.put("name", user.getFirstName() + " " + user.getLastName());
			}

			mailMap.put("line1", shippingAddress.getLine1());
			if (Strings.isNullOrEmpty(shippingAddress.getLine2())) {
				mailMap.put("line2", "");
			} else {
				mailMap.put("line2", shippingAddress.getLine2());
			}
			mailMap.put("city", shippingAddress.getCity());
			mailMap.put("totalOrderAmount", totalOrderAmount);
			mailMap.put("state", stateName);
			mailMap.put("reason", reason);
			mailMap.put("zipcode", shippingAddress.getZipcode());
			mailMap.put("country", shippingAddress.getCountry());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("orderCount", buyerOrder.size());
			mailMap.put("loginurl", buyerDomain);
			Template mailTemplate = config.getTemplate(template);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			// notificationMap.put("userMail", email);
			if (role.equals("seller")) {
				notificationMap.put("userMail", newOrder.getVendor().getUser().getEmail());
			} else if (role.equals("admin")) {
				notificationMap.put("userMail", toaddress);
			} else {
				notificationMap.put("userMail", newOrder.getUser().getEmail());
			}
			notificationMap.put("subject", subject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			log.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendRefundOrder----ends----");
	}

	private ShippoTransactionDetails createTransaction(String shipoTransId, Integer orderId) {
		logger.info("OrderServiceImpl createTransaction----starts----"+shipoTransId,orderId);
		// TODO Auto-generated method stub
		String tilePath = null;
		URL url;
		UUID uuid = UUID.randomUUID();
		ShippoTransactionDetails shippoTransactionDetails = shippoTransactionDetailsRepository
				.findByShippoid(Integer.parseInt(shipoTransId));
		if (null != shippoTransactionDetails.getLabel()) {
			if (shippoTransactionDetails.getLabel().isEmpty()) {
				Transaction transaction = CommonUtils.createTransaction(shippoTransactionDetails.getRateObjectId(),
						shippoKey);
				shippoTransactionDetails.setOrderId(orderId.toString());
				shippoTransactionDetails.setLabel(getS3url(transaction.getLabelUrl().toString(), shipoTransId));
				shippoTransactionDetails.setTrackingNumber(transaction.getTrackingNumber().toString());
				shippoTransactionDetails.setTransactionObject(transaction.getObjectId());
				shippoTransactionDetails.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				shippoTransactionDetails = shippoTransactionDetailsRepository.save(shippoTransactionDetails);
				logger.info("OrderServiceImpl createTransaction----ends----");
				return shippoTransactionDetails;
			}
		} else {
			return shippoTransactionDetails;
		}
		return null;
	}


	private String getS3url(String uri,String shipoTransId) {
		logger.info("OrderServiceImpl getS3url----starts----"+shipoTransId);
		logger.info("OrderServiceImpl getS3url----starts----"+uri);
		String tilePath = "";URL url;UUID uuid = UUID.randomUUID();String s3url ="";
		try {
			url = new URL(uri);
			String fileName = Paths.get((url).getPath()).getFileName().toString();
			String ext = FilenameUtils.getExtension(fileName);
			tilePath = lableFolder + shipoTransId + "/"+ uuid;
			MultipartFile resizeMultipartFile = new MultipartImage(CommonUtils.getFile(uri), fileName, fileName, ext, 100);
			s3url = amazonClient.uploadFile(resizeMultipartFile, tilePath, uuid + "." + ext);
			System.out.println(CommonUtils.getS3Url()+s3url);

		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		logger.info("OrderServiceImpl getS3url----ends----");
		return CommonUtils.getS3Url()+s3url;
	}

	private ShippoTransactionDetails saveTransaction(String shipoTransId, Integer orderId) {
		logger.info("OrderServiceImpl saveTransaction----starts----"+shipoTransId,orderId);
		// TODO Auto-generated method stub
		ShippoTransactionDetails shippoTransactionDetails = shippoTransactionDetailsRepository
				.findByShippoid(Integer.parseInt(shipoTransId));
		// Transaction transaction =
		// CommonUtils.createTransaction(shippoTransactionDetails.getRateObjectId(),shippoKey);
		shippoTransactionDetails.setOrderId(orderId.toString());
		shippoTransactionDetails.setLabel("");
		shippoTransactionDetails.setTrackingNumber("");
		shippoTransactionDetails.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		shippoTransactionDetails = shippoTransactionDetailsRepository.save(shippoTransactionDetails);
		logger.info("OrderServiceImpl saveTransaction----ends----");
		return shippoTransactionDetails;
	}

	public static BufferedImage resizeImage(final Image img, int width, int height) {
		logger.info("OrderServiceImpl resizeImage----starts----"+img,width,height);
		final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		final Graphics2D graphics2D = bufferedImage.createGraphics();
		graphics2D.setComposite(AlphaComposite.Src);
		// below three lines are for RenderingHints for better image quality at cost of
		// higher processing time
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics2D.drawImage(img, 0, 0, width, height, null);
		graphics2D.dispose();
		logger.info("OrderServiceImpl resizeImage----ends----");
		return bufferedImage;
	}

	@Override
	public Response sentReceipt(Integer id) {
		// TODO Auto-generated method stub
		List<Orders> orderList = new ArrayList<>();
		Orders orders = ordersRepository.findOrdersByOrderId(id);
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(orders.getUser().getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		orderList.add(orders);
		User userDetails = userRepository.findByUserId(orders.getUser().getUserId());
		Address shippingAddress = null;
		String stateName = null;
		BuyerAddress buyerAddress = buyerAddressRepository.findByAddressId(Integer.parseInt(orders.getAddressid()));
		if (buyerAddress != null) {
			shippingAddress = buyerAddress.getAddress();
		}
		if (shippingAddress.getStateId() != null) {
			State state = stateRepository.findStateById(shippingAddress.getStateId());
			if (state != null) {
				stateName = state.getName();
			}
		}
		Discount discount = null;
		if (orders.getParentOrderId() != null && orders.getParentOrderId() != 0) {
			Integer parentOrderId = orders.getParentOrderId();
			DiscountRedemption discountRedemption = discountRedemptionRepository.findByParentOrderId(parentOrderId);
			if (discountRedemption != null) {
				Integer discountId = discountRedemption.getDiscount().getId();
				discount = discountRepository.findDiscountById(discountId);
			}
		}
        sendSuccessfullPaymentOrderMail(userDetails, orderList, shippingAddress, stateName, discount);
		return ResponseHelper.getSuccessResponse("Mail sent to : "+userDetails.getEmail(), "", 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response exitingOrderDetailsMigration() throws Exception {
		logger.info("exitingOrderDetailsMigration method start");

		List<Orders> orderList = ordersRepository.findAll();
		logger.info("order list size:" + orderList.size());
		int count = 0;

		if (!CommonUtils.IsNullOrEmpty(orderList)) {

			for (Orders order : orderList) {

				// shipping state,stateCode migration exiting orders
				if (order.getShippingStateId() != null && order.getShippingStateId() != 0) {
					State state = stateRepository.findStateById(order.getShippingStateId());
					if (state != null) {
						order.setShipState(state.getName());
						order.setShippingStateCode(state.getStatecode());
						order = ordersRepository.save(order);
					}
				}

				// vendor address details update exiting orders
				if (order.getVendor() != null) {					
					VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndType(order.getVendor().getVendorId(),
							Constant.PRIMARY);
					if (vendorAddress != null) {
						Address address = vendorAddress.getAddress();
						if (address != null) {
							order.setVendorLine1(address.getLine1());
							order.setVendorLine2(address.getLine2());
							order.setVendorCity(address.getCity());
							order.setVendorDistrict(address.getDistrict());
							if (address.getStateId() != null) {
								State state = stateRepository.findStateById(address.getStateId());
								if (state != null) {
									order.setVendorState(state.getName());
									order.setVendorStateCode(state.getStatecode());
								}
							}
							order.setVendorZipcode(address.getZipcode());
							order.setVendorCountry(address.getCountry());
							order = ordersRepository.save(order);
						}						
					}
				}

				// pickup address details update on exiting orders
				if (order.getSellerPickupAddressId() != null && order.getSellerPickupAddressId() != 0
						&& order.getDeliveryMode().equals("Pick-Up")) {
					Address pickUpAddress = addressRepository.findAddressById(order.getSellerPickupAddressId());
					if (pickUpAddress != null) {
						order.setInstruction(pickUpAddress.getInstruction());
						order.setLocationName(pickUpAddress.getLocationName());
						order.setPickupLine1(pickUpAddress.getLine1());
						order.setPickupLine2(pickUpAddress.getLine2());
						order.setPickupCity(pickUpAddress.getCity());
						order.setPickupDistrict(pickUpAddress.getDistrict());
						if (pickUpAddress.getStateId() != null) {
							State state = stateRepository.findStateById(pickUpAddress.getStateId());
							if (state != null) {
								order.setPickupState(state.getName());
								order.setPickupStateCode(state.getStatecode());
							}
						}
						order.setPickupZipcode(pickUpAddress.getZipcode());
						order.setPickupCountry(pickUpAddress.getCountry());
						order = ordersRepository.save(order);
					}
				} else if (order.getDeliveryMode() != null && order.getDeliveryMode().equals("Pick-Up") && order.getSellerPickupAddressId() == null) {				
					VendorAddress vendorAddress = vendorAddressRepository
							.findByVendorVendorIdAndType(order.getVendor().getVendorId(), Constant.PRIMARY);
					if (vendorAddress != null) {
						Address address = vendorAddress.getAddress();
						if (address != null) {
							order.setInstruction(address.getInstruction());
							order.setLocationName(address.getLocationName());
							order.setPickupLine1(address.getLine1());
							order.setPickupLine2(address.getLine2());
							order.setPickupCity(address.getCity());
							order.setPickupDistrict(address.getDistrict());
							if (address.getStateId() != null) {
								State state = stateRepository.findStateById(address.getStateId());
								if (state != null) {
									order.setPickupState(state.getName());
									order.setPickupStateCode(state.getStatecode());
								}
							}
							order.setPickupZipcode(address.getZipcode());
							order.setPickupCountry(address.getCountry());
							order = ordersRepository.save(order);
						}
					}
				}
				
				
				// Exiting UOM details update
				if (order != null && order.getOrderItems() != null) {
					for (OrderItem orderItem : order.getOrderItems()) {
						Product product = productRepository.findByProductId(orderItem.getProduct().getProductId());
						if (product != null) {
							orderItem.setOrder(order);
							orderItem.setOrderId(order.getOrderId());
							orderItem.setUom(product.getUom().getName());
							orderItemRepository.save(orderItem);
						}
					}
				}
				count = count + 1;  
				logger.info("migration count:"+count);
			}
			logger.info("exitingOrderDetailsMigration method end..");
			return ResponseHelper.getSuccessResponse("order details migration successfully", "", 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Order details migration Failed!!",
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
	}

	@Override
	public Response getAllVendorOrdersStatusAndMode(String status, String mode, String searchString, Pagination pagination,
			String fromDate, String toDate) throws Exception {
		logger.info("OrderServiceImpl getAllVendorOrdersStatusAndMode ----starts----" + status, mode, searchString,
				pagination, fromDate, toDate);
		boolean validDate = false;
		Date startDate = null;
		Date endDate = null;
		VendorOrdersResponseListVO vendorOrdersResponseVO = new VendorOrdersResponseListVO();
		List<VendorOrdersResponseListVO> vendorOrdersResponseListVO = new ArrayList<>();
		VendorOrderResponseMap vendorOrderResponseMap = new VendorOrderResponseMap();
		String currentUserName = authenticationConfig.getLoginUserMail();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		int offset = 0;
		int limit = Constant.DEFAULT_PAGINATION_LIMIT;
		List<Map<String, String>> cardTransactionList = null;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		if (vendor != null) {
			Pageable paging = PageRequest.of(offset, limit);
			if (fromDate != null && toDate != null) {
				validDate = CommonUtils.endDateAfterStartDate1(fromDate, toDate);
				startDate = CommonUtils.convertDate(fromDate + " 00:00:00");
				endDate = CommonUtils.convertDate(toDate + " 23:59:00");
			}
			logger.info("validDate>>>>" + validDate);
			if (fromDate != null && toDate != null && !validDate) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_FROM_TO_DATE,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			List<Orders> list = new ArrayList<>();
			List<Orders> orderList = null;
			Integer totalCount = 0;
			List<Orders> orderListCount = new ArrayList<>();
			if (searchString != null) {
				if (status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.searchByOrderDt(vendor.getVendorId(), searchString.toLowerCase(),
								startDate, endDate, offset, limit);
						orderListCount = ordersRepository.searchByOrderDtCount(vendor.getVendorId(),
								searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.searchByOrder(vendor.getVendorId(), searchString.toLowerCase(),
								offset, limit);
						orderListCount = ordersRepository.searchByOrderCount(vendor.getVendorId(),
								searchString.toLowerCase());
					}
				} else if ((status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT))
						&& mode.equalsIgnoreCase(Constant.MODE_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.searchByOrderStatusDt(vendor.getVendorId(), status,
								searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusDtCount(vendor.getVendorId(), status,
								searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.searchByOrderStatus(vendor.getVendorId(), status,
								searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(), status,
								searchString.toLowerCase());
					}

				} else if ((status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND))
						&& mode.equalsIgnoreCase(Constant.MODE_STATUS_ALL)) {
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(),
								refundStatus, searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(),
								Constant.REFUND_STATUS_COMPLETED, searchString.toLowerCase());
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
					if (validDate) {
						orderList = ordersRepository.searchByOrderStatusDt(vendor.getVendorId(), status, mode,
								searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusDtCount(vendor.getVendorId(), status, mode,
								searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.searchByOrderStatus(vendor.getVendorId(), status, mode,
								searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(), status, mode,
								searchString.toLowerCase());
					}

				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {

//					List<String> refundStatus = Arrays.asList(new String[] { Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//							Constant.ORDER_STATUS_REFUNDED_APPROVED, Constant.ORDER_STATUS_REFUNDED_COMPLETED });
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								mode, searchString.toLowerCase(), startDate, endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(),
								refundStatus, mode, searchString.toLowerCase(), startDate, endDate);
					} else {
						orderList = ordersRepository.getRefundOrderWithSearchTxt(vendor.getVendorId(), refundStatus,
								mode, searchString.toLowerCase(), offset, limit);
						orderListCount = ordersRepository.searchByOrderStatusCount(vendor.getVendorId(),
								Constant.REFUND_STATUS_COMPLETED, mode, searchString.toLowerCase());
						// Constant.ORDER_STATUS_REFUNDED_COMPLETED, searchString.toLowerCase());

					}

				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			} else {

				if (status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.findByOrderAllStatusDt(vendor.getVendorId(), startDate, endDate,
								offset, limit);
						orderListCount = ordersRepository.findByOrderAllStatusDtCount(vendor.getVendorId(), startDate,
								endDate);

					} else {
						orderList = ordersRepository.findByVendorVendorIdOrderByOrderIdDesc(vendor.getVendorId(),
								paging);
						totalCount = ordersRepository.countByVendorVendorIdOrderByOrderIdDesc(vendor.getVendorId());
					}
				} else if ((status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT))
						&& mode.equalsIgnoreCase(Constant.MODE_STATUS_ALL)) {
					if (validDate) {
						orderList = ordersRepository.findByOrderStatusDt(vendor.getVendorId(), status, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.findByOrderStatusDtCount(vendor.getVendorId(), status,
								startDate, endDate);
					} else {
						orderList = ordersRepository.findByVendorVendorIdAndOrderStatusOrderByOrderIdDesc(
								vendor.getVendorId(), status, paging);
						totalCount = ordersRepository
								.countByVendorVendorIdAndOrderStatusOrderByOrderIdDesc(vendor.getVendorId(), status);
					}
				} else if ((status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND))
						&& mode.equalsIgnoreCase(Constant.MODE_STATUS_ALL)) {
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, startDate,
								endDate);
					} else {
						orderList = ordersRepository.findByVendorVendorIdAndRefundStatusInOrderByOrderIdDesc(
								vendor.getVendorId(), refundStatus, paging);
						totalCount = ordersRepository.countByVendorVendorIdAndRefundStatusInOrderByOrderIdDesc(
								vendor.getVendorId(), refundStatus);
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_CANCELLED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INPROGRESS)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_COMPLETED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_DELIVERED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_CREATED)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_ALL)
						|| status.equalsIgnoreCase(Constant.ORDER_STATUS_INSHIPMENT)) {
					if (validDate) {
						orderList = ordersRepository.findByOrderStatusDt(vendor.getVendorId(), status, mode, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.findByOrderStatusDtCount(vendor.getVendorId(), status, mode,
								startDate, endDate);
					} else {
						orderList = ordersRepository
								.findByVendorVendorIdAndOrderStatusAndDeliveryModeOrderByOrderIdDesc(
										vendor.getVendorId(), status, mode, paging);
						totalCount = ordersRepository
								.countByVendorVendorIdAndOrderStatusAndDeliveryModeOrderByOrderIdDesc(
										vendor.getVendorId(), status, mode);
					}
				} else if (status.equalsIgnoreCase(Constant.ORDER_STATUS_REFUND)) {
//					List<String> refundStatus = Arrays.asList(new String[] { Constant.ORDER_STATUS_REFUNDED_REQUESTED,
//							Constant.ORDER_STATUS_REFUNDED_APPROVED, Constant.ORDER_STATUS_REFUNDED_COMPLETED });
					List<String> refundStatus = Arrays.asList(new String[] { Constant.REFUND_STATUS_PENDING,
							Constant.REFUND_STATUS_APPROVED, Constant.REFUND_STATUS_COMPLETED });
					if (validDate) {
						orderList = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, mode, startDate,
								endDate, offset, limit);
						orderListCount = ordersRepository.getRefundOrder(vendor.getVendorId(), refundStatus, mode,
								startDate, endDate);
					} else {
						orderList = ordersRepository
								.findByVendorVendorIdAndRefundStatusInAndDeliveryModeOrderByOrderIdDesc(
										vendor.getVendorId(), refundStatus, mode, paging);
						totalCount = ordersRepository
								.countByVendorVendorIdAndRefundStatusInAndDeliveryModeOrderByOrderIdDesc(
										vendor.getVendorId(), refundStatus, mode);
					}
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}
			if (!CommonUtils.IsNullOrEmpty(orderList)) {
				List<Integer> shippingStateList = new ArrayList<>();
				List<State> stateDatailsList = new ArrayList<>();
				int vendorId = 0;
				for (Orders order : orderList) {
					shippingStateList.add(order.getShippingStateId());
				}
				vendorId = orderList.get(0).getVendor().getVendorId();
				if (shippingStateList != null) {
					stateDatailsList = stateRepository.findByIdIn(shippingStateList);
				}
				if (vendorId != 0) {
					VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndType(vendorId,
							Constant.PRIMARY);
					if (vendorAddress != null) {
						if (vendorAddress.getVendor().getVendorId().intValue() == vendorId) {
							vendor.setVendorAddress(vendorAddress.getAddress());
						}
					}
				}
				if (stateDatailsList != null) {
					for (Orders order : orderList) {
						for (State state : stateDatailsList) {
							if (order.getShippingStateId() == state.getId()) {
								order.setShippingState(state.getName());
							}
						}
						order.setOrderItems(order.getOrderItems());
						list.add(order);
					}
				}
			}
			if (!CommonUtils.IsNullOrEmpty(orderListCount)) {
				totalCount = orderListCount.size();
			}
			VendorOrderResponseList convertedOrder = VendorOrderConverterHelper.getResponseListFromEntityList(list,
					totalCount);
			Map<Integer, Orders> ordersMap = list.stream()
					.collect(Collectors.toMap(Orders::getOrderId, Function.identity()));

			List<String> transactionIdList = new ArrayList<>();
			List<String> orderIdList = new ArrayList<>();
			List<ShippoTransactionDetails> shippoTransactionDetailsList = new ArrayList<>();
			List<Integer> deliveryChargeIdList = new ArrayList<>();
			List<Integer> productIdList = new ArrayList<>();
			List<DeliveryCharge> deliveryChargeDetailsList = new ArrayList<>();
			List<ProductImage> productImageList = new ArrayList<ProductImage>();
			Map<Integer, Integer> orderProductMap = new HashMap<>();
			Map<Integer, Integer> orderDeliveryChargeMap = new HashMap<>();

			for (VendorOrderResponse response : convertedOrder.getOrderResponse()) {
				Orders orders = ordersMap.get(response.getId());
				transactionIdList.add(orders.getTransactionId().toString());
				orderIdList.add(orders.getOrderId().toString());
				if ("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
					if (orders.getDeliveryCharge() != null) {
						deliveryChargeIdList.add(orders.getDeliveryCharge().getDeliveryChargeId());
						orderDeliveryChargeMap.put(orders.getOrderId(),
								orders.getDeliveryCharge().getDeliveryChargeId());
					}
				}
				if (null != response && null != response.getOrderItemDetails()) {
					for (VendorOrderItemResponse item : response.getOrderItemDetails()) {
						if (null != item) {
							productIdList.add(item.getProductId());
							orderProductMap.put(orders.getOrderId(), item.getProductId());

						}
					}
				}
			}

			shippoTransactionDetailsList = shippoTransactionDetailsRepository.findByOrderIdIn(orderIdList);

			List<Object[]> resultList = buyerPaymentMethodRepository.getCardNumber(transactionIdList);
			if (resultList != null) {
				cardTransactionList = resultList.stream().map(result -> {
					Map<String, String> cardTransactionMap = new HashMap<>();
					cardTransactionMap.put("transactionId", (String) result[0]);
					cardTransactionMap.put("cardNumber", (String) result[1]);
					return cardTransactionMap;
				}).collect(Collectors.toList());
			}

			if (deliveryChargeIdList != null) {
				deliveryChargeDetailsList = deliveryChargeRepository.findByDeliveryChargeIdIn(deliveryChargeIdList);
			}

			if (productIdList != null) {
				productImageList = productImageRepository.findByProductProductIdInAndIsActive(productIdList, true);

			}

			for (VendorOrderResponse response : convertedOrder.getOrderResponse()) {
				Orders orders = ordersMap.get(response.getId());
				if (shippoTransactionDetailsList != null) {
					for (ShippoTransactionDetails shippoTransactionDetails : shippoTransactionDetailsList) {
						logger.info("shippoTransactionDetails===>" + orders.getOrderId().toString() + "===>"
								+ shippoTransactionDetails.getOrderId());
						if (shippoTransactionDetails != null && null != shippoTransactionDetails.getOrderId() && orders
								.getOrderId().intValue() == Integer.parseInt(shippoTransactionDetails.getOrderId())) {
							response.setShippo(shippoTransactionDetails);
						}
					}
				}

				if (cardTransactionList != null) {
					for (Map<String, String> cardTransactionMap : cardTransactionList) {
						logger.info("orders.getTransactionId()" + orders.getTransactionId() + "-->"
								+ cardTransactionMap.entrySet());
						if (null != cardTransactionMap.get("transactionId") && cardTransactionMap.get("transactionId")
								.equalsIgnoreCase(orders.getTransactionId())) {
							response.setCardNumber(cardTransactionMap.get("cardNumber"));
						}
					}
				}

				if (orders.getDeliveryMode() != null) {
					if ("Pick-Up".equalsIgnoreCase(orders.getDeliveryMode())) {
						response.setInstruction(orders.getInstruction());
						response.setLocationName(orders.getLocationName());
						response.setPickupLine1(orders.getPickupLine1());
						response.setPickupLine2(orders.getPickupLine2());
						response.setPickupCity(orders.getPickupCity());
						response.setPickupDistrict(orders.getPickupDistrict());
						response.setPickupState(orders.getPickupState());
						response.setPickupStateCode(orders.getPickupStateCode());
						response.setPickupZipcode(orders.getPickupZipcode());
						response.setPickupCountry(orders.getPickupCountry());
					}
					// Total delivery charge amount calculated
					if ("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
						if (deliveryChargeDetailsList != null) {
							for (DeliveryCharge deliveryOrders : deliveryChargeDetailsList) {
								if (deliveryOrders != null && orders.getDeliveryCharge() != null
										&& orderDeliveryChargeMap.get(orders.getOrderId()).intValue() == deliveryOrders
												.getDeliveryChargeId()) {
									Double totalDeliveryCharge = deliveryOrders.getDeliveryChargeAmt();
									response.setTotalDeliveryCharge(totalDeliveryCharge);
								}
							}
						}
					}
				}
				if (null != response && null != response.getOrderItemDetails()) {
					if (null != productImageList && !productImageList.isEmpty() && orderProductMap != null) {
						Integer orderId = orders.getOrderId();
						Integer productIdFromMap = orderProductMap.get(orderId);

						for (ProductImage productImage : productImageList) {
							if (productImage != null && productImage.getProduct() != null) {
								Integer productIdFromImage = productImage.getProduct().getProductId();

								if (productIdFromMap.equals(productIdFromImage)) {
									response.setProductImageUrl(productImage.getImage().getUrl());
									break;
								} else {
									response.setProductImageUrl("");
								}
							}
						}
					}
				}
				if (Constant.ORDER_STATUS_DELIVERED.equalsIgnoreCase(orders.getOrderStatus())) {
					if (!CommonUtils.IsNullOrEmpty(orders.getRefund())) {
						setRefundDetailsList(orders, response);
					}
				}
			}

			if (convertedOrder.getOrderResponse() != null) {
				Map<String, List<VendorOrderResponse>> vendorResponseMap = new LinkedHashMap<String, List<VendorOrderResponse>>(
						convertedOrder.getOrderResponse().size());
				vendorResponseMap = convertedOrder.getOrderResponse().stream()
						// .sorted(Comparator.comparing(VendorOrderResponse::getId).reversed())
						.collect(Collectors.groupingBy(VendorOrderResponse::getVendorName));

				vendorOrderResponseMap.setVendorResponseMap(vendorResponseMap);
				// vendorOrderResponseMap.setTotalCount(totalCount);
			}
			// VendorOrderConverterHelper.getResponseListFromEntity(list);
			if (vendorOrderResponseMap != null && !vendorOrderResponseMap.getVendorResponseMap().isEmpty()) {
				for (Map.Entry<String, List<VendorOrderResponse>> entry : vendorOrderResponseMap.getVendorResponseMap()
						.entrySet()) {
					vendorOrdersResponseVO.setSellerName(entry.getKey());
					vendorOrdersResponseVO.setVendorOrdersResponse(entry.getValue());
				}
				vendorOrdersResponseVO.setTotalCount(totalCount);
				vendorOrdersResponseListVO.add(vendorOrdersResponseVO);
			}
			logger.info("OrderServiceImpl getAllVendorOrdersStatusAndMode----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorOrdersResponseListVO, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
	}
	
	
	@Override
	public Response viewByReceipt(Integer id) throws Exception {
		logger.info("OrderServiceImpl viewByReceipt----starts----"+id);		
		Orders orders = ordersRepository.findOrdersByOrderId(id);
		if (orders == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		String cardNumber = null;
		String transactionId = orders.getTransactionId();
		BuyerPayment buyerPayment = buyerPaymentRepository.findByTransactionId(transactionId);
		if (buyerPayment != null) {
			BuyerPaymentMethods buyerPaymentMethods = buyerPaymentMethodRepository.findByStripeAccountId(buyerPayment.getStripeId());
			if (buyerPaymentMethods != null) {
				cardNumber = buyerPaymentMethods.getCardNumber();
			}
		}
		setVendorAddress(orders.getVendor());
		VendorOrderResponse vendorOrderResponse = VendorOrderConverterHelper.getResponseFromEntity(orders);
		if ("Pick-Up".equalsIgnoreCase(orders.getDeliveryMode())) {
			setPickupAddressOnVendorResponse(orders, vendorOrderResponse);
		}
		
		vendorOrderResponse.setShippo(shippoTransactionDetailsRepository.findByOrderId(vendorOrderResponse.getId().toString()));
		vendorOrderResponse.setCardNumber(cardNumber);
		setInstructionNameAndLocation(orders, vendorOrderResponse);
		if (null != vendorOrderResponse.getOrderItemDetails()) {
			for (VendorOrderItemResponse item : vendorOrderResponse.getOrderItemDetails()) {
				if (null != item) {
					List<ProductImage> productImageList = productImageRepository.findByProductProductIdAndIsActive(item.getProductId(), true);
					if (null !=productImageList && !productImageList.isEmpty()) {
						vendorOrderResponse.setProductImageUrl(productImageList.get(0).getImage().getUrl());
					} else {
						vendorOrderResponse.setProductImageUrl("");
					}
				}
			}
		}

		if(Constant.ORDER_STATUS_DELIVERED.equalsIgnoreCase(orders.getOrderStatus())) {
			if(!CommonUtils.IsNullOrEmpty(orders.getRefund())) {
				setRefundDetailsList(orders,vendorOrderResponse);
			}
		}
		
		if("Delivery".equalsIgnoreCase(orders.getDeliveryMode())) {
			setConnectedDeliveryOrders(orders, vendorOrderResponse);
		}
		logger.info("OrderServiceImpl viewByReceipt----ends----"+id);
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				vendorOrderResponse, 200, Constant.RESPONSE_SUCCESS);
	}
	
	
}