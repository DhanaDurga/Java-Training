package com.eatzos.service.impl;

import java.math.BigInteger;
import java.text.ParseException;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.helper.VendorScheduleHelper;
import com.eatzos.model.Address;
import com.eatzos.model.State;
import com.eatzos.model.User;
import com.eatzos.model.Vendor;
import com.eatzos.model.VendorAddress;
import com.eatzos.model.VendorSchedule;
import com.eatzos.repository.StateRepository;
import com.eatzos.repository.VendorAddressRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.repository.VendorScheduleRepository;
import com.eatzos.request.ProductRequest;
import com.eatzos.request.VendorScheduleRequest;
import com.eatzos.request.VendorScheduleSubRequest;
import com.eatzos.service.UserService;
import com.eatzos.service.VendorScheduleService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;

@Service(value = "vendorScheduleService")
public class VendorScheduleServiceImpl implements VendorScheduleService {
	
	private static final Logger logger = LoggerFactory.getLogger(VendorServiceImpl.class);
	
	@Autowired
	private VendorRepository vendorRepository;
	
	@Autowired
	private VendorScheduleRepository vendorScheduleRepository;
	
	@Autowired
	private VendorAddressRepository vendorAddressRepository;
	
	@Autowired
	private StateRepository stateRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;
	
	@Override
	public Response saveVendor(VendorScheduleRequest vendorScheduleRequest) throws Exception {

		logger.info("VendorScheduleServiceImpl saveVendor----starts----" + vendorScheduleRequest);
		String deliveryType = null;
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (vendorScheduleRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorScheduleRequest.getDays())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DAY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorScheduleRequest.getSlot())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorScheduleRequest.getDeliveryType())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_TYPE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorScheduleRequest.getFromTime())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.FROM_TIME_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorScheduleRequest.getToTime())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TO_TIME_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		vendorScheduleRequest.setFromTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getFromTime()));
		vendorScheduleRequest.setToTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getToTime()));
		String from = String
				.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getFromTime()));
		String to = String.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getToTime()));
		if (!CommonUtils.endTimeAfterStartTime(from, to)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.END_TIME_MUST_BE_GREATER_THAN_START_TIME,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		List<VendorSchedule> vendorScheduleSaveList = new ArrayList<>();
		VendorSchedule vendorSchedule = null;

		VendorSchedule vendorScheduleCheck = null;
		for (String day : vendorScheduleRequest.getDays()) {
			if (vendorScheduleRequest.getDeliveryType().equals("BOTH")) {
				for (int i = 1; i <= 2; i++) {
					if (i == 1) {
						deliveryType = Constant.DELIVERY;
					} else {
						deliveryType = Constant.PICKUP;
					}
					vendorSchedule = new VendorSchedule();
					if (day.equalsIgnoreCase(Constant.MONDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findByMondayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setMonday(Constant.MONDAY);
					}
					if (day.equalsIgnoreCase(Constant.TUESDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findByTuesdayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setTuesday(Constant.TUESDAY);
					}
					if (day.equalsIgnoreCase(Constant.WEDNESDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findByWednesdayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setWednesday(Constant.WEDNESDAY);
					}
					if (day.equalsIgnoreCase(Constant.THURSDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findByThursdayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setThursday(Constant.THURSDAY);
					}
					if (day.equalsIgnoreCase(Constant.FRIDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findByFridayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setFriday(Constant.FRIDAY);
					}
					if (day.equalsIgnoreCase(Constant.SATURDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findBySaturdayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setSaturday(Constant.SATURDAY);
					}
					if (day.equalsIgnoreCase(Constant.SUNDAY)) {
						vendorScheduleCheck = vendorScheduleRepository
								.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(day, deliveryType,
										vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
						if (vendorScheduleCheck != null) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
						List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
								.findBySundayAndDeliveryTypeAndVendorVendorId(day, deliveryType,
										existingVendor.getVendorId());
						if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
							for (VendorSchedule vendor : vendorScheduleList) {
								boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getFromTime());
								boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
										vendorScheduleRequest.getToTime(), vendor.getToTime());
								boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getFromTime());
								boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
										vendor.getToTime(), vendorScheduleRequest.getToTime());
								if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
									return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
											Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
								}
							}
						}
						vendorSchedule.setSunday(Constant.SUNDAY);
					}
					vendorSchedule.setSlot(vendorScheduleRequest.getSlot());

					vendorSchedule.setDeliveryType(deliveryType);
					vendorSchedule.setVendor(existingVendor);
					vendorSchedule.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorSchedule.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorSchedule.setFromTime(vendorScheduleRequest.getFromTime());
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
					LocalTime checkLocalTime = LocalTime.parse(vendorScheduleRequest.getToTime(), formatter);
					vendorSchedule.setToTime(checkLocalTime.minusMinutes(01).toString());
					if (deliveryType.equals("Pickup")) {
						VendorAddress vendorAddress = vendorAddressRepository
								.findByVendorVendorIdAndType(existingVendor.getVendorId(), Constant.PRIMARY);
						if (vendorAddress != null) {
							vendorSchedule.setVendorAddress(vendorAddress);
						}
					}
					vendorScheduleSaveList.add(vendorSchedule);
				}
			} else {

				vendorSchedule = new VendorSchedule();
				if (day.equalsIgnoreCase(Constant.MONDAY)) {
					vendorScheduleCheck = vendorScheduleRepository.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(
							day, vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
							existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findByMondayAndDeliveryTypeAndVendorVendorId(day, vendorScheduleRequest.getDeliveryType(),
									existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setMonday(Constant.MONDAY);
				}
				if (day.equalsIgnoreCase(Constant.TUESDAY)) {
					vendorScheduleCheck = vendorScheduleRepository.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(
							day, vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
							existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findByTuesdayAndDeliveryTypeAndVendorVendorId(day, vendorScheduleRequest.getDeliveryType(),
									existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setTuesday(Constant.TUESDAY);
				}
				if (day.equalsIgnoreCase(Constant.WEDNESDAY)) {
					vendorScheduleCheck = vendorScheduleRepository
							.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
									existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findByWednesdayAndDeliveryTypeAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setWednesday(Constant.WEDNESDAY);
				}
				if (day.equalsIgnoreCase(Constant.THURSDAY)) {
					vendorScheduleCheck = vendorScheduleRepository
							.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
									existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findByThursdayAndDeliveryTypeAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setThursday(Constant.THURSDAY);
				}
				if (day.equalsIgnoreCase(Constant.FRIDAY)) {
					vendorScheduleCheck = vendorScheduleRepository.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(
							day, vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
							existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findByFridayAndDeliveryTypeAndVendorVendorId(day, vendorScheduleRequest.getDeliveryType(),
									existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setFriday(Constant.FRIDAY);
				}
				if (day.equalsIgnoreCase(Constant.SATURDAY)) {
					vendorScheduleCheck = vendorScheduleRepository
							.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
									existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findBySaturdayAndDeliveryTypeAndVendorVendorId(day,
									vendorScheduleRequest.getDeliveryType(), existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setSaturday(Constant.SATURDAY);
				}
				if (day.equalsIgnoreCase(Constant.SUNDAY)) {
					vendorScheduleCheck = vendorScheduleRepository.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(
							day, vendorScheduleRequest.getDeliveryType(), vendorScheduleRequest.getSlot(),
							existingVendor.getVendorId());
					if (vendorScheduleCheck != null) {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
					List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
							.findBySundayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
									existingVendor.getVendorId());
					if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
						for (VendorSchedule vendor : vendorScheduleList) {
							boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getFromTime());
							boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
									vendorScheduleRequest.getToTime(), vendor.getToTime());
							boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getFromTime());
							boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(), vendor.getToTime(),
									vendorScheduleRequest.getToTime());
							if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
								return ResponseHelper.getSuccessResponse(Constant.TIME_ALREAY_AVAILABLE,
										Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
							}
						}
					}
					vendorSchedule.setSunday(Constant.SUNDAY);
				}
				vendorSchedule.setSlot(vendorScheduleRequest.getSlot());

				vendorSchedule.setDeliveryType(vendorScheduleRequest.getDeliveryType());
				vendorSchedule.setVendor(existingVendor);
				vendorSchedule.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				vendorSchedule.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				vendorSchedule.setFromTime(vendorScheduleRequest.getFromTime());
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US);
				LocalTime checkLocalTime = LocalTime.parse(vendorScheduleRequest.getToTime(), formatter);
				vendorSchedule.setToTime(checkLocalTime.minusMinutes(01).toString());
				if (deliveryType.equals("Pickup")) {
					VendorAddress vendorAddress = vendorAddressRepository
							.findByVendorVendorIdAndType(existingVendor.getVendorId(), Constant.PRIMARY);
					if (vendorAddress != null) {
						vendorSchedule.setVendorAddress(vendorAddress);
					}
				}
				vendorScheduleSaveList.add(vendorSchedule);
			}
		}
		vendorScheduleRepository.saveAll(vendorScheduleSaveList);
		logger.info("VendorScheduleServiceImpl saveVendor----ends----");
		return ResponseHelper.getSuccessResponse("",
				VendorScheduleHelper.getResponseListFromEntity(vendorScheduleSaveList), 200, Constant.RESPONSE_SUCCESS);

	}
	

	@Override
	public Response deleteById(VendorScheduleRequest vendorScheduleRequest) throws Exception {
		logger.info("VendorScheduleServiceImpl deleteById----starts----"+vendorScheduleRequest);
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(Strings.isNullOrEmpty(vendorScheduleRequest.getDay())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELETE_SCHEDULE_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		List<VendorSchedule> vendorSchedule = new ArrayList<>();
		if(!Strings.isNullOrEmpty(vendorScheduleRequest.getDeliveryType())) {
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.MONDAY)) {
				vendorSchedule = vendorScheduleRepository.findByMondayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.TUESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByTuesdayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.WEDNESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByWednesdayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.THURSDAY)) {
				vendorSchedule = vendorScheduleRepository.findByThursdayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.FRIDAY)) {
				vendorSchedule = vendorScheduleRepository.findByFridayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SATURDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySaturdayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SUNDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySundayAndSlotAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),vendorScheduleRequest.getDeliveryType(),existingVendor.getVendorId());
			}
		} else  if(vendorScheduleRequest.getSlot()!=null && vendorScheduleRequest.getSlot()!=0) {
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.MONDAY)) {
				vendorSchedule = vendorScheduleRepository.findByMondayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.TUESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByTuesdayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.WEDNESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByWednesdayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.THURSDAY)) {
				vendorSchedule = vendorScheduleRepository.findByThursdayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.FRIDAY)) {
				vendorSchedule = vendorScheduleRepository.findByFridayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SATURDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySaturdayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SUNDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySundayAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(),vendorScheduleRequest.getSlot(),existingVendor.getVendorId());
			}
		} else {
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.MONDAY)) {
				vendorSchedule = vendorScheduleRepository.findByMondayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.TUESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByTuesdayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.WEDNESDAY)) {
				vendorSchedule = vendorScheduleRepository.findByWednesdayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.THURSDAY)) {
				vendorSchedule = vendorScheduleRepository.findByThursdayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.FRIDAY)) {
				vendorSchedule = vendorScheduleRepository.findByFridayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SATURDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySaturdayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SUNDAY)) {
				vendorSchedule = vendorScheduleRepository.findBySundayAndVendorVendorId(vendorScheduleRequest.getDay(),existingVendor.getVendorId());
			}
		}
		if (CommonUtils.IsNullOrEmpty(vendorSchedule)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_SCHEDULE_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		for(VendorSchedule list : vendorSchedule) {
			//long dcount = vendorScheduleRepository.countByVendorVendorIdAndDeliveryType(existingVendor.getVendorId(),Constant.DELIVERY);
			if(list.getDeliveryType().equals(Constant.PICKUP)) {
				long count = deliveryOrscheduleCount(existingVendor, Constant.PICKUP);
				if(count == 1) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ATLEAST_ONE_PICP_VALUE_NEEDED, Constant.RESPONSE_EMPTY_DATA,
							1001);
				}
			}
			if(list.getDeliveryType().equals(Constant.DELIVERY)) {
				long count = deliveryOrscheduleCount(existingVendor, Constant.DELIVERY);
				if(count == 1) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ATLEAST_ONE_DELIVERY_VALUE_NEEDED, Constant.RESPONSE_EMPTY_DATA,
							1001);
				}
			}
		}
	    vendorScheduleRepository.deleteAll(vendorSchedule);
	    logger.info("VendorScheduleServiceImpl deleteById----ends----");
		return ResponseHelper.getSuccessResponse(Constant.DELETE_VENDOR_SCHEDULE, Collections.<String, Object>emptyMap(), 200,
				null);
		
	}

	public long deliveryOrscheduleCount(Vendor existingVendor, String deliveryType) {
		long count = vendorScheduleRepository.countByVendorVendorIdAndDeliveryType(existingVendor.getVendorId(),deliveryType);
		return count;
	}

	@Override
	public Response findById(Integer id) throws Exception {
		logger.info("VendorScheduleServiceImpl findById----starts----"+id);
		Optional<VendorSchedule> vendorSchedule;
		vendorSchedule = vendorScheduleRepository.findById(id);
		logger.info("VendorScheduleServiceImpl findById----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, VendorScheduleHelper.getResponseFromEntity(vendorSchedule.get()), 200, Constant.RESPONSE_SUCCESS);
	
	}

	@Override
	public Response findByVendorId(Integer vendorId) throws Exception {
		logger.info("VendorScheduleServiceImpl findByVendorId----starts----"+vendorId);
		List<VendorSchedule> vendorSchedule = new ArrayList<>();
		vendorSchedule = vendorScheduleRepository.findByVendorVendorId(vendorId);

		if (CommonUtils.IsNullOrEmpty(vendorSchedule)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_SCHEDULE_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		
		for(VendorSchedule vendorAddress : vendorSchedule) {
			if(vendorAddress.getVendorAddress()!=null) {
				List<VendorAddress> vendorAddressList = new ArrayList<>();
				vendorAddressList = vendorAddressRepository.findByVendorVendorId(vendorId);
				List<Address> addressList = new ArrayList<>();
				for(VendorAddress vendorAdd : vendorAddressList ) {
					if(vendorAdd.getAddress().getId().equals(vendorAddress.getVendorAddress().getAddress().getId())) {
						vendorAdd.getAddress().setSelected(true);
					}
					State state = stateRepository.findStateById(vendorAdd.getAddress().getStateId());
					if(state!=null) {
						vendorAdd.getAddress().setStateName(state.getName());
					}
					addressList.add(vendorAdd.getAddress());
				}
				//addressList.add(vendorAddress.getVendorAddress().getAddress());
				vendorAddress.setAddressList(addressList);
			}
		}
		 
		logger.info("VendorScheduleServiceImpl findByVendorId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, VendorScheduleHelper.getResponseListFromEntity(vendorSchedule), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getAllAddress(Integer vendorId) throws Exception {
		logger.info("VendorScheduleServiceImpl findByVendorId----starts----"+vendorId);
		List<VendorAddress> vendorAddressList = new ArrayList<>();
		List<Address> addressList = new ArrayList<>();
		vendorAddressList = vendorAddressRepository.findByVendorVendorId(vendorId);
		/*
		 * if (CommonUtils.IsNullOrEmpty(vendorSchedule)) { throw new
		 * BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_SCHEDULE_NOT_FOUND,
		 * Constant.RESPONSE_EMPTY_DATA, 1001); }
		 */
		for(VendorAddress vendorAddress : vendorAddressList) {
			vendorAddress.getAddress().setType(vendorAddress.getType());
			addressList.add(vendorAddress.getAddress());
		}
		logger.info("VendorScheduleServiceImpl findByVendorId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, addressList, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response findAll() throws Exception {
		logger.info("VendorScheduleServiceImpl findAll----starts----");
		List<VendorSchedule> list = new ArrayList<>();
		Iterable<VendorSchedule> vendorSchedule = vendorScheduleRepository.findAll();
		vendorSchedule.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_SCHEDULE_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("VendorScheduleServiceImpl findAll----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, VendorScheduleHelper.getResponseListFromEntity(list), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response addressUpdate(VendorScheduleRequest vendorScheduleRequest) throws Exception {
		logger.info("VendorServiceImpl addressUpdate----starts----");
		
		if(vendorScheduleRequest.getScheduleId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_SCHEDULE_ID_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(vendorScheduleRequest.getAddressId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ADDRESS_ID_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		VendorAddress address = vendorAddressRepository.findByAddressId(vendorScheduleRequest.getAddressId());

		if (address == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Optional<VendorSchedule> vendorSchedule = vendorScheduleRepository.findById(vendorScheduleRequest.getScheduleId());
		if(vendorSchedule!=null) {
			vendorSchedule.get().setVendorAddress(address);
		}
		vendorScheduleRepository.save(vendorSchedule.get());
		logger.info("VendorServiceImpl findVendorById----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ADDRESS_UPDATED,
				Constant.ADDRESS_UPDATED, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response saveVendorSchedule(VendorScheduleRequest vendorScheduleRequest) throws Exception {

		logger.info("VendorScheduleServiceImpl saveVendorSchedule----starts----" + vendorScheduleRequest);
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (vendorScheduleRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		List<VendorSchedule> vendorScheduleList = validation(vendorScheduleRequest,existingVendor);
		vendorScheduleRepository.saveAll(vendorScheduleList);
		logger.info("VendorScheduleServiceImpl saveVendorSchedule----ends----");
		return ResponseHelper.getSuccessResponse(Constant.VENDOR_SCHEDULE_CREATED, "" , 200, Constant.RESPONSE_SUCCESS);

	}
	
	public List<VendorSchedule> validation(VendorScheduleRequest vendorScheduleReq,Vendor existingVendor) throws ParseException {
		VendorSchedule vendorSchedule = null;
		List<VendorSchedule> vendorScheduleListVal = new ArrayList<>();
		for(VendorScheduleSubRequest vendorScheduleRequest :vendorScheduleReq.getVendorScheduleSubRequest()) {
			if(vendorScheduleRequest.getId()==null) {
				vendorSchedule = new VendorSchedule();
			} else {
				Optional<VendorSchedule> vendorScheduleOpt = vendorScheduleRepository.findById(vendorScheduleRequest.getId());
				vendorSchedule = vendorScheduleOpt.get();
				if(vendorSchedule==null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
							1001);
				}
			}
			if (StringUtils.isEmpty(vendorScheduleRequest.getDay())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DAY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getSlot())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getDeliveryType())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_TYPE_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getFromTime())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.FROM_TIME_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getToTime())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TO_TIME_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			vendorScheduleRequest.setFromTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getFromTime()));
			vendorScheduleRequest.setToTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getToTime()));
			String from = String
					.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getFromTime()));
			String to = String.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getToTime()));
			if (!CommonUtils.endTimeAfterStartTime(from, to)) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.END_TIME_MUST_BE_GREATER_THAN_START_TIME,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			if(vendorScheduleRequest.getDeliveryType().equals("Pickup" )) {

				if(vendorScheduleRequest.getAddressId() == null) {
					throw new BusinessException(Constant.RESPONSE_FAIL,
							Constant.ADDRESS_ID_REQUIRED, Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				VendorAddress vendorAddress = vendorAddressRepository.findByAddressId(vendorScheduleRequest.getAddressId());
				if(vendorAddress==null) {
					throw new BusinessException(Constant.RESPONSE_FAIL,
							Constant.PICK_UP_ADDRESS_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				vendorSchedule.setVendorAddress(vendorAddress);
			
			}
			VendorSchedule vendorScheduleCheck = null;
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.MONDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByMondayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByMondayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setMonday(Constant.MONDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.TUESDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByTuesdayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setTuesday(Constant.TUESDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.WEDNESDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByWednesdayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setWednesday(Constant.WEDNESDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.THURSDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByThursdayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setThursday(Constant.THURSDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.FRIDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByFridayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByFridayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setFriday(Constant.FRIDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SATURDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findBySaturdayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setSaturday(Constant.SATURDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SUNDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findBySundayAndDeliveryTypeAndSlotAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findBySundayAndDeliveryTypeAndVendorVendorId(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setSunday(Constant.SUNDAY);
			}
			vendorSchedule.setFromTime(vendorScheduleRequest.getFromTime());
			vendorSchedule.setToTime(vendorScheduleRequest.getToTime());
			vendorSchedule.setSlot(vendorScheduleRequest.getSlot());
			vendorSchedule.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			vendorSchedule.setDeliveryType(vendorScheduleRequest.getDeliveryType());
			vendorSchedule.setVendor(existingVendor);
			vendorScheduleListVal.add(vendorSchedule);
		}
		
		return vendorScheduleListVal;
	}
	
	public List<VendorSchedule> validationUpdate(VendorScheduleRequest vendorScheduleReq,Vendor existingVendor) throws ParseException {
		VendorSchedule vendorSchedule = null;
		List<VendorSchedule> vendorScheduleListVal = new ArrayList<>();
		for(VendorScheduleSubRequest vendorScheduleRequest :vendorScheduleReq.getVendorScheduleSubRequest()) {
			if(vendorScheduleRequest.getId()==null) {
				vendorSchedule = new VendorSchedule();
			} else {
				Optional<VendorSchedule> vendorScheduleOpt = vendorScheduleRepository.findById(vendorScheduleRequest.getId());
				vendorSchedule = vendorScheduleOpt.get();
				if(vendorSchedule==null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
							1001);
				}
			}
			if (StringUtils.isEmpty(vendorScheduleRequest.getDay())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DAY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getSlot())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
						1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getDeliveryType())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_TYPE_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getFromTime())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.FROM_TIME_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorScheduleRequest.getToTime())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TO_TIME_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			vendorScheduleRequest.setFromTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getFromTime()));
			vendorScheduleRequest.setToTime(CommonUtils.timeToRailwayTime(vendorScheduleRequest.getToTime()));
			String from = String
					.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getFromTime()));
			String to = String.valueOf(CommonUtils.railwayTimeToNormalTimeConversion(vendorScheduleRequest.getToTime()));
			if (!CommonUtils.endTimeAfterStartTime(from, to)) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.END_TIME_MUST_BE_GREATER_THAN_START_TIME,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			if(vendorScheduleRequest.getDeliveryType().equals("Pickup" )) {

				if(vendorScheduleRequest.getAddressId() == null) {
					throw new BusinessException(Constant.RESPONSE_FAIL,
							Constant.ADDRESS_ID_REQUIRED, Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				VendorAddress vendorAddress = vendorAddressRepository.findByAddressId(vendorScheduleRequest.getAddressId());
				if(vendorAddress==null) {
					throw new BusinessException(Constant.RESPONSE_FAIL,
							Constant.PICK_UP_ADDRESS_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				vendorSchedule.setVendorAddress(vendorAddress);
			
			}
			VendorSchedule vendorScheduleCheck = null;
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.MONDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByMondayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByMondayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setMonday(Constant.MONDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.TUESDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByTuesdayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByTuesdayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setTuesday(Constant.TUESDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.WEDNESDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByWednesdayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByWednesdayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setWednesday(Constant.WEDNESDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.THURSDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByThursdayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByThursdayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setThursday(Constant.THURSDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.FRIDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findByFridayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findByFridayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setFriday(Constant.FRIDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SATURDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findBySaturdayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findBySaturdayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setSaturday(Constant.SATURDAY);
			}
			if (vendorScheduleRequest.getDay().equalsIgnoreCase(Constant.SUNDAY)) {
				vendorScheduleCheck = vendorScheduleRepository
						.findBySundayAndDeliveryTypeAndSlotAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								vendorScheduleRequest.getSlot(), existingVendor.getVendorId(),vendorSchedule.getId());
				if (vendorScheduleCheck != null) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SLOT_ALREAY_AVAILABLE,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				List<VendorSchedule> vendorScheduleList = vendorScheduleRepository
						.findBySundayAndDeliveryTypeAndVendorVendorIdAndIdNot(vendorScheduleRequest.getDay(), vendorScheduleRequest.getDeliveryType(),
								existingVendor.getVendorId(),vendorSchedule.getId());
				if (!CommonUtils.IsNullOrEmpty(vendorScheduleList)) {
					for (VendorSchedule vendor : vendorScheduleList) {
						boolean fromTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getFromTime());
						boolean toTimeCheck = CommonUtils.checkTime(vendorScheduleRequest.getFromTime(),
								vendorScheduleRequest.getToTime(), vendor.getToTime());
						boolean fromTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getFromTime());
						boolean toTimeCheckTime = CommonUtils.checkTime(vendor.getFromTime(),
								vendor.getToTime(), vendorScheduleRequest.getToTime());
						if (fromTimeCheck || toTimeCheck || fromTimeCheckTime || toTimeCheckTime) {
							throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TIME_ALREAY_AVAILABLE,
									Constant.RESPONSE_EMPTY_DATA, 1001);
						}
					}
				}
				vendorSchedule.setSunday(Constant.SUNDAY);
			}
			vendorSchedule.setFromTime(vendorScheduleRequest.getFromTime());
			vendorSchedule.setToTime(vendorScheduleRequest.getToTime());
			vendorSchedule.setSlot(vendorScheduleRequest.getSlot());
			vendorSchedule.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			vendorSchedule.setDeliveryType(vendorScheduleRequest.getDeliveryType());
			vendorSchedule.setVendor(existingVendor);
			vendorScheduleListVal.add(vendorSchedule);
		}
		
		return vendorScheduleListVal;
	}
	
	@Override
	public Response updateVendorSchedule(VendorScheduleRequest vendorScheduleRequest) throws Exception {
		logger.info("VendorScheduleServiceImpl saveVendorSchedule----starts----"+vendorScheduleRequest);
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (vendorScheduleRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		List<VendorSchedule> vendorScheduleList = validationUpdate(vendorScheduleRequest,existingVendor);
		vendorScheduleRepository.saveAll(vendorScheduleList);
		logger.info("VendorScheduleServiceImpl saveVendorSchedule----ends----");
		return ResponseHelper.getSuccessResponse(Constant.VENDOR_SCHEDULE_UPDATED, "" , 200, Constant.RESPONSE_SUCCESS);
	
	}
	
	@Override
	public Response checkPickupOrDeliveryExist(String scheduleType) throws Exception {
		logger.info("VendorScheduleServiceImpl checkPickupOrDeliveryExist----starts----");
		int deliveryCount = 0;
		int pickupCount = 0;
		User accessUser = authenticationConfig.getUserByAccessToken();
		boolean flag = false;
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		List<Object[]> countByVendorList = vendorScheduleRepository
				.countByVendorAndDeliveryType(existingVendor.getVendorId());
		if (countByVendorList != null && countByVendorList.size() > 0) {
			for (Object[] countByVendor : countByVendorList) {
				String deliveryType = (String) countByVendor[0];
				int typeCount = ((BigInteger) countByVendor[1]).intValue();
				if (deliveryType.equals(Constant.PICKUP)) {
					pickupCount = typeCount;
				}
				if (deliveryType.equals(Constant.DELIVERY)) {
					deliveryCount = typeCount;
				}
			}
		}

		if (deliveryCount == 0 && pickupCount == 0) {
			flag = true;
			return ResponseHelper.getSuccessResponse(Constant.SCHEDULE_NOT_EXIT, flag, 200, null);
		}

		if (!Strings.isNullOrEmpty(scheduleType) && scheduleType.equals(Constant.PICKUP) && pickupCount > 0) {
			flag = false;
			return ResponseHelper.getSuccessResponse(Constant.PICKUP_VALID, flag, 200, null);
		}

		if (!Strings.isNullOrEmpty(scheduleType) && scheduleType.equals(Constant.DELIVERY) && deliveryCount > 0) {
			flag = false;
			return ResponseHelper.getSuccessResponse(Constant.DELIVERY_VALID, flag, 200, null);
		}

		if (deliveryCount == 0 || pickupCount == 0) {
			if (deliveryCount == 0) {
				flag = true;
				return ResponseHelper.getSuccessResponse(Constant.DELIVERY_SCHEDULE_NOT_EXIT, flag, 200, null);
			}
			if (pickupCount == 0) {
				flag = true;
				return ResponseHelper.getSuccessResponse(Constant.PICKUP_SCHEDULE_NOT_EXIT, flag, 200, null);
			}
		}
		logger.info("VendorScheduleServiceImpl checkPickupOrDeliveryExist----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PICKUP_DELIVERY_VALID, flag, 200, null);

	}

}
