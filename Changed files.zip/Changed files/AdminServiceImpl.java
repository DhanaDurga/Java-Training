package com.eatzos.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;


import com.eatzos.response.OrderCountIndividualResponse;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.multipart.MultipartFile;

import com.eatzos.request.ConfigRequestVO;
import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.AmazonClient;
import com.eatzos.helper.AvalaraHelper;
import com.eatzos.model.AvalaraTaxCode;
import com.eatzos.helper.NotificationHelper;
import com.eatzos.helper.ProductConverterHelper;
import com.eatzos.helper.ReportHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.model.Address;
import com.eatzos.model.BuyerAddress;
import com.eatzos.model.Config;
import com.eatzos.model.CurrentVersion;
import com.eatzos.model.DeliveryTypeDAO;
import com.eatzos.model.Images;
import com.eatzos.model.OrderItem;
import com.eatzos.model.Orders;
import com.eatzos.model.Product;
import com.eatzos.model.ProductAuditTrail;
import com.eatzos.model.ProductImage;
import com.eatzos.model.Registration;
import com.eatzos.model.SellerPayment;
import com.eatzos.model.ShipmentProgressDtlDAO;
import com.eatzos.model.ShippoTransactionDetails;
import com.eatzos.model.State;
import com.eatzos.model.User;
import com.eatzos.model.Vendor;
import com.eatzos.model.VendorImage;
import com.eatzos.repository.AddressRepository;
import com.eatzos.repository.AdminRepository;
import com.eatzos.repository.AvalaraTaxCodeRepository;
import com.eatzos.repository.ConfigRepository;
import com.eatzos.repository.CurrentVersionRepository;
import com.eatzos.repository.ImageRepository;
import com.eatzos.repository.OrdersRepository;
import com.eatzos.repository.ProductAuditTrailRepository;
import com.eatzos.repository.ProductImageRepository;
import com.eatzos.repository.ProductRepository;
import com.eatzos.repository.ProductSearchRepository;
import com.eatzos.repository.RegistrationRepository;
import com.eatzos.repository.SellerPaymentRepository;
import com.eatzos.repository.ShippoTransactionDetailsRepository;
import com.eatzos.repository.StateRepository;
import com.eatzos.repository.UserImageRepository;
import com.eatzos.repository.UserRepository;
import com.eatzos.repository.UserRoleRepository;
import com.eatzos.repository.VendorImageRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.request.FeaturedSellerImageRequest;
import com.eatzos.request.FeedBackRequest;
import com.eatzos.request.OrderRequest;
import com.eatzos.request.Pagination;
import com.eatzos.request.ProductUpdateRequest;
import com.eatzos.request.ReportSearchRequest;
import com.eatzos.response.AdminDashboardResponse;
import com.eatzos.response.AdminResponse;
import com.eatzos.response.BuyerOrderResponse;
import com.eatzos.response.OrderCountResponse;
import com.eatzos.response.SellerPaymentResponse;
import com.eatzos.response.ShippoTransactionResponse;
import com.eatzos.response.ShippoTransactionResponseList;
import com.eatzos.response.VendorOrdersDTO;
import com.eatzos.response.VendorProductResponse;
import com.eatzos.response.VersionHistoryResponse;
import com.eatzos.service.AdminService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;

import freemarker.template.Configuration;
import freemarker.template.Template;
import com.eatzos.response.AvalaraTaxCodeResponse;
import com.eatzos.response.VendorResponseDTO;
import com.eatzos.model.UserImage;
import com.eatzos.model.UserRole;

@Service(value = "adminService")
public class AdminServiceImpl implements AdminService {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

	@Autowired
	private TokenStore tokenStore;
	
	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private ShippoTransactionDetailsRepository shippoTransactionDetailsRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RegistrationRepository registrationRepository;

	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	ProductImageRepository productImageRepository;
	
	@Autowired
	private UserService userService;

	@Autowired
	private OrdersRepository ordersRepository;

	@Autowired
	private SellerPaymentRepository sellerPaymentRepository;
	
	@Autowired
	private CurrentVersionRepository versionrepository;
	
	@Autowired
	private ProductSearchRepository productSearchRepository;
	
	@Autowired
	private ProductAuditTrailRepository productAuditTrailRepository;
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private StateRepository stateRepository;
	
	@Autowired
	private AvalaraTaxCodeRepository avalaraTaxCodeRepository;

	@Value("${transaction.failed.count}")
	private Integer transactionFaliedCount;
	
	@Value("${mail.FeedBackTemplate.template}")
	private String feedBackEmailTemplate;

	@Value("${mail.FeedBackTemplate.subject}")
	private String feedBackEmailSubject;
	
	@Value("${mail.ProductRejectTemplate.template}")
	private String productRejectTemplate;
	
	@Value("${mail.productInactivateTemplate.template}")
	private String productInactivateTemplate;
	
	@Value("${mail.admin.user}")
	private String adminMail;
	
	@Value("${eatzos.website.url}")
	private String webSiteUrl;
	
	@Value("${buyer.support.faq}")
	private String supportFAQ;
	
	@Value("${googleMap.api.key}")
	private String googleMapAPIKey;
	
	@Autowired
	private Configuration config;

	@Autowired
	NotificationHelper notificationHelper;
	
	@Autowired
	ConfigRepository configRepository;
	
	@Autowired
	AmazonClient amazonClient;
	
	@Autowired
	ImageServiceImpl imageService;
	
	@Autowired
	ImageRepository imageRepository;	
	
	@Autowired
	VendorImageRepository vendorImageRepository;
	
	@Autowired
	private UserImageRepository userImageRepository;
	
    @Autowired
	private UserRoleRepository userRoleRepository;
	
	@Value("${s3.image.folder}")
	private String imageFolder;
	
	@Value("${s3.vendor.folder}")
	private String vendorFolder;
	
	@Value("${s3.user.folder}")
	private String userFolder;
	
	@Value("${aws.s3.bucket}")
	private String bucketName;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;
	

	@Override
	public void getAllVendorExport(HttpServletResponse response, ReportSearchRequest reportSearchRequest)
			throws Exception {
		logger.info("AdminServiceImpl getAllVendorExport----starts----"+response,reportSearchRequest);
		List<Vendor> list = new ArrayList<>();
		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus()) && reportSearchRequest.getStatus().equals("1")) {
			list = vendorRepository.findByUserStatus(1);
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())
				&& reportSearchRequest.getStatus().equals("0")) {
			list = vendorRepository.findByUserStatus(0);
		} else {
			list = vendorRepository.getAllVendors();
		}
		vendorToCSV(response, list);
		logger.info("AdminServiceImpl getAllVendorExport----ends----");
	}

	public void vendorToCSV(HttpServletResponse httpResponse, List<Vendor> vendorList) {
		logger.info("AdminServiceImpl vendorToCSV----starts----"+httpResponse,vendorList);
		try (CSVPrinter csvPrinter = new CSVPrinter(httpResponse.getWriter(), CSVFormat.DEFAULT.withHeader("Name",
				"Company", "Phone Number", "Email Address", "Registration Status"));) {
			for (Vendor vendor : vendorList) {
				List<String> data = Arrays.asList(
						vendor.getUser().getFirstName() + " " + vendor.getUser().getLastName(), vendor.getName(),
						vendor.getUser().getMobileNumber(), vendor.getUser().getEmail(), "Completed");
				csvPrinter.printRecord(data);
			}
			httpResponse.setContentType("text/csv");
			httpResponse.setHeader("Content-Disposition", "attachment; file=" + getFileName("csv"));
			csvPrinter.flush();
			logger.info("AdminServiceImpl vendorToCSV----ends----");
		} catch (Exception e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Writing CSV error!", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
	}

	public void buyerToCSV(HttpServletResponse httpResponse, List<User> userList, List<Registration> registrationList) {
		logger.info("AdminServiceImpl getAllVendorExport----starts----"+httpResponse,userList,registrationList);
		try (CSVPrinter csvPrinter = new CSVPrinter(httpResponse.getWriter(),
				CSVFormat.DEFAULT.withHeader("Name", "Phone Number", "Email Address", "Registration Status"));) {
			if (!CommonUtils.IsNullOrEmpty(userList)) {
				for (User user : userList) {
					List<String> data = Arrays.asList(user.getFirstName() + " " + user.getLastName(),
							user.getMobileNumber(), user.getEmail(), "Completed");
					csvPrinter.printRecord(data);
				}
			}
			if (!CommonUtils.IsNullOrEmpty(registrationList)) {
				for (Registration registration : registrationList) {
					List<String> data = Arrays.asList(registration.getFirstName() + " " + registration.getLastName(),
							registration.getMobile(), registration.getEmail(), "In-Completed");
					csvPrinter.printRecord(data);
				}
			}
			httpResponse.setContentType("text/csv");
			httpResponse.setHeader("Content-Disposition", "attachment; file=" + getFileName("csv"));
			csvPrinter.flush();
		} catch (Exception e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Writing CSV error!", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("AdminServiceImpl getAllVendorExport----ends----");
	}

	private String getFileName(String extn) {
		logger.info("AdminServiceImpl getFileName----starts----"+extn);
		String todayDate = "";
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddYYYY");
		todayDate = simpleDateFormat.format(date);
		logger.info("AdminServiceImpl getFileName----ends----");
		return "student_report" + todayDate + "." + extn;
	}

	@Override
	public void getAllBuyerExport(HttpServletResponse response, ReportSearchRequest reportSearchRequest)
			throws Exception {
		logger.info("AdminServiceImpl getAllBuyerExport----starts----"+response,reportSearchRequest);
		List<User> list = new ArrayList<>();
		List<Integer> vendor = vendorRepository.getAllVendor();
		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus()) && reportSearchRequest.getStatus().equals("1")) {
			list = userRepository.findByUserIdNotInAndStatus(vendor, 1);
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())
				&& reportSearchRequest.getStatus().equals("0")) {
			list = userRepository.findByUserIdNotInAndStatus(vendor, 0);
		} else {
			list = userRepository.findByUserIdNotIn(vendor);
		}
		buyerToCSV(response, list, null);
		logger.info("AdminServiceImpl getAllBuyerExport----ends----");
	}

	@Override
	public Response getAllBuyer(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getAllBuyer----starts----"+reportSearchRequest);
		long totalCount = 0;
		Page<User> pages = null;
		List<User> list = new ArrayList<>();
		Sort sort = null;
		if (!Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			sort = Sort.by("createdAt").descending();
		}
		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);
		List<Integer> vendor = vendorRepository.getAllVendor();
		vendor =vendor.parallelStream().filter(i->i!=null).collect(Collectors.toList());

		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())) {
			if (reportSearchRequest.getStatus().equals("1")) {
				pages = userRepository.findByUserIdNotInAndStatus(vendor, 1, paging);
			} else if (reportSearchRequest.getStatus().equals("0")) {
				pages = userRepository.findByUserIdNotInAndStatus(vendor, 0, paging);
			}
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getSearchText())) {
			list = userRepository.getUser(reportSearchRequest.getSearchText(), vendor,
					reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize());
			totalCount = userRepository.getUserCount(reportSearchRequest.getSearchText(), vendor);
		} else {
			pages = userRepository.findByUserIdNotIn(vendor, paging);
		}

		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			totalCount = pages.getTotalElements();
			list = pages.getContent();
			
		}
		logger.info("AdminServiceImpl getAllBuyer----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ReportHelper.getResponseListFromEntity(list, totalCount), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getAllVendor(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getAllVendor----starts----"+reportSearchRequest);
		long totalCount = 0;
		Page<Vendor> pages = null;
		List<Vendor> list = new ArrayList<>();
		Sort sort = null;
		if (!Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			sort = Sort.by("createdAt").descending();
		}
		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);
		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())) {
			if (reportSearchRequest.getStatus().equals("1")) {
				pages = vendorRepository.findByUserStatus(1, paging);
			} else if (reportSearchRequest.getStatus().equals("0")) {
				pages = vendorRepository.findByUserStatus(0, paging);
			}else if (reportSearchRequest.getStatus().equals("2")){
				
				pages = vendorRepository.findAll(paging);
				
				if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
					
					list =pages.getContent().parallelStream().filter(v -> !(v.getPaymentStatus() && v.getProfileStatus() && v.getAddressStatus() && v.getScheduleStatus()))
					.collect(Collectors.toList());
					totalCount = list.size();
					return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
							ReportHelper.getResponseListFromVendorEntity(list, totalCount), 200, Constant.RESPONSE_SUCCESS);
				}
						
			}
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getSearchText())) {
			list = vendorRepository.getVendorUser(reportSearchRequest.getSearchText(),
					reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize());
			totalCount = vendorRepository.getVendorUserCount(reportSearchRequest.getSearchText());
		} else {
			if (reportSearchRequest != null && reportSearchRequest.getSortKey() != null
					&& !reportSearchRequest.getSortKey().isEmpty()
					&& reportSearchRequest.getSortKey().equals(Constant.FIRST_NAME)
					|| reportSearchRequest.getSortKey().equals(Constant.MOBILE_NUMBER)
					|| reportSearchRequest.getSortKey().equals(Constant.EMAIL)
					|| reportSearchRequest.getSortKey().equals(Constant.IS_ACTIVE)) {
				pages = vendorRepository.findUsersDetails(paging);
			} else {
				pages = vendorRepository.findAll(paging);
			}			
		}

		// vendorList.iterator().forEachRemaining(list::add);
		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			totalCount = pages.getTotalElements();
			list = pages.getContent();
		}
		logger.info("AdminServiceImpl getAllVendor----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ReportHelper.getResponseListFromVendorEntity(list, totalCount), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getAllCount(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getAllCount----starts----"+reportSearchRequest);
		List<AdminResponse> adminResponse = null;
		if (Strings.isNullOrEmpty(reportSearchRequest.getEndDate())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.END_DATE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getStartDate())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.START_DATE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getType())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TYPE_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (reportSearchRequest.getType().equalsIgnoreCase("vendor")) {
			adminResponse = adminRepository.getVendor(reportSearchRequest);
		} else if (reportSearchRequest.getType().equalsIgnoreCase("buyer")) {
			adminResponse = adminRepository.getVendor(reportSearchRequest);
		} else if (reportSearchRequest.getType().equalsIgnoreCase("product")) {
			adminResponse = adminRepository.getProduct(reportSearchRequest);
		} else {
			adminResponse = adminRepository.getRegisteredUser(reportSearchRequest);
		}
		logger.info("AdminServiceImpl getAllCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, adminResponse, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getOrderCount() throws Exception {
		logger.info("AdminServiceImpl getOrderCount----starts----");
		String loginMail = authenticationConfig.getLoginUserMail();
		User user = userRepository.findByEmail(loginMail);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		System.out.println(loginMail);
		OrderCountResponse orderCountResponse = new OrderCountResponse();

		//List<Orders> vendorOrders = ordersRepository.findByVendorVendorId(vendor.getVendorId());
		List<VendorOrdersDTO> vendorOrders= ordersRepository.fetchVendorOrders(vendor.getVendorId());
		List<String> openOrderStatus = new ArrayList<>();
		openOrderStatus.add("NEW");
		openOrderStatus.add("CONFIRMED");
		openOrderStatus.add("INPROGRESS");
		openOrderStatus.add("INSHIPMENT");

		List<String> refundOrderStatus = new ArrayList<>();
		refundOrderStatus.add("PENDING");
		refundOrderStatus.add("APPROVED");
		refundOrderStatus.add("COMPLETED");
		refundOrderStatus.add("REJECTED");

		List<String> inShipmentOpenOrderStatus = new ArrayList<>(openOrderStatus);
		inShipmentOpenOrderStatus.remove("INSHIPMENT");

		List<String> deliveredOrderStatus = new ArrayList<>();
		deliveredOrderStatus.add("COMPLETED");
		deliveredOrderStatus.add("DELIVERED");

		// Delivery orders section
		long openDeliveryOrders = vendorOrders.stream()
				.filter(orders -> openOrderStatus.contains(orders.getOrderStatus()) && "D".equals(orders.getSelectedDeliveryType()))
				.count();

		long cancelledDeliveryOrders = vendorOrders.stream()
				.filter(orders -> "CANCELLED".equals(orders.getOrderStatus()) && "D".equals(orders.getSelectedDeliveryType()))
				.count();

//		long refundDeliveryOrders = vendorOrders.stream()
//				.filter(orders -> refundOrderStatus.contains(orders.getOrderStatus()) && "D".equals(orders.getSelectedDeliveryType()))
//				.count();
		
		long refundDeliveryOrders = vendorOrders.stream()
		        .filter(orders -> refundOrderStatus.stream().anyMatch(status -> hasRefundWithStatus(orders, status)) && "D".equals(orders.getSelectedDeliveryType()))
		        .count();


		long deliveredDeliveryOrders = vendorOrders.stream()
				.filter(orders -> deliveredOrderStatus.contains(orders.getOrderStatus()) && "D".equals(orders.getSelectedDeliveryType()))
				.count();

		long allDeliveryOrders = vendorOrders.stream()
				.filter(orders -> "D".equals(orders.getSelectedDeliveryType()))
				.count();

		// Pickup orders section
		long openPickupOrders = vendorOrders.stream()
				.filter(orders -> openOrderStatus.contains(orders.getOrderStatus()) && "P".equals(orders.getSelectedDeliveryType()))
				.count();

		long cancelledPickupOrders = vendorOrders.stream()
				.filter(orders -> "CANCELLED".equals(orders.getOrderStatus()) && "P".equals(orders.getSelectedDeliveryType()))
				.count();

		long refundPickupOrders = vendorOrders.stream()
				.filter(orders -> refundOrderStatus.stream().anyMatch(status -> hasRefundWithStatus(orders, status)) && "P".equals(orders.getSelectedDeliveryType()))
				.count();

		long deliveredPickupOrders = vendorOrders.stream()
				.filter(orders -> deliveredOrderStatus.contains(orders.getOrderStatus()) && "P".equals(orders.getSelectedDeliveryType()))
				.count();

		long allPickupOrders = vendorOrders.stream()
				.filter(orders -> "P".equals(orders.getSelectedDeliveryType()))
				.count();

		// Shipping orders section
		long openShippingOrders = vendorOrders.stream()
				.filter(orders -> inShipmentOpenOrderStatus.contains(orders.getOrderStatus()) && "S".equals(orders.getSelectedDeliveryType()))
				.count();

		long inShipmentShippingOrders = vendorOrders.stream()
				.filter(orders -> "INSHIPMENT".equals(orders.getOrderStatus()) && "S".equals(orders.getSelectedDeliveryType()))
				.count();

		long cancelledShippingOrders = vendorOrders.stream()
				.filter(orders -> "CANCELLED".equals(orders.getOrderStatus()) && "S".equals(orders.getSelectedDeliveryType()))
				.count();

		long refundShippingOrders = vendorOrders.stream()
				.filter(orders -> refundOrderStatus.stream().anyMatch(status -> hasRefundWithStatus(orders, status)) && "S".equals(orders.getSelectedDeliveryType()))
				.count();

		long deliveredShippingOrders = vendorOrders.stream()
				.filter(orders -> deliveredOrderStatus.contains(orders.getOrderStatus()) && "S".equals(orders.getSelectedDeliveryType()))
				.count();

		long allShippingOrders = vendorOrders.stream()
				.filter(orders -> "S".equals(orders.getSelectedDeliveryType()))
				.count();

		// All orders section
		long allOpenOrders = vendorOrders.stream()
				.filter(orders -> inShipmentOpenOrderStatus.contains(orders.getOrderStatus()))
				.count();

		long allInShipmentOrders = vendorOrders.stream()
				.filter(orders -> "INSHIPMENT".equals(orders.getOrderStatus()))
				.count();

		long allCancelledOrders = vendorOrders.stream()
				.filter(orders -> "CANCELLED".equals(orders.getOrderStatus()))
				.count();

		long allRefundOrders = vendorOrders.stream()
				.filter(orders -> refundOrderStatus.stream().anyMatch(status -> hasRefundWithStatus(orders, status)))
				.count();

		long allDeliveredOrders = vendorOrders.stream()
				.filter(orders -> deliveredOrderStatus.contains(orders.getOrderStatus()))
				.count();

		long allOrders = vendorOrders.size();

		OrderCountIndividualResponse deliveryCount = new OrderCountIndividualResponse();
		deliveryCount.setOpen(openDeliveryOrders);
		deliveryCount.setCancelled(cancelledDeliveryOrders);
		deliveryCount.setRefund(refundDeliveryOrders);
		deliveryCount.setDelivered(deliveredDeliveryOrders);
		deliveryCount.setAll(allDeliveryOrders);

		OrderCountIndividualResponse pickupCount = new OrderCountIndividualResponse();
		pickupCount.setOpen(openPickupOrders);
		pickupCount.setCancelled(cancelledPickupOrders);
		pickupCount.setRefund(refundPickupOrders);
		pickupCount.setDelivered(deliveredPickupOrders);
		pickupCount.setAll(allPickupOrders);

		OrderCountIndividualResponse shippingCount = new OrderCountIndividualResponse();
		shippingCount.setOpen(openShippingOrders);
		shippingCount.setInShipment(inShipmentShippingOrders);
		shippingCount.setCancelled(cancelledShippingOrders);
		shippingCount.setRefund(refundShippingOrders);
		shippingCount.setDelivered(deliveredShippingOrders);
		shippingCount.setAll(allShippingOrders);

		OrderCountIndividualResponse allCount = new OrderCountIndividualResponse();
		allCount.setOpen(allOpenOrders);
		allCount.setInShipment(allInShipmentOrders);
		allCount.setCancelled(allCancelledOrders);
		allCount.setRefund(allRefundOrders);
		allCount.setDelivered(allDeliveredOrders);
		allCount.setAll(allOrders);

		List<String> totalCountFilters = new ArrayList<>();
		totalCountFilters.add("NEW");
		totalCountFilters.add("CONFIRMED");
		totalCountFilters.add("INPROGRESS");
		totalCountFilters.remove("INSHIPMENT");
		totalCountFilters.add("COMPLETED");
		totalCountFilters.add("DELIVERED");
		double orderTotal = vendorOrders.stream()
				.filter(orders -> totalCountFilters.contains(orders.getOrderStatus()))
				.collect(Collectors.summarizingDouble(VendorOrdersDTO::getOrderAmount))
				.getSum();

		orderCountResponse.setDelivery(deliveryCount);
		orderCountResponse.setPickup(pickupCount);
		orderCountResponse.setShipping(shippingCount);
		orderCountResponse.setAll(allCount);
		orderCountResponse.setOrderTotal(orderTotal);

		logger.info("AdminServiceImpl getOrderCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, orderCountResponse, 200,
				Constant.RESPONSE_SUCCESS);
	}

	
	/*private boolean hasRefundWithStatus(VendorOrdersDTO order, String status) {
    return order.getRefund().stream()
            .anyMatch(refund -> status.equals(refund.getStatus()));
	}*/
	
	private boolean hasRefundWithStatus(VendorOrdersDTO order, String status) {
	    return status.equals(order.getStatus());
	}

	@Override
	public Response getAllInCompletedUser(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getOrderCount----starts----"+reportSearchRequest);
		long totalCount = 0;
		Page<Registration> pages = null;
		List<Registration> list = new ArrayList<>();
		Sort sort = null;
		if (!Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			sort = Sort.by("createdAt").descending();
		}
		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);

		if (!Strings.isNullOrEmpty(reportSearchRequest.getSearchText())) {
			list = registrationRepository.getRegisterUser(reportSearchRequest.getSearchText(),
					reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize());
			totalCount = registrationRepository.getRegisterUserCount(reportSearchRequest.getSearchText());
			// pages =
			// registrationRepository.findAllByEmailLikeOrFirstNameLikeOrLastNameLikeOrMobileLike(reportSearchRequest.getSearchText(),reportSearchRequest.getSearchText(),
			// reportSearchRequest.getSearchText(),reportSearchRequest.getSearchText(),paging);
		} else {
			pages = registrationRepository.findAll(paging);
		}

		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			totalCount = pages.getTotalElements();
			list = pages.getContent();
		}
		logger.info("AdminServiceImpl getOrderCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ReportHelper.getResponseListFromRegistrationEntity(list, totalCount), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public void getAllInCompletedUserExport(HttpServletResponse response, ReportSearchRequest reportSearchRequest)
			throws Exception {
		logger.info("AdminServiceImpl getAllInCompletedUserExport----starts----"+response,reportSearchRequest);
		List<Registration> list = new ArrayList<>();
		list = registrationRepository.getAllRegistration();
		buyerToCSV(response, null, list);
		logger.info("AdminServiceImpl getAllInCompletedUserExport----ends----");
	}

	@Override
	public Response getAllProduct(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getAllProduct----starts----"+reportSearchRequest);
		long totalCount = 0;
		Page<Product> pages = null;
		List<Product> list = new ArrayList<>();
		Sort sort = null;
		if (!Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			sort = Sort.by("createdAt").descending();
		}

		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);
		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus()) && !Strings.isNullOrEmpty(reportSearchRequest.getApprovalStatus())) { 
			if (reportSearchRequest.getStatus().equals("1")) {
				pages = productRepository.findByStatusAndApprovalStatus(true,reportSearchRequest.getApprovalStatus(), paging);
			} else if (reportSearchRequest.getStatus().equals("0")) {
				pages = productRepository.findByStatusAndApprovalStatus(false,reportSearchRequest.getApprovalStatus(), paging);
			}
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())) {
			if (reportSearchRequest.getStatus().equals("1")) {
				pages = productRepository.findByStatus(true, paging);
			} else if (reportSearchRequest.getStatus().equals("0")) {
				pages = productRepository.findByStatus(false, paging);
			}
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getSearchText())) {
			list = productRepository.getProduct(reportSearchRequest.getSearchText(),
					reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize());
			totalCount = productRepository.getProductCount(reportSearchRequest.getSearchText());
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getApprovalStatus())) {
			if (reportSearchRequest.getApprovalStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_PENDING)) {
				pages = productRepository.findByApprovalStatus(Constant.PRODUCT_APPROVAL_STATUS_PENDING,paging);
			} else if (reportSearchRequest.getApprovalStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_APPROVED)) {
				pages = productRepository.findByApprovalStatus(Constant.PRODUCT_APPROVAL_STATUS_APPROVED,paging);
			} else if (reportSearchRequest.getApprovalStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_REJECTED)) {
				pages = productRepository.findByApprovalStatus(Constant.PRODUCT_APPROVAL_STATUS_REJECTED,paging);
			} else {
				pages = productRepository.findAll(paging);
			}
		} else {
			if (reportSearchRequest != null && reportSearchRequest.getSortKey() != null
					&& !reportSearchRequest.getSortKey().isEmpty()
					&& reportSearchRequest.getSortKey().equals(Constant.NAME)) {
				pages = productRepository.findVendorDetails(paging);
			}else {
				pages = productRepository.findAll(paging);
			}
		}

		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			totalCount = pages.getTotalElements();
			list = pages.getContent();
		}
		logger.info("AdminServiceImpl getAllProduct----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ProductConverterHelper.getResponseListFromEntity(list, totalCount), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public void getAllProductExport(HttpServletResponse httpResponse, ReportSearchRequest reportSearchRequest)
			throws Exception {
		logger.info("AdminServiceImpl getAllProductExport----starts----"+httpResponse,reportSearchRequest);
		Page<Product> pages = null;
		Sort sort = null;
		if (!Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(reportSearchRequest.getSortKey())) {
			sort = Sort.by("createdAt").descending();
		}
		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);
		List<Product> list = new ArrayList<>();
		pages = productRepository.findAll(paging);
		if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus()) && reportSearchRequest.getStatus().equals("1")) {
			pages = productRepository.findByStatus(true, paging);
		} else if (!Strings.isNullOrEmpty(reportSearchRequest.getStatus())
				&& reportSearchRequest.getStatus().equals("0")) {
			pages = productRepository.findByStatus(false, paging);
		} else {
			pages = productRepository.findAll(paging);
		}

		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			list = pages.getContent();
		}
		productToCSV(httpResponse, list);
		logger.info("AdminServiceImpl getAllProductExport----ends----");
	}

	public void productToCSV(HttpServletResponse httpResponse, List<Product> productList) {
		logger.info("AdminServiceImpl productToCSV----starts----");
		try (CSVPrinter csvPrinter = new CSVPrinter(httpResponse.getWriter(),
				CSVFormat.DEFAULT.withHeader("Product Name", "Product Code", "Price", "Unit Count", "Out Of Stock"));) {
			if (!CommonUtils.IsNullOrEmpty(productList)) {
				for (Product product : productList) {
					List<Object> data = Arrays.asList(product.getProductName(), product.getProductCode(),
							product.getPrice(), product.getUnitCount(), product.getIsOutOfStock());
					csvPrinter.printRecord(data);
				}
			}
			httpResponse.setContentType("text/csv");
			httpResponse.setHeader("Content-Disposition", "attachment; file=" + getFileName("csv"));
			csvPrinter.flush();
		} catch (Exception e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Writing CSV error!", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("AdminServiceImpl productToCSV----ends----");
	}

	@Override
	public Response getProductCount() throws Exception {
		logger.info("AdminServiceImpl getProductCount----starts----");
		int activeCount = 0;
		int inActiveCount = 0;
		int outOfStockCount = 0;
		activeCount = productRepository.countByStatus(true);
		inActiveCount = productRepository.countByStatus(false);
		outOfStockCount = productRepository.countByIsOutOfStock(true);

		VendorProductResponse vendorProductResponse = new VendorProductResponse();
		vendorProductResponse.setActiveCount(activeCount);
		vendorProductResponse.setInActiveCount(inActiveCount);
		vendorProductResponse.setOutOfStockCount(outOfStockCount);
		logger.info("AdminServiceImpl getProductCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getCountForDashboard() throws Exception {
		logger.info("AdminServiceImpl getCountForDashboard----starts----");
		AdminDashboardResponse adminDashboardResponse = new AdminDashboardResponse();
		long buyerCount = 0;
		long vendorCount = 0;
		long buyerYesterdayCount = 0;
		long vendorYesterdayCount = 0;
		long inCompletedUser = 0;
		buyerCount = getAllBuyerCount();
		vendorCount = getAllVendorCount();
		buyerYesterdayCount = getAllBuyerCountOnYesterday();
		vendorYesterdayCount = getAllVendorCountOnYesterday();
		inCompletedUser = getAllInCompletedUserCount();
		long activeCount = productRepository.countByStatus(true);
		long yesterdayProductActiveCount = productRepository.countByStatusAndCreatedAtBetween(true,
				CommonUtils.previousDate(), CommonUtils.getCurrentDate());
		adminDashboardResponse.setActiveCount(activeCount);
		adminDashboardResponse.setBuyerCount(buyerCount);
		adminDashboardResponse.setBuyerYesterdayCount(buyerYesterdayCount);
		adminDashboardResponse.setInCompletedUser(inCompletedUser);
		adminDashboardResponse.setVendorCount(vendorCount);
		adminDashboardResponse.setVendorYesterdayCount(vendorYesterdayCount);
		adminDashboardResponse.setYesterdayProductActiveCount(yesterdayProductActiveCount);
		logger.info("AdminServiceImpl getCountForDashboard----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, adminDashboardResponse, 200,
				Constant.RESPONSE_SUCCESS);
	}

	public long getAllBuyerCount() throws Exception {
		logger.info("AdminServiceImpl getAllBuyerCount----starts----");
		long totalCount = 0;
		List<Integer> vendor = vendorRepository.getAllVendor();
		logger.info("AdminServiceImpl getAllBuyerCount - vendorListSize = {}", vendor.size());
		totalCount = userRepository.countByUserIdNotInAndStatus(vendor, 1);
		logger.info("AdminServiceImpl getAllBuyerCount----ends----");
		return totalCount;
	}

	public long getAllVendorCount() throws Exception {
		logger.info("AdminServiceImpl getAllVendorCount----starts----");
		long totalCount = 0;
		totalCount = vendorRepository.countByUserStatus(1);
		logger.info("AdminServiceImpl getAllVendorCount----ends----");
		return totalCount;
	}

	public long getAllInCompletedUserCount() throws Exception {
		logger.info("AdminServiceImpl getAllInCompletedUserCount----starts----");
		long totalCount = 0;
		List<Registration> registration = registrationRepository.getAllRegistration();
		if (!CommonUtils.IsNullOrEmpty(registration)) {
			totalCount = registration.size();
		}
		logger.info("AdminServiceImpl getAllInCompletedUserCount----ends----");
		return totalCount;
	}

	public long getAllBuyerCountOnYesterday() throws Exception {
		logger.info("AdminServiceImpl getAllBuyerCountOnYesterday----starts----");
		long totalCount = 0;
		List<Integer> vendor = vendorRepository.getAllVendor();
		totalCount = userRepository.countByUserIdNotInAndStatusAndCreatedAtBetween(vendor, 1,
				CommonUtils.previousDate(), CommonUtils.getCurrentDate());
		logger.info("AdminServiceImpl getAllBuyerCountOnYesterday----ends----");
		return totalCount;
	}

	public long getAllVendorCountOnYesterday() throws Exception {
		logger.info("AdminServiceImpl getAllVendorCountOnYesterday----starts----");
		long totalCount = 0;
		totalCount = vendorRepository.countByUserStatusAndUserCreatedAtBetween(1, CommonUtils.previousDate(),
				CommonUtils.getCurrentDate());
		logger.info("AdminServiceImpl getAllVendorCountOnYesterday----ends----");
		return totalCount;
	}

	@Override
	public Response getOrderDetails(OrderRequest orderRequest) throws Exception {
		logger.info("AdminServiceImpl getOrderDetails----starts----"+orderRequest);
		List<SellerPaymentResponse> sellerPaymentResponse = null;
		if (Strings.isNullOrEmpty(orderRequest.getEndDate())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.END_DATE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Strings.isNullOrEmpty(orderRequest.getStartDate())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.START_DATE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (orderRequest.getOrderId() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		sellerPaymentResponse = adminRepository.getOrderDetails(orderRequest);
		logger.info("AdminServiceImpl getOrderDetails----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, sellerPaymentResponse, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getUnpaidOrders(int page, int size) throws Exception {
		logger.info("AdminServiceImpl getUnpaidOrders----starts----"+page,size);
		// TODO Auto-generated method stub
		Map<String,Object> unpaidResponse = new  LinkedHashMap<String, Object>();
		List<Map<String, Object>> respList = new ArrayList<Map<String, Object>>();
		try {

			String loginMail = authenticationConfig.getLoginUserMail();
			User user = userRepository.findByEmail(loginMail);
			Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
			
			Authentication authentication  = authenticationConfig.getAuthorities();
			authentication.getAuthorities().stream().forEach(a -> System.out.println(a.getAuthority()));

			if (authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER") || a.getAuthority().equals("ROLE_ADMIN"))) {
				//Pageable pagableRefLastTransaction = PageRequest.of(page, size, Direction.DESC, "transactionDate");
				Page<Orders> unpaidOrderList = ordersRepository.findByVendorVendorIdAndPaidToSellerAndFailedPayoutCount(
						vendor.getVendorId(), false, transactionFaliedCount,PageRequest.of(page, size, Direction.DESC, "orderDate")); // 5 Order total values

				if (unpaidOrderList.getContent().size() > 0) {
					Map<String, Object> response;
					for (Orders order : unpaidOrderList.getContent()) {
						response = new LinkedHashMap<>();
						List<SellerPayment> sellerp = sellerPaymentRepository.findBySellerPaymentOrderDetails(order.getOrderId(),page,size);
						response.put("orderNo", order.getOrderNumber());
						response.put("orderId", order.getOrderId());
						response.put("orderDate", order.getOrderDate());
						response.put("orderValue", order.getOrderAmount());
						response.put("transactionDate",
								sellerp.size() > 0 ? sellerp.get(0).getTransactionDate() : null);
						respList.add(response);
					}
					unpaidResponse.put("reportResponse", respList);
					unpaidResponse.put("totalCount", unpaidOrderList.getTotalElements());
				}
			} else if (authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
				//Pageable pagableRefLastTransaction = PageRequest.of(page, size, Direction.DESC, "transactionDate");
				Page<Orders> unpaidOrderList = ordersRepository.findByPaidToSellerAndFailedPayoutCount(false,
						transactionFaliedCount,PageRequest.of(page, size, Direction.DESC, "orderDate"));

				if (unpaidOrderList.getContent().size() > 0) {
					Map<String, Object> response;
					for (Orders order : unpaidOrderList.getContent()) {

						response = new LinkedHashMap<>();
						List<SellerPayment> sellerp = sellerPaymentRepository.findBySellerPaymentOrderDetails(order.getOrderId(),page,size);
						response.put("orderNo", order.getOrderNumber());
						response.put("orderId", order.getOrderId());
						response.put("orderDate", order.getOrderDate());
						response.put("orderValue", order.getOrderAmount());
						response.put("transactionDate",
								sellerp.size() > 0 ? sellerp.get(0).getTransactionDate() : null);
						response.put("sellerId", order.getVendor().getVendorId());
						response.put("sellerName", order.getVendor().getName());
						respList.add(response);
					}
					unpaidResponse.put("reportResponse", respList);
					unpaidResponse.put("totalCount", unpaidOrderList.getTotalElements());
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
					500);

		}
		logger.info("AdminServiceImpl getUnpaidOrders----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, unpaidResponse, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getSuccessTransaction() throws Exception {
		logger.info("AdminServiceImpl getSuccessTransaction----starts----");
		// TODO Auto-generated method stub
		List<Map<String, Object>> respList = new ArrayList<Map<String, Object>>();
		try {
			User user = authenticationConfig.getUserByAccessToken();
			Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
			
			Authentication authentication  = authenticationConfig.getAuthorities();
			authentication.getAuthorities().stream().forEach(a -> System.out.println(a.getAuthority()));

			if (authentication.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER") || a.getAuthority().equals("ROLE_ADMIN"))) {

				Pageable lastTenSuccessTransaction = PageRequest.of(0, 10, Direction.DESC, "transactionDate");
				Page<SellerPayment> sellrt = sellerPaymentRepository.findByVendorVendorId(vendor.getVendorId(),
						lastTenSuccessTransaction);

				Map<String, Object> response;
				for (SellerPayment sellerPayment : sellrt.getContent()) {
					response = new LinkedHashMap<>();
					response.put("orderNo", sellerPayment.getOrder().getOrderNumber());
					response.put("orderId", sellerPayment.getOrder().getOrderId());
					response.put("orderDate", sellerPayment.getOrder().getOrderDate());
					response.put("paymentDate", sellerPayment.getTransactionDate());
					response.put("transactionId", sellerPayment.getTransactionId());
					response.put("orderValue", sellerPayment.getOrder().getOrderAmount() / 100); // converting stripe
					respList.add(response);
				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
					500);

		}
		logger.info("AdminServiceImpl getSuccessTransaction----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, respList, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response sendFeedBack(FeedBackRequest feedBackRequest) throws Exception {
		logger.info("AdminServiceImpl sendFeedBack----starts----"+feedBackRequest);
		Map<String, String> map = new HashMap<>();
		Vendor vendor = vendorRepository.findByVendorId(feedBackRequest.getVendorId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		boolean isMailSent = sendFeedBackMail(feedBackRequest,vendor);
		if(isMailSent) {
			map.put("message", Constant.FEEDBACK_SENTED_SUCCESSFULLY);
		} else {
			map.put("message", Constant.FEEDBACK_SENTED_FAILED);
		}
		logger.info("AdminServiceImpl sendFeedBack----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,map, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Async("specificTaskExecutor")
	public boolean sendFeedBackMail(FeedBackRequest feedBackRequest, Vendor vendor) {
		logger.info("AdminServiceImpl sendFeedBackMail----starts----"+feedBackRequest,vendor);
		boolean isMailSent = true;
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("feedBack", feedBackRequest.getFeedBack());
			mailMap.put("name", Constant.ADMIN);
			mailMap.put("sellerName", vendor.getUser().getFirstName()+" "+vendor.getUser().getLastName());
			mailMap.put("sellerEmail", vendor.getUser().getEmail());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			mailMap.put("supportFAQ", webSiteUrl.concat(supportFAQ));
			Template mailTemplate = config.getTemplate(feedBackEmailTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", adminMail);
			notificationMap.put("subject", feedBackEmailSubject);
			notificationMap.put("html", html);
			isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		logger.info("AdminServiceImpl sendFeedBackMail----ends----");
		return isMailSent;

	}

	@Override
	public Response getVersionDetails() throws Exception {
		logger.info("AdminServiceImpl getVersionDetails----starts----");
		// TODO Auto-generated method stub
		List<CurrentVersion> CurrentVersionList = versionrepository.findAll();
		List<VersionHistoryResponse> VersionHistoryResponseList =  new ArrayList<VersionHistoryResponse>();
		for (CurrentVersion v : CurrentVersionList) {
			VersionHistoryResponse VersionHistoryResponse = new VersionHistoryResponse();
			VersionHistoryResponse.setPlatform(v.getPlatform());
			VersionHistoryResponse.setVersionName(v.getVersion());
			VersionHistoryResponse.setRemarks(v.getRemarks());
			VersionHistoryResponse.setReleaseDate(v.getReleaseDate());
			VersionHistoryResponse.setCurrentversionId(v.getVersionid());
			VersionHistoryResponse.setUserid(v.getUserid());
			VersionHistoryResponseList.add(VersionHistoryResponse);
		}
		logger.info("AdminServiceImpl getVersionDetails----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, VersionHistoryResponseList, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getShippingOrders(ReportSearchRequest reportSearchRequest) throws Exception {
		logger.info("AdminServiceImpl getShippingOrders----starts----"+reportSearchRequest);
		ShippoTransactionResponse shippoTransactionResponse = null;
		List<ShippoTransactionResponse> shippoTransactionList = new ArrayList<>();
		ShippoTransactionResponseList shippoTransactionResponseList = new ShippoTransactionResponseList();
		Page<ShippoTransactionDetails> pages = null;
		long totalCount = 0;
		List<ShippoTransactionDetails> list = new ArrayList<>();
		Sort sort = null;
		String sortKey = null;
		if (reportSearchRequest != null) {
			sortKey = (StringUtils.isNotBlank(reportSearchRequest.getSortKey())
					&& (reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ORDER_NUMBER)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.SELLER_NAME)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.BUYER_NAME)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.SHIPPING_COST)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ORDER_AMOUNT)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.TOTAL_AMOUNT)
							|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ACTION)) ? ""
									: reportSearchRequest.getSortKey());
		}
		System.out.println("sortKey:"+sortKey);
		if (!Strings.isNullOrEmpty(sortKey)) {
			if (reportSearchRequest.getSortOrder().equalsIgnoreCase("desc")) {
				sort = Sort.by(reportSearchRequest.getSortKey()).descending();
			} else {
				sort = Sort.by(reportSearchRequest.getSortKey()).ascending();
			}
		}
		if (Strings.isNullOrEmpty(sortKey)) {
			sort = Sort.by("createdAt").descending();
		}
		Pageable paging = PageRequest.of(reportSearchRequest.getPageNumber(), reportSearchRequest.getPageSize(), sort);
		pages = shippoTransactionDetailsRepository.findByLabelNotNull(paging);
		if(!Strings.isNullOrEmpty(reportSearchRequest.getEndDate()) && !Strings.isNullOrEmpty(reportSearchRequest.getStartDate())) {
			Timestamp startDate = CommonUtils.stringToTimestampConversion(CommonUtils.convertStringToTimestamp(reportSearchRequest.getStartDate()));
			Timestamp endDate = CommonUtils.stringToTimestampEndDateConversion(CommonUtils.convertStringToTimestamp(reportSearchRequest.getEndDate()));
			pages = shippoTransactionDetailsRepository.findByLabelNotNullAndCreatedAtLessThanEqualAndCreatedAtGreaterThanEqual(paging,endDate,startDate);
		}
		if (pages != null && !CommonUtils.IsNullOrEmpty((pages.getContent()))) {
			totalCount = pages.getTotalElements();
			list = pages.getContent();
			
		}
		for (ShippoTransactionDetails shippoTransaction : list) {
			if(StringUtils.isNotBlank(shippoTransaction.getTrackingNumber())) {
				shippoTransactionResponse = new ShippoTransactionResponse();
				shippoTransactionResponse.setCarrier(shippoTransaction.getCarrier());
				shippoTransactionResponse.setCreatedAt(shippoTransaction.getCreatedAt());
				shippoTransactionResponse.setTrackingNumber(shippoTransaction.getTrackingNumber());
				shippoTransactionResponse.setLabel(shippoTransaction.getLabel());
				if(shippoTransaction.getOrderId()!=null) {
					Orders order = ordersRepository.findOrdersByOrderId(Integer.parseInt(shippoTransaction.getOrderId()));
					if(order!=null) {
						shippoTransactionResponse.setOrderAmount(order.getOrderAmount());
						shippoTransactionResponse.setOrderDate(order.getOrderDate());
						shippoTransactionResponse.setOrderNumber(order.getOrderNumber());
						shippoTransactionResponse.setShippingCost(order.getShippingCost());
						Vendor vendor = vendorRepository.findByVendorId(order.getVendor().getVendorId());
						shippoTransactionResponse.setSellerName(vendor.getName());
						User user = userRepository.findByUserId(order.getUser().getUserId());
						shippoTransactionResponse.setBuyerName(user.getFirstName()+" "+user.getLastName());
						shippoTransactionResponse.setTotalAmount(order.getOrderAmount()+order.getShippingCost());
						shippoTransactionList.add(shippoTransactionResponse);
					}
				}
			}
		}
		//Java level sorting admin shipping details show place.
		System.out.println("sortKey input:"+reportSearchRequest.getSortKey());
		if(reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ORDER_NUMBER)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.SELLER_NAME)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.BUYER_NAME)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.SHIPPING_COST)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ORDER_AMOUNT)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.TOTAL_AMOUNT)
				|| reportSearchRequest.getSortKey().equalsIgnoreCase(Constant.ACTION)) {
			
			List<ShippoTransactionResponse> shippoTransactionDetails = shippoTransactionList;
			Comparator<ShippoTransactionResponse> sortingComparator = makeSortComparator(reportSearchRequest);
			String sortOrder = (StringUtils.isNotBlank(reportSearchRequest.getSortKey()) &&  reportSearchRequest.getSortOrder().equalsIgnoreCase("desc"))? "desc" : "asc";
			if (sortOrder.equalsIgnoreCase("desc")) {
				shippoTransactionDetails.sort(Collections.reverseOrder(sortingComparator));		       
		    } else {
		    	shippoTransactionDetails.sort(sortingComparator);
		    }			
			shippoTransactionResponseList.setShippoTransactionResponse(shippoTransactionDetails);
			shippoTransactionResponseList.setTotalCount(totalCount);
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, shippoTransactionResponseList, 200, Constant.RESPONSE_SUCCESS);			
		}
		
		shippoTransactionResponseList.setShippoTransactionResponse(shippoTransactionList);
		shippoTransactionResponseList.setTotalCount(totalCount);
		logger.info("AdminServiceImpl getShippingOrders----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, shippoTransactionResponseList, 200, Constant.RESPONSE_SUCCESS);
	}

	public Comparator<ShippoTransactionResponse> makeSortComparator(ReportSearchRequest reportSearchRequest) {
		Comparator<ShippoTransactionResponse> sortingComparator = null;
		switch (reportSearchRequest.getSortKey()) {
		    case Constant.ORDER_NUMBER:
		    	sortingComparator = (c1, c2) -> c1.getOrderNumber().compareTo(c2.getOrderNumber());
		        break;
		    case Constant.SELLER_NAME:
		    	sortingComparator = (c1, c2) -> c1.getSellerName().compareToIgnoreCase(c2.getSellerName());
		        break;
		    case Constant.BUYER_NAME:
		    	sortingComparator = (c1, c2) -> c1.getBuyerName().compareToIgnoreCase(c2.getBuyerName());
		        break;
		    case Constant.SHIPPING_COST:
		    	sortingComparator = (c1, c2) -> Double.compare(c1.getShippingCost(), c2.getShippingCost());
		        break;
		    case Constant.ORDER_AMOUNT:
		    	sortingComparator = (c1, c2) -> Double.compare(c1.getOrderAmount(),c2.getOrderAmount());
		        break;
		    case Constant.TOTAL_AMOUNT:
		    	sortingComparator = (c1, c2) -> Double.compare(c1.getTotalAmount(),c2.getTotalAmount());
		        break;
		    default:
		    	sortingComparator = (c1, c2) -> c1.getOrderNumber().compareToIgnoreCase(c2.getOrderNumber());
		        break;
		}
		return sortingComparator;
	}
	
	@Override
	public Response getChartCount(ReportSearchRequest searchRequest) throws Exception {
		logger.info("VendorServiceImpl getChartCount----starts----"+searchRequest);
		Map<String, Object> map = new HashMap<>();
		List<AdminResponse> adminResponse = productSearchRepository.getChartCountAdmin(searchRequest,Constant.NEW);
		List<AdminResponse> cancelOrder = productSearchRepository.getChartCountAdmin(searchRequest,Constant.ORDER_STATUS_CANCELLED);
		List<AdminResponse> deliveredOrder = productSearchRepository.getChartCountAdmin(searchRequest,Constant.ORDER_STATUS_DELIVERED);
		map.put("Received", adminResponse);
		map.put("Cancelled", cancelOrder);
		map.put("Delivered", deliveredOrder);
		logger.info("VendorServiceImpl getChartCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,map,200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response updateApprovalStatus(ProductUpdateRequest productReq) throws Exception {
		logger.info("AdminServiceImpl updateApprovedStatus----starts----"+productReq);
		User accessUser = userService.getUserByAccessToken();
		if (org.springframework.util.StringUtils.isEmpty(productReq.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Strings.isNullOrEmpty(productReq.getApprovedStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.APPROVED_STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(productReq.getApprovedStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_REJECTED) && Strings.isNullOrEmpty(productReq.getRejectReason())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.REJECTED_REASON_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Product product = productRepository.findByProductId(productReq.getId());
		if(product==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		int count = 0;
		if (product.getApprovalStatus().equalsIgnoreCase(Constant.PRODUCT_APPROVAL_STATUS_PENDING)) {
			count = productRepository.updateApprovalStatus(productReq.getApprovedStatus(), product.getProductId(), CommonUtils.GetCurrentTimeStamp());
			if(productReq.getApprovedStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_REJECTED) ) {
				product.setApprovalStatus(productReq.getApprovedStatus());
				product.setRejectReason(productReq.getRejectReason());
				productRepository.save(product);
				sendProductRejectMail(product);
			}
			updateProductAuditTrail(product,productReq.getApprovedStatus(),false,false,accessUser.getFirstName()+" "+accessUser.getLastName());
		//	saveActiveProductLog(product, Constant.PRODUCT_ACTIVE);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_APPROVAL_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		
		if (count == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("AdminServiceImpl updateApprovedStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
	}
	
	public void updateProductAuditTrail(Product product,String message,boolean img,boolean value,String name) throws Exception {
		logger.info("ProductServiceImpl updateProductAuditTrail----starts----");
		ProductAuditTrail ProductAuditTrail = new ProductAuditTrail(); 
		ProductAuditTrail.setComments(message);
		ProductAuditTrail.setImgUpdate(img);
		ProductAuditTrail.setProduct(product);
		ProductAuditTrail.setProductupdate(value);
		ProductAuditTrail.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		ProductAuditTrail.setUpdatedBy(name);
		productAuditTrailRepository.save(ProductAuditTrail);
		logger.info("ProductServiceImpl updateProductAuditTrail----ends----");
	}
	
	@Override
	public Response getByProductId(Integer id) throws Exception {
		logger.info("ProductServiceImpl getByProductId----starts----"+id);
		if (org.springframework.util.StringUtils.isEmpty(id)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<ProductAuditTrail> list = new ArrayList<>();
		Product product = productRepository.findByProductId(id);

		if (product == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<ProductImage> productImageList = productImageRepository
				.findByProductProductIdAndIsActive(product.getProductId(), true);
		product.setProductImage(productImageList);
		List<ProductAuditTrail> productAuditTrailList = productAuditTrailRepository.findByProductProductId(product.getProductId());
		for(ProductAuditTrail productAuditTrail : productAuditTrailList) {
			productAuditTrail.setProduct(null);
			list.add(productAuditTrail);
		}
		product.setProductAuditTrail(list);
		logger.info("ProductServiceImpl getByProductId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ProductConverterHelper.getResponseFromEntity(product),
				200, Constant.RESPONSE_SUCCESS);
	}
	
	@Async("specificTaskExecutor")
	public void sendProductRejectMail(Product product) {
		logger.info("OrderServiceImpl sendOrderShipmentMail----starts----");
		try {
			
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("sellerName", product.getVendor().getName());
			mailMap.put("productName", product.getProductName());
			mailMap.put("rejectReason", product.getRejectReason());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			// mailMap.put("name", user.getFirstName()+" "+user.getLastName());
			Template mailTemplate = config.getTemplate(productRejectTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", product.getVendor().getUser().getEmail());
			// notificationMap.put("userMail", user.getEmail());
			notificationMap.put("subject", "Attention - "+product.getProductName()+" has been rejected for "+product.getVendor().getName());
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			logger.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("OrderServiceImpl sendOrderShipmentMail----ends----");
	}

	@Override
	public Response updateInactivateStatus(ProductUpdateRequest productReq) throws Exception {
		logger.info("AdminServiceImpl updateInactivateStatus----starts----" + productReq);
		if (org.springframework.util.StringUtils.isEmpty(productReq.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(productReq.getStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(productReq.getInactivateReason())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INACTIVATE_REASON_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(productReq.getApprovedStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.APPROVED_STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		Product product = productRepository.findByProductId(productReq.getId());
		if (existingVendor != null && product != null
				&& CommonUtils.integersCompare(existingVendor.getVendorId(), product.getVendor().getVendorId()) != 0) {
			System.out.println(" existingVendor.getVendorId()>>" + existingVendor.getVendorId());
			System.out.println(" product.getVendorId()>>" + product.getVendor().getVendorId());
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}		
		if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
			assert product != null;
			product.setStatus(false);
			product.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			product.setInactivateReason(productReq.getInactivateReason());
			productRepository.save(product);		
			sendProductInactivateMail(product);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}		
		logger.info("AdminServiceImpl updateInactivateStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
	}

	@Async("specificTaskExecutor")
	public void sendProductInactivateMail(Product product) {
		logger.info("AdminServiceImpl sendProductInactivateMail----starts----");
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("sellerName", product.getVendor().getName());
			mailMap.put("productName", product.getProductName());
			mailMap.put("inActiveReason", product.getInactivateReason());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			Template mailTemplate = config.getTemplate(productInactivateTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", product.getVendor().getUser().getEmail());
			notificationMap.put("subject", "Attention - " + product.getProductName() + " has been inactivated for "
					+ product.getVendor().getName());
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			logger.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("AdminServiceImpl sendProductInactivateMail----ends----");
	}

	@Override
	public Response exitingAddresslatAndLongMigration() throws Exception {
		logger.info("AdminServiceImpl exitingAddresslatAndLongMigration----starts----");
		// Seller end latitude and longitude update logic
		List<Address> addressList = addressRepository.findByLatitudeIsNullAndLongitudeIsNull();
		logger.info("latitude and longitude empty count:" + addressList.size());
		if (!CommonUtils.IsNullOrEmpty(addressList)) {
			for (Address address : addressList) {
				if (address != null) {
					String addressLine = concatAddressFields(address);
					logger.info("prepare addressLine:" + addressLine);
					try {
						String apiKey = googleMapAPIKey;

						String encodedAddress = URLEncoder.encode(addressLine, "UTF-8");

						// Create the URL for the Geocoding API request
						String apiUrl = "https://maps.googleapis.com/maps/api/geocode/json?address=" + encodedAddress
								+ "&key=" + apiKey;

						// Send the API request and get the response
						URL url = new URL(apiUrl);
						HttpURLConnection connection = (HttpURLConnection) url.openConnection();
						connection.setRequestMethod("GET");
						int responseCode = connection.getResponseCode();

						if (responseCode == HttpURLConnection.HTTP_OK) {
							BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
							String inputLine;
							StringBuilder response = new StringBuilder();

							while ((inputLine = in.readLine()) != null) {
								response.append(inputLine);
							}
							in.close();

							// Parse the JSON response
							JSONObject jsonObject = new JSONObject(response.toString());
							JSONArray results = jsonObject.getJSONArray("results");

							if (results.length() > 0) {
								JSONObject result = results.getJSONObject(0);
								JSONObject location = result.getJSONObject("geometry").getJSONObject("location");
								double latitude = location.getDouble("lat");
								double longitude = location.getDouble("lng");

								logger.info("Latitude: " + latitude);
								logger.info("Longitude: " + longitude);

								// update on database
								Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
								addressRepository.updateLatitudeAndLongitude(latitude, longitude, currentTime,
										address.getId());
								logger.info("update on for address id:" + address.getId());
							} else {
								logger.info("No results found.");
							}
						} else {
							logger.info("API request failed with response code: " + responseCode);
						}
					} catch (Exception e) {
						logger.info("Exception:" + e.getMessage());
					}
				}
			}
		}
		logger.info("AdminServiceImpl exitingAddresslatAndLongMigration----ends----");
		return ResponseHelper.getSuccessResponse("Latitude and longitude updated done", "", 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	public String concatAddressFields(Address address) {
		StringBuilder sb = new StringBuilder();
		if (address.getLine1() != null && !address.getLine1().isEmpty()) {
			sb.append(address.getLine1()).append(", ");
		}
		if (address.getCity() != null && !address.getCity().isEmpty()) {
			sb.append(address.getCity()).append(", ");
		}
		if (address.getStateId() != null) {
			State state = stateRepository.findStateById(address.getStateId());
			if (state != null && state.getStatecode() != null && !state.getStatecode().isEmpty()) {
				sb.append(state.getStatecode()).append(", ");
			}
		}
		if (address.getZipcode() != null && !address.getZipcode().isEmpty()) {
			sb.append(address.getZipcode()).append(", ");
		}
		String concatenatedAddress = sb.toString();
		if (concatenatedAddress.endsWith(", ")) {
			concatenatedAddress = concatenatedAddress.substring(0, concatenatedAddress.length() - 2);
		}
		return concatenatedAddress;
	}
	
	@Override
	public Response getAllTaxCodes(Pagination pagination, String searchText, String sortKey, String sortOrder,
			String taxCode, String description) throws Exception {
		int offset = 0;
		int limit = Constant.DEFAULT_TAX_CODE_SEARCH_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		Sort sort = makeSortOrder(sortKey, sortOrder);
		Pageable paging = PageRequest.of(offset, limit, sort);
		List<AvalaraTaxCode> avalaraTaxCodeList = new ArrayList<>();
		if (StringUtils.isNotBlank(searchText)) {
			avalaraTaxCodeList = avalaraTaxCodeRepository.taxCodeDetailsWithSearchTxt(searchText,
					Constant.DEFAULT_TAX_CODE_SEARCH_LIMIT,Constant.AUTO_SEARCH_SORTBY);

		} else {
			if (StringUtils.isNotBlank(taxCode) && StringUtils.isNotBlank(description)) {
				avalaraTaxCodeList = avalaraTaxCodeRepository
						.findByTaxCodeContainingIgnoreCaseOrDescriptionContainingIgnoreCase(taxCode, description,
								paging);
			} else if (StringUtils.isNotBlank(taxCode)) {
				avalaraTaxCodeList = avalaraTaxCodeRepository.findByTaxCodeContainingIgnoreCase(taxCode, paging);
			} else if (StringUtils.isNotBlank(description)) {
				avalaraTaxCodeList = avalaraTaxCodeRepository.findByDescriptionContainingIgnoreCase(description,
						paging);
			} else {
				Page<AvalaraTaxCode> avalaraTaxCodePage = avalaraTaxCodeRepository.findAll(paging);
				avalaraTaxCodeList.addAll(avalaraTaxCodePage.getContent());
			}
		}
		List<AvalaraTaxCodeResponse> avalaraTaxCodeDetails = avalaraTaxCodeList.stream().map(avalaraTaxCode -> {
			AvalaraTaxCodeResponse avalaraTaxCodeResponse = AvalaraHelper
					.makeAvalaraTaxCodeResponse(avalaraTaxCode);
			return avalaraTaxCodeResponse;
		}).collect(Collectors.toList());
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, avalaraTaxCodeDetails, 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	private Sort makeSortOrder(String sortKey, String sortOrder) {
		Sort sort;
		if (!Strings.isNullOrEmpty(sortKey)) {
			if ("desc".equalsIgnoreCase(sortOrder)) {
				sort = Sort.by(sortKey).descending();
			} else {
				sort = Sort.by(sortKey).ascending();
			}
		} else {
			sort = Sort.by(Constant.DEFAULT_TAX_CODE_SORT_FIELD).ascending();
		}
		return sort;
	}

	@Override
	public Response saveFeaturedImages(List<ConfigRequestVO> confibRequestVOList) throws Exception {
		logger.info("AdminServiceImpl saveFeaturedImages----starts----");

		if (CommonUtils.IsNullOrEmpty(confibRequestVOList)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		for (ConfigRequestVO configRequestVO : confibRequestVOList) {
			if (configRequestVO != null && configRequestVO.getName() != null && !configRequestVO.getName().isEmpty()) {

				if (configRequestVO.getName().equalsIgnoreCase(Constant.FEATURE_SELLER_ID)) {
					Config featureSellerId = configRepository.findByName(Constant.FEATURE_SELLER_ID);
					if (featureSellerId != null) {
						featureSellerId.setValue(configRequestVO.getValue());
						configRepository.save(featureSellerId);
					}
				}

				if (configRequestVO.getName().equalsIgnoreCase(Constant.FEATURE_SELLER_NAME)) {
					Config featureSellerName = configRepository.findByName(Constant.FEATURE_SELLER_NAME);
					if (featureSellerName != null) {
						featureSellerName.setValue(configRequestVO.getValue());
						configRepository.save(featureSellerName);
					}
				}

				if (configRequestVO.getName().equalsIgnoreCase(Constant.FEATURE_SELLER_TAGLINE)) {
					Config featureSellerTagline = configRepository.findByName(Constant.FEATURE_SELLER_TAGLINE);
					if (featureSellerTagline != null) {
						featureSellerTagline.setValue(configRequestVO.getValue());
						configRepository.save(featureSellerTagline);
					}
				}

				if (configRequestVO.getName().equalsIgnoreCase(Constant.FEATURE_SELLER_IMAGE)) {
					Config featureSellerImage = configRepository.findByName(Constant.FEATURE_SELLER_IMAGE);
					if (featureSellerImage != null) {
						featureSellerImage.setValue(configRequestVO.getValue());
						configRepository.save(featureSellerImage);
					}
				}
			} else {
				logger.info("config request name is null or empty");
			}
		}
		logger.info("AdminServiceImpl saveFeaturedImages----end----");
		return ResponseHelper.getSuccessResponse(Constant.FEATURED_IMAGES_SAVED_OR_UPDATED_SUCCESSFULLY, "", 200,
				Constant.RESPONSE_SUCCESS);

	}


	@Override
	public Response searchVendor(String searchString) {
		logger.info("AdminServiceImpl searchVendor ---- starts ----");

		List<VendorResponseDTO> vendorResponseDTOList = new ArrayList<>();
		if (searchString != null) {
			vendorResponseDTOList = vendorRepository.getVendorList(searchString);
		}

		for (VendorResponseDTO vendorResponseDTO : vendorResponseDTOList) {
			List<VendorImage> vendorImages = vendorImageRepository
					.findByVendorVendorIdAndIsActive(vendorResponseDTO.getVendorId(), true);

			if (vendorImages != null && vendorImages.size() > 0) {
				for (VendorImage vendorImage : vendorImages) {
					if (vendorImage != null && vendorImage.getImage() != null) {
						String imageUrl = vendorImage.getImage().getUrl();

						if (imageUrl != null && !imageUrl.isEmpty()
								&& imageUrl.contains(Constant.IMAGE_VENDOR_SELLER_LOGO)) {
							vendorResponseDTO.setFeaturedSellerLogo(imageUrl);
							break;
						}
					}
				}
				// If no matching image was found, put an empty string
				if (vendorResponseDTO.getFeaturedSellerLogo() == null
						|| vendorResponseDTO.getFeaturedSellerLogo().isEmpty()) {
					vendorResponseDTO.setFeaturedSellerLogo("");
				}
			}
		}

		logger.info("AdminServiceImpl searchVendor ---- ends ----");
		return ResponseHelper.getSuccessResponse("", vendorResponseDTOList, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getFeaturedSeller() throws Exception {
		logger.info("AdminServiceImpl getFeaturedSeller----starts----");
		Map<String, Object> featuredSellerDetails = new LinkedHashMap<String, Object>();

		Config featureSellerId = configRepository.findByName(Constant.FEATURE_SELLER_ID);
		if (featureSellerId != null) {
			featuredSellerDetails.put(Constant.FEATURE_SELLER_ID, featureSellerId);
		}

		Config featureSellerName = configRepository.findByName(Constant.FEATURE_SELLER_NAME);
		if (featureSellerName != null) {
			featuredSellerDetails.put(Constant.FEATURE_SELLER_NAME, featureSellerName);
		}

		Config featureSellerTagline = configRepository.findByName(Constant.FEATURE_SELLER_TAGLINE);
		if (featureSellerTagline != null) {
			featuredSellerDetails.put(Constant.FEATURE_SELLER_TAGLINE, featureSellerTagline);
		}
		
		if (featureSellerId != null) {
			if (featureSellerId.getValue() != null && !featureSellerId.getValue().isEmpty()) {
				List<VendorImage> vendorImages = vendorImageRepository
						.findByVendorVendorIdAndIsActive(Integer.valueOf(featureSellerId.getValue()), true);
				if (vendorImages != null && vendorImages.size() > 0) {
					for (VendorImage vendorImage : vendorImages) {
						if (vendorImage != null && vendorImage.getImage() != null) {
							String imageUrl = vendorImage.getImage().getUrl();

							if (imageUrl != null && !imageUrl.isEmpty() && imageUrl.contains(Constant.IMAGE_VENDOR_SELLER_LOGO)) {
								featuredSellerDetails.put(Constant.FEATURE_SELLER_LOGO, imageUrl);
								break;
							}
						}
					}
					// If no matching image was found, put an empty string
					if (!featuredSellerDetails.containsKey(Constant.FEATURE_SELLER_LOGO)) {
						featuredSellerDetails.put(Constant.FEATURE_SELLER_LOGO, "");
					}
				} else {
					featuredSellerDetails.put(Constant.FEATURE_SELLER_LOGO, "");
				}
			} else {
				featuredSellerDetails.put(Constant.FEATURE_SELLER_LOGO, "");
			}
		}

		Config featureSellerImage = configRepository.findByName(Constant.FEATURE_SELLER_IMAGE);
		if (featureSellerImage != null) {
			if (featureSellerImage.getValue() != null && !featureSellerImage.getValue().isEmpty()) {
				Images images = imageRepository.findByImageId(Integer.valueOf(featureSellerImage.getValue()));
				images.setType(Constant.IMAGE_VENDOR_FEATURED_IMAGE_TYPE);
				featureSellerImage.setSellerFeaturedImage(images);
			}
			featuredSellerDetails.put(Constant.FEATURE_SELLER_IMAGE, featureSellerImage);
		}

		logger.info("AdminServiceImpl getFeaturedSeller----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FEATURED_SELLER_ID_FETCH_SUCCESSFULLY, featuredSellerDetails,
				200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response migrationPersonalPhoto() throws Exception {
		logger.info("AdminServiceImpl migrationPersonalPhoto ---- starts ----");
		int migrationCount = 0;
		try {			
			// Fetch all old personal photo list for vendorImage table.			
			List<VendorImage> getMigrationImagesList = vendorImageRepository
					.getMigrationImages(Constant.IMAGE_VENDOR_PHOTO);
			if (getMigrationImagesList != null && getMigrationImagesList.size() > 0) {
				logger.info("getMigrationImagesList Count: " + getMigrationImagesList.size());

				for (VendorImage vendorImage : getMigrationImagesList) {
					if (vendorImage != null) {
						//if (vendorImage.getVendor().getVendorId().equals(398)) {
							// fetch user id based on given vendor
							Integer userId = vendorImage.getVendor().getUser().getUserId();							
							logger.info("userId:" + userId+" "+"vendorId"+vendorImage.getVendor().getVendorId());
							if (userId != null && userId > 0) {
								// Move data from s3 vendor/photo/vendorId to user/photo/userId
								logger.info("S3 Upload started>>>>" + vendorImage.getImage().getUrl());
								String copiedUrl = "";
								if (vendorImage.getImage().getUrl() != null
										&& !vendorImage.getImage().getUrl().isEmpty()) {
									if (vendorImage.getImage().getUrl().contains(Constant.IMAGE_VENDOR_PHOTO_TYPE)) {
										try {
											String filePath = imageFolder + vendorFolder + "photo/";
											String newPath = imageFolder + userFolder + "photo/";
											copiedUrl = amazonClient.copyFilesOnS3(filePath, newPath,
													vendorImage.getImage().getUrl(), "" + userId);
											if (copiedUrl != null && !copiedUrl.isEmpty()) {
												logger.info("After s3 moved Url" + copiedUrl);
											} else {
												logger.info("s3 moved Url Failed");
											}
										} catch (Exception e) {
											logger.info("s3 level exception");
											logger.info(e.getMessage());
										}
									}
								}

								Images images = new Images();
								// Modified image object vendor level to user level
								images.setUrl(copiedUrl);
								images.setStatus(vendorImage.getImage().getStatus());
								images.setCreatedAt(vendorImage.getImage().getCreatedAt());
								images.setUpdatedAt(vendorImage.getImage().getUpdatedAt());
								images = imageRepository.save(images);

								// Saved image details save on userImage table.
								UserImage userImage = new UserImage();
								userImage.setUser(vendorImage.getVendor().getUser());
								userImage.setImage(images);
								userImage.setStatus(vendorImage.getIsActive());
								userImage.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
								userImage.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
								userImage = userImageRepository.save(userImage);
							}
							migrationCount = migrationCount +1;
						//}
					}
				}
			}
		} catch (Exception e) {
		  logger.info(e.getMessage());
		}
		logger.info("AdminServiceImpl migrationPersonalPhoto ---- end ----");
		return ResponseHelper.getSuccessResponse("Personal photo vendorImage to userImage migration done", migrationCount, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response copyDirectory() throws Exception {
		logger.info("AdminServiceImpl copyDirectory ---- Start ----");
		boolean copyFlag = false;
		try {
			logger.info("bucketName"+bucketName);
			String sourceBucket = bucketName;
			String sourcePrefix = Constant.IMAGE_VENDOR_SOURCE_DIRECTORY;
			String destinationBucket = bucketName;
			String destinationPrefix = Constant.IMAGE_VENDOR_DESTINATION_DIRECTORY;
			
			logger.info("sourcePrefix: "+sourcePrefix);
			logger.info("destinationPrefix: "+destinationPrefix);
			copyFlag = amazonClient.copyDirectory(sourceBucket, sourcePrefix, destinationBucket, destinationPrefix);
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		logger.info("AdminServiceImpl copyDirectory ---- end ----");
		return ResponseHelper.getSuccessResponse("Successfully copy directory one location to another location done.",
				copyFlag, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response s3BucketObjectValidation(String directoryPath) throws Exception {
		logger.info("AdminServiceImpl s3BucketObjectValidation ---- Start ----");
		List<String> subdirectories = null;
		try {
			logger.info("bucketName" + bucketName);

			String basePath = directoryPath;
			logger.info("basePath" + basePath);

			subdirectories = amazonClient.s3BucketObjectValidation(bucketName, basePath);
			if (subdirectories != null) {
				for (String subdirectory : subdirectories) {
					System.out.println("Subdirectory: " + subdirectory);
				}
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		logger.info("AdminServiceImpl s3BucketObjectValidation ---- end ----");
		return ResponseHelper.getSuccessResponse("object Validation successfully", subdirectories, 200,
				Constant.RESPONSE_SUCCESS);
	}
	

	@Override
	public Response deleteObjectsInDirectory() throws Exception {
		logger.info("AdminServiceImpl removeDirectory ---- Start ----");
		boolean removeDirectoryFlag = false;
		try {
			logger.info("bucketName"+bucketName);
			String sourceBucket = bucketName;		
			String removeDirectoryPath = Constant.DELETE_VENDOR_PHOTOS_DIRECTORY;
			logger.info("removeDirectoryPath: "+removeDirectoryPath);
			removeDirectoryFlag = amazonClient.deleteObjectsInDirectory(sourceBucket,removeDirectoryPath);
		}catch(Exception e) {
			logger.info(e.getMessage());
		}
		logger.info("AdminServiceImpl removeDirectory ---- end ----");
		return ResponseHelper.getSuccessResponse("Successfully copy directory one location to another location done.",
				removeDirectoryFlag, 200, Constant.RESPONSE_SUCCESS);
	}
	
	
	@Override
	public Response deletePersonalPhoto() {
		logger.info("AdminServiceImpl deletePersonalPhoto ---- starts ----");
		int deletedRecordCount = 0;
		int notmappingCount = 0;
		try {
			List<VendorImage> getMigrationImagesList = vendorImageRepository
					.getVendorPhotoImageList(Constant.IMAGE_VENDOR_PHOTO);
			if (getMigrationImagesList != null && getMigrationImagesList.size() > 0) {
				for (VendorImage vendorImage : getMigrationImagesList) {
					if (vendorImage != null) {						
						vendorImageRepository.deleteByVendorImageId(vendorImage.getVendorImageId());						
					}
					deletedRecordCount = deletedRecordCount + 1;
				}
			}

			// delete all common records
			notmappingCount = imageRepository.deleteAllVendorPhoto();
			logger.info("notmappingCount:" + notmappingCount);
		} catch (Exception e) {
			logger.info("DeleteVendorPersonalPhoto exception", e.getMessage());
		}
		logger.info("AdminServiceImpl deletePersonalPhoto ---- end ----");
		return ResponseHelper.getSuccessResponse(
				"List of Vendor Personal photo deleted successfully from VendorImage and Image table",
				"deletedRecordCount:" + deletedRecordCount + " " + "notmappingCount" + notmappingCount, 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	 	@Override
	    public Response getSelectedSeller(HttpServletRequest request,Integer adminUserId,Integer userId) throws Exception{
	    	String authHeader = request.getHeader("Authorization");
	    	OAuth2AccessToken accessToken = null;
			if (authHeader != null) {
				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
				org.springframework.security.core.userdetails.User userDetails = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
				String tokenValue = authHeader.replace("Bearer", "").trim();
				accessToken = tokenStore.readAccessToken(tokenValue);
				final Map<String, Object> additionalInfo = new HashMap<String, Object>();
				User user = userRepository.findByUserId(adminUserId);
				User selectedSeller = userRepository.findByUserId(userId);
				additionalInfo.put("role", userDetails.getAuthorities());
		        com.eatzos.model.Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		        
		        additionalInfo.put("userId", user.getUserId().toString());
		        additionalInfo.put("firstName", user.getFirstName());
		        additionalInfo.put("lastName", user.getLastName());
		    	additionalInfo.put("email", user.getEmail());
		    	additionalInfo.put("mobile", user.getMobile());
		    	if(vendor!=null) {
		        	additionalInfo.put("vendorId", vendor.getVendorId().toString());
		        }else {
		        	additionalInfo.put("vendorId", "");
		        }
		    	additionalInfo.put("status",Constant.RESPONSE_SUCCESS);
		        additionalInfo.put("code", 200);
		        additionalInfo.put("data", Constant.RESPONSE_EMPTY_DATA);
		    	additionalInfo.put("message", "");
		    	additionalInfo.put("selectedVendor", selectedSeller.getEmail());
		    	additionalInfo.put("imPersonAte", true);
		    	additionalInfo.put("selectedVendorId", selectedSeller.getUserId());
		    	UserRole role = userRoleRepository.findByPkUserUserId(user.getUserId());
				additionalInfo.put("role", Arrays.asList(new SimpleGrantedAuthority(role.getRoles().getRoleName())));
		        
		        ((DefaultOAuth2AccessToken) accessToken)
		                .setAdditionalInformation(additionalInfo);
		       
			}
			 return ResponseHelper.getSuccessResponse("seller access token", accessToken, 200,
						Constant.RESPONSE_SUCCESS);
	    }	
}