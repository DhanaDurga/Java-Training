package com.eatzos.service.impl;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.eatzos.client.AvalaraClient;
import com.eatzos.config.AuthenticationConfig;
import com.eatzos.helper.AvalaraHelper;
import com.eatzos.model.AvalaraTxnLineSummary;
import com.eatzos.model.AvalaraTxnSummary;
import com.eatzos.model.DeliveryCharge;
import com.eatzos.repository.AvalaraTxnLineSummaryRepository;
import com.eatzos.repository.AvalaraTxnSummaryRepository;
import com.eatzos.repository.DeliveryChargeRepository;
import com.eatzos.request.AvalaraRefundTransactionRequest;
import com.eatzos.response.AvalaraCreateTransactionResponse;
import com.eatzos.response.BuyerOrderResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;

import com.eatzos.exception.BusinessException;
import com.eatzos.helper.AmazonClient;
import com.eatzos.helper.BuyerHelper;
import com.eatzos.helper.NotificationHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.helper.VendorConverterHelper;
import com.eatzos.model.Address;
import com.eatzos.model.Discount;
import com.eatzos.model.DiscountRedemption;
import com.eatzos.model.Images;
import com.eatzos.model.OrderItem;
import com.eatzos.model.Orders;
import com.eatzos.model.Product;
import com.eatzos.model.ProductAttribute;
import com.eatzos.model.ProductCategoryAttribute;
import com.eatzos.model.ProductImage;
import com.eatzos.model.SellerPayment;
import com.eatzos.model.ShippoTransactionDetails;
import com.eatzos.model.State;
import com.eatzos.model.TransactionStatus;
import com.eatzos.model.User;
import com.eatzos.model.UserImage;
import com.eatzos.model.Vendor;
import com.eatzos.model.VendorAddress;
import com.eatzos.model.VendorImage;
import com.eatzos.model.VendorSchedule;
import com.eatzos.repository.AddressRepository;
import com.eatzos.repository.DiscountRedemptionRepository;
import com.eatzos.repository.DiscountRepository;
import com.eatzos.repository.ImageRepository;
import com.eatzos.repository.OrdersRepository;
import com.eatzos.repository.ProductAttributeRepository;
import com.eatzos.repository.ProductCategoryAttributeRepository;
import com.eatzos.repository.ProductImageRepository;
import com.eatzos.repository.ProductRepository;
import com.eatzos.repository.ProductSearchRepository;
import com.eatzos.repository.SellerPaymentRepository;
import com.eatzos.repository.ShippoTransactionDetailsRepository;
import com.eatzos.repository.StateRepository;
import com.eatzos.repository.TransactionStatusRepository;
import com.eatzos.repository.UserImageRepository;
import com.eatzos.repository.UserRepository;
import com.eatzos.repository.VendorAddressRepository;
import com.eatzos.repository.VendorImageRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.repository.VendorScheduleRepository;
import com.eatzos.request.PaymentMethodUpdateRequest;
import com.eatzos.request.PaymentRequest;
import com.eatzos.request.ReportSearchRequest;
import com.eatzos.request.Tracking;
import com.eatzos.request.VendorAddressRequest;
import com.eatzos.response.AdminResponse;
import com.eatzos.response.PaymentResponse;
import com.eatzos.service.ImageService;
import com.eatzos.service.UserService;
import com.eatzos.service.VendorService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.eatzos.util.SimpleResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.base.Strings;
import com.shippo.exception.APIConnectionException;
import com.shippo.model.Track;
import com.stripe.Stripe;
import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.exception.RateLimitException;
import com.stripe.exception.StripeException;
import com.stripe.model.Account;
import com.stripe.model.Customer;
import com.stripe.model.PaymentIntent;
import com.stripe.model.PaymentMethod;
import com.stripe.model.Refund;
import com.stripe.model.Subscription;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.CustomerUpdateParams;
import com.stripe.param.PaymentIntentCreateParams;
import com.stripe.param.PaymentMethodAttachParams;
import com.stripe.param.RefundCreateParams;
import com.stripe.param.SubscriptionCreateParams;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(value = "vendorService")
public class VendorServiceImpl implements VendorService {
	
	private static final Logger logger = LoggerFactory.getLogger(VendorServiceImpl.class);

	@Value("${stripe.api}")
	private String stripeApiKey;
	
	@Value("${renewal.subscription.fee}")
	private String subscriptionFee;
	
	@Value("${transaction.currency.type}")
	private String currencyType;
	
	@Value("${renewal.subscription.fee}")
	private String usdToCents;
	
	@Value("${shippo.carrier}")
	private String carrier;
	
	@Value("${shippo.trackingnumber}")
	private String trackingnumber;
	
	@Value("${shippo.key}")
	private String shippoKey;

	@Autowired
    private OrdersRepository ordersRepository;
	
	@Autowired
    private ProductRepository productRepository;
	
	 @Autowired
	 private TransactionStatusRepository transactionStatusRepository;
	
	@Autowired
	private VendorRepository vendorRepository;
	
	@Autowired
	private VendorScheduleRepository vendorScheduleRepository;

	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private VendorAddressRepository vendorAddressRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ImageRepository imageRepository;
	
	@Autowired
	private ProductCategoryAttributeRepository productCategoryAttributeRepository;

	@Autowired
	private ImageService imageService;

	@Autowired
	private UserService userService;

	@Autowired
	private VendorImageRepository vendorImageRepository;
	
	@Autowired
	private ProductSearchRepository productSearchRepository;

	@Autowired
	private SellerPaymentRepository sellerPaymentRepository;
	
	@Autowired
	DiscountRepository discountRepository;
	
	@Autowired
	DiscountRedemptionRepository discountRedemptionRepository;

	@Value("${mail.vendorRegistrationEmail.template}")
	private String vendorRegistrationEmailTemplate;

	@Value("${mail.vendorRegistrationEmail.subject}")
	private String vendorRegistrationEmailSubject;

	@Value("${mail.header.image}")
	private String mailHeaderImage;
	
	@Autowired
	NotificationHelper notificationHelper;
	
	@Autowired
	private Configuration config;
	
	@Autowired
	ProductAttributeRepository productAttributeRepository;
	
	@Value("${mail.CancelOrderTemplate.subject}")
	private String cancelOrderTemplateSubject;
	
	@Value("${mail.BuyerCancelOrderEmail.subject}")
	private String buyerCancelOrderTemplateSubject;

	@Value("${mail.BuyerCancelOrderEmail.template}")
	private String buyerCancelOrderTemplate;
	
	@Value("${mail.SellerCancelOrderEmail.subject}")
	private String sellerCancelOrderTemplateSubject;

	@Value("${mail.SellerCancelOrderEmail.template}")
	private String sellerCancelOrderTemplate;
	
	@Value("${mail.SellerCancelOrderFromBuyerEmail.template}")
	private String sellerCancelOrderFromBuyerTemplate;

	@Value("${mail.buyerCancelOrdeFromBuyerTemplate.template}")
	private String buyerCancelOrdeFromBuyerTemplate;
	
	@Value("${mail.SellerCancelOrderFromBuyerEmail.subject}")
	private String sellerCancelOrderFromBuyerTemplateSubject;
	
	@Value("${mail.BuyerCancelOrderFromBuyerEmail.subject}")
	private String buyerCancelOrderFromBuyerTemplateSubject;
	
	 @Value("${aws.endpointUrl}")
	 private String s3BasetUrl;
	 
	 @Value("${aws.s3.bucket}")
	 private String s3BucketName;
	
	@Autowired
	AmazonClient amazonClient;
	
	@Autowired
	StateRepository stateRepository;
	
	@Autowired
	ShippoTransactionDetailsRepository shippoTransactionDetailsRepository;

	@Autowired
	private AvalaraClient avalaraClient;

	@Autowired
	private AvalaraTxnSummaryRepository avalaraTxnSummaryRepository;

	@Autowired
	private AvalaraTxnLineSummaryRepository avalaraTxnLineSummaryRepository;
	
	@Autowired
	private DeliveryChargeRepository deliveryChargeRepository;
	
	@Autowired
	ProductImageRepository productImageRepository;
	
	//Buyer cancel template load
	@Value("${aws.endpointUrl}")
	private String awsendpointUrl;
		
	@Value("${aws.s3.bucket}")
	private String awsbucketName;
		
	@Value("${mail.sellerCancelOrderToBuyerTemplateDeliveryType.template}")
	private String sellerCancelOrderToBuyerTemplateDeliveryType;
		
	@Value("${mail.sellerCancelOrderEmailTemplateDeliveryType.template}")
	private String sellerCancelOrderEmailTemplateDeliveryType;
	
	@Autowired
	UserImageRepository userImageRepository;
	
	@Autowired
	AuthenticationConfig authenticationConfig;

	@Override
	public Response saveVendor(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl saveVendor----starts----"+vendorAddressRequest);
		boolean sendMail = false;
		if (vendorAddressRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} else {
			User accessUser = userService.getUserByAccessToken();
			if (CommonUtils.integersCompare(accessUser.getUserId(), vendorAddressRequest.getUserId()) != 0) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getName())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_NAME_EMPTY,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getIsDeliveryEnable())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_ENABLE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (vendorAddressRequest.getIsDeliveryEnable()) {

			if (StringUtils.isEmpty(vendorAddressRequest.getMinDeliveryAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MIN_DELIVERY_AMOUNT_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getDeliveryChargeLessMinAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL,
						Constant.DELIVERY_CHARGE_LESS_MIN_AMOUNT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getMaxDeliveryDistance())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MAXIMUM_DELIVERY_DISTANCE_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

		}

		if (StringUtils.isEmpty(vendorAddressRequest.getLine1())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.LINE1_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCity())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CITY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getStateId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATE_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCountry())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.COUNTRY_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Vendor vendor = new Vendor();
		User user = userRepository.findByUserId(vendorAddressRequest.getUserId());
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		} else {
			Vendor oldVendor = vendorRepository.findByUserUserId(user.getUserId());
			if (oldVendor != null) {
				vendor.setVendorId(oldVendor.getVendorId());
				vendor.setCardNumber(oldVendor.getCardNumber());
				vendor.setStripeAccountId(oldVendor.getStripeAccountId());
				vendor.setStripePaymentMethodId(oldVendor.getStripePaymentMethodId());
				vendor.setPaymentStatus(oldVendor.getPaymentStatus());
			} else {
				vendor.setVendorId(vendorAddressRequest.getId());
				vendor.setPaymentStatus(false);
				sendMail = true;
			}
		}
		vendor.setUser(user);
		vendor.setUrl(vendorAddressRequest.getUrl());
		vendor.setName(vendorAddressRequest.getName());
		vendor.setShortDescription(vendorAddressRequest.getShortDescription());
		vendor.setMinDeliveryAmount(vendorAddressRequest.getMinDeliveryAmount());
		vendor.setDeliveryChargeLessMinAmount(vendorAddressRequest.getDeliveryChargeLessMinAmount());
		vendor.setMaxDeliveryDistance(vendorAddressRequest.getMaxDeliveryDistance());
		vendor.setIsDeliveryEnable(vendorAddressRequest.getIsDeliveryEnable());
		vendor.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		vendor.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		vendor.setAddressStatus(true);
		vendor.setProfileStatus(true);
		Vendor savedVendor = vendorRepository.save(vendor);

		// Save Address
		//saveAddress(vendorAddressRequest, savedVendor);

		// Send registration email code
		// User user = userRepository.findByUserId(vendorAddressRequest.getUserId());
		if (sendMail) {
			sendVendorRegMail(vendor.getUser().getEmail(), user.getFirstName(), vendor.getName());
		}

		// Save Vendor Images

		if (vendorAddressRequest.getImages() != null) {
			for (Images image : vendorAddressRequest.getImages()) {
				System.out.println("mage.getType()>>>" + image.getType());
				boolean isMoved = imageService.moveFilesFromS3(image.getImageId(), savedVendor.getVendorId(),
						Constant.SOURCE_VENDOR, image.getType());
				if (isMoved) {
					VendorImage vendorImages = new VendorImage();
					if (image.getImageId() != null) {
						Images vendorImage = imageRepository.findByImageId(image.getImageId());
						vendorImages.setImage(vendorImage);
					}
					if (savedVendor.getVendorId() != null) {
						Vendor checkVendor = vendorRepository.findByVendorId(savedVendor.getVendorId());
						vendorImages.setVendor(checkVendor);
					}
					vendorImages.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorImages.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorImageRepository.save(vendorImages);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}

		}
		logger.info("VendorServiceImpl saveVendor----ends----");
		return ResponseHelper.getSuccessResponse("", vendor, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response saveVendorNew(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl saveVendorNew----starts----"+vendorAddressRequest);
		boolean sendMail = false;
		if (vendorAddressRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} else {
			User accessUser = userService.getUserByAccessToken();
			if (CommonUtils.integersCompare(accessUser.getUserId(), vendorAddressRequest.getUserId()) != 0) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getName())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_NAME_EMPTY,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getIsDeliveryEnable())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_ENABLE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (vendorAddressRequest.getIsDeliveryEnable()) {

			if (StringUtils.isEmpty(vendorAddressRequest.getMinDeliveryAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MIN_DELIVERY_AMOUNT_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getDeliveryChargeLessMinAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL,
						Constant.DELIVERY_CHARGE_LESS_MIN_AMOUNT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getMaxDeliveryDistance())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MAXIMUM_DELIVERY_DISTANCE_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

		}

		Vendor vendor = new Vendor();
		User user = userRepository.findByUserId(vendorAddressRequest.getUserId());
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		} else {
			Vendor oldVendor = vendorRepository.findByUserUserId(user.getUserId());
			if (oldVendor != null) {
				vendor.setVendorId(oldVendor.getVendorId());
				vendor.setCardNumber(oldVendor.getCardNumber());
				vendor.setStripeAccountId(oldVendor.getStripeAccountId());
				vendor.setStripePaymentMethodId(oldVendor.getStripePaymentMethodId());
				vendor.setPaymentStatus(oldVendor.getPaymentStatus());
			} else {
				vendor.setVendorId(vendorAddressRequest.getId());
				vendor.setPaymentStatus(false);
				sendMail = true;
			}
		}
		vendor.setUser(user);
		vendor.setUrl(vendorAddressRequest.getUrl());
		vendor.setName(vendorAddressRequest.getName());
		vendor.setShortDescription(vendorAddressRequest.getShortDescription());
		vendor.setMinDeliveryAmount(vendorAddressRequest.getMinDeliveryAmount());
		vendor.setDeliveryChargeLessMinAmount(vendorAddressRequest.getDeliveryChargeLessMinAmount());
		vendor.setMaxDeliveryDistance(vendorAddressRequest.getMaxDeliveryDistance());
		vendor.setPreferredCourier(vendorAddressRequest.getPreferredCourier());
		vendor.setIsDeliveryEnable(vendorAddressRequest.getIsDeliveryEnable());
		vendor.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		vendor.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		vendor.setProfileStatus(true);
		Vendor savedVendor = vendorRepository.save(vendor);

		// Send registration email code
		if (sendMail) {
			sendVendorRegMail(vendor.getUser().getEmail(), user.getFirstName(), vendor.getName());
		}

		// Save Vendor Images
		if (vendorAddressRequest.getImages() != null) {
			for (Images image : vendorAddressRequest.getImages()) {
				System.out.println("mage.getType()>>>" + image.getType());
				boolean isMoved = imageService.moveFilesFromS3(image.getImageId(), savedVendor.getVendorId(),
						Constant.SOURCE_VENDOR, image.getType());
				if (isMoved) {
					VendorImage vendorImages = new VendorImage();
					if (image.getImageId() != null) {
						Images vendorImage = imageRepository.findByImageId(image.getImageId());
						vendorImages.setImage(vendorImage);
					}
					if (savedVendor.getVendorId() != null) {
						Vendor checkVendor = vendorRepository.findByVendorId(savedVendor.getVendorId());
						vendorImages.setVendor(checkVendor);
					}
					vendorImages.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorImages.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorImageRepository.save(vendorImages);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}

		}
		logger.info("VendorServiceImpl saveVendorNew----ends----");
		return ResponseHelper.getSuccessResponse(Constant.SAVE_VENDOR, vendor, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response deleteByVendorId(Integer id) throws Exception {
		logger.info("VendorServiceImpl deleteByVendorId----starts----"+id);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor != null && CommonUtils.integersCompare(existingVendor.getVendorId(), id) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = null;
		vendor = vendorRepository.findByVendorId(id);

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		// vendorAddressRepository.deleteVendorAddressByVendorId(id);
		// vendorRepository.deleteById(id);
		logger.info("VendorServiceImpl deleteByVendorId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.DELETE_VENDOR, Collections.<String, Object>emptyMap(), 200,
				null);
	}

	@Override
	public Response findVendorById(Integer id) throws Exception {
		logger.info("VendorServiceImpl findVendorById----starts----"+id);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor != null && CommonUtils.integersCompare(existingVendor.getVendorId(), id) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = null;

		vendor = vendorRepository.findByVendorId(id);

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		List<Address> vendorAddress = addressRepository.getVendorAddress(vendor.getVendorId());
		vendor.setAddress(vendorAddress);
		List<VendorImage> vendorImage = vendorImageRepository.findByVendorVendorIdAndIsActive(vendor.getVendorId(),
				true);
		vendor.setVendorImage(vendorImage);
		logger.info("VendorServiceImpl findVendorById----ends----"+id);
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				VendorConverterHelper.getResponseFromEntity(vendor), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getVendorByUserId(Integer id, boolean afterLogin) throws Exception {
		logger.info("VendorServiceImpl getVendorByUserId----starts----"+id);
		Stripe.apiKey = stripeApiKey;
		User accessUser = authenticationConfig.getUserByAccessToken();
		List<Address> address = new ArrayList<>();
		// Vendor existingVendor =
		// vendorRepository.findByUserUserId(accessUser.getUserId());
		if (accessUser != null && CommonUtils.integersCompare(accessUser.getUserId(), id) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByUserUserId(id);

		if (vendor == null) {
			return ResponseHelper.getSuccessResponse(Constant.VENDOR_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
		}
		//Checks for Stripe Account status for login time only based on afterLogin "Flag" true.
		if (afterLogin && vendor.getStripeAccountId() != null && !vendor.getStripeAccountId().isEmpty()) {
			Account account = Account.retrieve(vendor.getStripeAccountId());
			if (account != null) {
				String cardPayments = account.getCapabilities().getCardPayments();
				String transfers = account.getCapabilities().getTransfers();
				if (!Strings.isNullOrEmpty(cardPayments) && !Strings.isNullOrEmpty(transfers)
						&& cardPayments.equalsIgnoreCase("active") && transfers.equalsIgnoreCase("active")) {
					vendor.setPaymentStatus(true);
				} else {
					vendor.setPaymentStatus(false);
				}
				vendor = vendorRepository.save(vendor);
			}
		}
		//List<Address> vendorAddress = addressRepository.getVendorAddress(vendor.getVendorId());
		//vendor.setAddress(vendorAddress);
		List<VendorAddress> vendorAddressList = vendorAddressRepository.findByVendorVendorId(vendor.getVendorId());
		for(VendorAddress vendorAddress : vendorAddressList) {
			vendorAddress.getAddress().setType(vendorAddress.getType());
			address.add(vendorAddress.getAddress());
		}
		vendor.setAddress(address);
		List<VendorImage> vendorImage = vendorImageRepository.findByVendorVendorIdAndIsActive(vendor.getVendorId(),
				true);
		System.out.println("vendorImage>>" + vendorImage);
		vendor.setVendorImage(vendorImage);
		UserImage userImage = userImageRepository.findByUserUserIdAndStatus(id, true);
		if (userImage != null) {
			userImage.setUserId(id);
			User vendorUser = vendor.getUser();
			vendorUser.setUserImage(userImage);
		}	
		logger.info("VendorServiceImpl getVendorByUserId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				VendorConverterHelper.getResponseFromEntity(vendor), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response findAll() throws Exception {
		logger.info("VendorServiceImpl findAll----starts----");
		List<Vendor> list = new ArrayList<>();
		Iterable<Vendor> vendorList = vendorRepository.findAll();
		if (vendorList == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		for (Vendor vendor : vendorList) {
			List<VendorImage> vendorImageList = vendorImageRepository
					.findByVendorVendorIdAndIsActive(vendor.getVendorId(), true);
			vendor.setVendorImage(vendorImageList);
			list.add(vendor);
		}
		logger.info("VendorServiceImpl findAll----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				VendorConverterHelper.getResponseListFromEntity(list), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response updateAddress(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl updateAddress----starts----"+vendorAddressRequest);
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,1001);
		}
		if(vendorAddressRequest.getAddressId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ADDRESS_ID_REQUIRED, Constant.RESPONSE_EMPTY_DATA,1001);
		}
		if(vendorAddressRequest.getLatitude() == null || vendorAddressRequest.getLatitude() == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SOMETHING_WENT_WRONG,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(vendorAddressRequest.getLongitude() == null || vendorAddressRequest.getLongitude() == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SOMETHING_WENT_WRONG,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		VendorAddress oldVendorAddress = vendorAddressRepository.findByVendorVendorIdAndAddressId(vendor.getVendorId(),vendorAddressRequest.getAddressId());
		if (oldVendorAddress != null) {
			Address address = addressRepository.findAddressById(oldVendorAddress.getAddress().getId());
			if(address==null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,1001);
			}
			address.setLine1(vendorAddressRequest.getLine1());
			address.setLine2(vendorAddressRequest.getLine2());
			address.setCity(vendorAddressRequest.getCity());
			address.setDistrict(vendorAddressRequest.getDistrict());
			address.setStateId(vendorAddressRequest.getStateId());
			address.setZipcode(vendorAddressRequest.getZipcode());
			address.setCountry(vendorAddressRequest.getCountry());
			address.setLatitude(vendorAddressRequest.getLatitude());
			address.setLongitude(vendorAddressRequest.getLongitude());
			address.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			address.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			address.setInstruction(vendorAddressRequest.getInstruction());
			address.setLocationName(vendorAddressRequest.getLocationName());
			addressRepository.save(address);
			vendor.setAddressStatus(true);
			vendorRepository.save(vendor);
			if (vendorAddressRequest.getType() != null && !vendorAddressRequest.getType().isEmpty()
					&& oldVendorAddress.getType() != null && !oldVendorAddress.getType().isEmpty()
					&& !oldVendorAddress.getType().equalsIgnoreCase(Constant.VENDOR_ADDRESS_TYPE)) {
				VendorAddress vendorAddress = new VendorAddress();
				vendorAddress.setId(oldVendorAddress.getId());
				vendorAddress.setAddress(address);
				vendorAddress.setVendor(vendor);
				vendorAddress.setType(vendorAddressRequest.getType());
				vendorAddressRepository.save(vendorAddress);
			}
		}
		logger.info("VendorServiceImpl updateAddress----ends----");
		return ResponseHelper.getSuccessResponse(Constant.UPDATE_VENDOR_ADDRESS,
				Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response saveAddress(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl saveAddress----starts----"+vendorAddressRequest);
		if(vendorAddressRequest.getId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(vendorAddressRequest.getId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(vendorAddressRequest.getLine1())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.LINE1_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCity())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CITY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getStateId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATE_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCountry())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.COUNTRY_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getType())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ADDRESS_TYPE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(vendorAddressRequest.getLatitude() == null || vendorAddressRequest.getLatitude() == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SOMETHING_WENT_WRONG,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(vendorAddressRequest.getLongitude() == null || vendorAddressRequest.getLongitude() == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SOMETHING_WENT_WRONG,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		List<VendorAddress> oldVendorAddress = vendorAddressRepository.findByVendorVendorId(vendorAddressRequest.getId());
		if(!CommonUtils.IsNullOrEmpty(oldVendorAddress) && oldVendorAddress.size()>=10) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ADDRESS_SHOULD_NOT_BE_GREATER_THAN_TEN,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Constant.VENDOR_ADDRESS_TYPE.equalsIgnoreCase(vendorAddressRequest.getType())) {
			Optional<VendorAddress> primaryAddressPresent = oldVendorAddress.stream().filter(vendorAddress -> Constant.VENDOR_ADDRESS_TYPE.equalsIgnoreCase(vendorAddress.getType())).findAny();
			if (primaryAddressPresent.isPresent()) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_PRIMARY_ADDRESS_EXIST,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}
			Address address = new Address();
			address.setLine1(vendorAddressRequest.getLine1());
			address.setLine2(vendorAddressRequest.getLine2());
			address.setCity(vendorAddressRequest.getCity());
			address.setDistrict(vendorAddressRequest.getDistrict());
			address.setStateId(vendorAddressRequest.getStateId());
			address.setZipcode(vendorAddressRequest.getZipcode());
			address.setCountry(vendorAddressRequest.getCountry());
			address.setInstruction(vendorAddressRequest.getInstruction());
			address.setLatitude(vendorAddressRequest.getLatitude());
			address.setLongitude(vendorAddressRequest.getLongitude());
			address.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			address.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			address.setInstruction(vendorAddressRequest.getInstruction());
			address.setLocationName(vendorAddressRequest.getLocationName());
			// address.setVendor(savedVendor);
			Address savedAddress = addressRepository.save(address);
			VendorAddress vendorAddress = new VendorAddress();
			vendorAddress.setAddress(savedAddress);
			vendorAddress.setVendor(vendor);
			vendorAddress.setType(vendorAddressRequest.getType());
			vendorAddressRepository.save(vendorAddress);
		vendor.setAddressStatus(true);
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl saveAddress----ends----");
		return ResponseHelper.getSuccessResponse(Constant.SAVE_VENDOR_ADDRESS,
				Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);

	}

	@Async("specificTaskExecutor")
	@Override
	public void sendVendorRegMail(String email, String firstName, String name) {
		logger.info("VendorServiceImpl sendVendorRegMail----starts----"+email,firstName,name);
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("imgUrl", mailHeaderImage);
			mailMap.put("name", name);
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			Template mailTemplate = config.getTemplate(vendorRegistrationEmailTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			// Call Mail Service
			notificationMap.put("userMail", email);
			notificationMap.put("subject", vendorRegistrationEmailSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//					500);
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		logger.info("VendorServiceImpl sendVendorRegMail----ends----");
	}

	@Override
	public Response savePayment(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl savePayment----starts----"+vendorAddressRequest);
		Stripe.apiKey = stripeApiKey;

		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		
		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (Strings.isNullOrEmpty(vendorAddressRequest.getCardNumber())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CARD_NUMBER_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(existingVendor.getVendorId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		String stripePaymentMethodId = vendorAddressRequest.getStripePaymentMethodId();

		CustomerCreateParams customerParams = CustomerCreateParams.builder().setEmail(accessUser.getEmail())
				.setDescription("Desc").setName(accessUser.getFirstName()).build();
		Customer customer = Customer.create(customerParams);

		PaymentMethod pm = PaymentMethod.retrieve(stripePaymentMethodId);

		Map<String, Object> customer_params = new HashMap<>();
		customer_params.put("customer", customer.getId());

		PaymentMethod updatedPaymentMethod = pm.attach(customer_params);

		String cust = updatedPaymentMethod.getCustomer();

		vendor.setStripeAccountId(cust); // FIXME change the name stripe account id to stripe customer id
		vendor.setStripePaymentMethodId(stripePaymentMethodId);

		vendor.setCardNumber(vendorAddressRequest.getCardNumber());
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl savePayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PAYMENT_ID_SAVED_SUCCESS,
				Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response stripeMakePayment(PaymentRequest paymentRequest) throws Exception {
		logger.info("VendorServiceImpl stripeMakePayment----starts----"+paymentRequest);
		Stripe.apiKey = stripeApiKey;

		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Strip Cusstomer Id", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		PaymentResponse paymentResponse = new PaymentResponse();

		PaymentIntentCreateParams paymentIntent = PaymentIntentCreateParams.builder().setCurrency(currencyType)
				.setAmount(Long.valueOf(subscriptionFee)).setPaymentMethod(vendor.getStripePaymentMethodId())
				.setCustomer(vendor.getStripeAccountId()).setConfirm(true).setOffSession(true)
				.setDescription("Vendor Subscription Fee").build();

		PaymentIntent paymentIntentRes = new PaymentIntent();
		try {
			paymentIntentRes = PaymentIntent.create(paymentIntent);

			SellerPayment sellerPayment = new SellerPayment();
			Instant instant = Instant.ofEpochSecond(paymentIntentRes.getCreated());
			Timestamp transactionDate = Timestamp.from(instant);

			sellerPayment.setVendor(vendor);
			sellerPayment.setTransactionId(paymentIntentRes.getId());
			sellerPayment.setPaymentReason(paymentIntentRes.getDescription());
			sellerPayment.setAmount(paymentIntentRes.getAmount().doubleValue());
			sellerPayment.setTransactionDate(transactionDate);
			sellerPayment = sellerPaymentRepository.save(sellerPayment);
			
			System.out.println("---Payment Status---->"+paymentIntentRes.getStatus());
			
			if("succeeded".equalsIgnoreCase(paymentIntentRes.getStatus()) ) {
				vendor.setIsSubscriptionPaid(true);
				vendor.setPaidAt(transactionDate);
				vendor = vendorRepository.save(vendor);
			}
			
			paymentResponse.setTransactionId(sellerPayment.getTransactionId());
			paymentResponse.setAmount(sellerPayment.getAmount());
			paymentResponse.setPaymentReason(sellerPayment.getPaymentReason());
			paymentResponse.setVendorId(vendor.getVendorId());
			paymentResponse.setTransactionDate(transactionDate);

		} catch (CardException e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Stripe Card error-->" + e.getCode(),
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} catch (InvalidRequestException e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid payment method id-->" + e.getCode(),
					Constant.RESPONSE_EMPTY_DATA, 1001);

		}
		logger.info("VendorServiceImpl stripeMakePayment----ends----");
		return ResponseHelper.getSuccessResponse("Payment done", paymentResponse, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getChartCount(ReportSearchRequest searchRequest) throws Exception {
		logger.info("VendorServiceImpl getChartCount----starts----"+searchRequest);
		Map<String, Object> map = new HashMap<>();
		List<AdminResponse> adminResponse = productSearchRepository.getChartCount(searchRequest,Constant.NEW);
		List<AdminResponse> cancelOrder = productSearchRepository.getChartCount(searchRequest,Constant.ORDER_STATUS_CANCELLED);
		List<AdminResponse> deliveredOrder = productSearchRepository.getChartCount(searchRequest,Constant.ORDER_STATUS_DELIVERED);
		map.put("Received", adminResponse);
		map.put("Cancelled", cancelOrder);
		map.put("Delivered", deliveredOrder);
		logger.info("VendorServiceImpl getChartCount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,map,200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response updateProfile(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl updateProfile----starts----"+vendorAddressRequest);
		if (vendorAddressRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getUserId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} else {
			User accessUser = authenticationConfig.getUserByAccessToken();
			if (CommonUtils.integersCompare(accessUser.getUserId(), vendorAddressRequest.getUserId()) != 0) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getName())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_NAME_EMPTY,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getIsDeliveryEnable())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.DELIVERY_ENABLE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (vendorAddressRequest.getIsDeliveryEnable()) {

			if (StringUtils.isEmpty(vendorAddressRequest.getMinDeliveryAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MIN_DELIVERY_AMOUNT_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getDeliveryChargeLessMinAmount())) {
				throw new BusinessException(Constant.RESPONSE_FAIL,
						Constant.DELIVERY_CHARGE_LESS_MIN_AMOUNT_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA, 1001);
			}

			if (StringUtils.isEmpty(vendorAddressRequest.getMaxDeliveryDistance())) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MAXIMUM_DELIVERY_DISTANCE_IS_REQUIRED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}

		}

		User user = userRepository.findByUserId(vendorAddressRequest.getUserId());
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(vendorAddressRequest.getId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		vendor.setUser(user);
		vendor.setUrl(vendorAddressRequest.getUrl());
		vendor.setName(vendorAddressRequest.getName());
		vendor.setShortDescription(vendorAddressRequest.getShortDescription());
		vendor.setMinDeliveryAmount(vendorAddressRequest.getMinDeliveryAmount());
		vendor.setDeliveryChargeLessMinAmount(vendorAddressRequest.getDeliveryChargeLessMinAmount());
		vendor.setMaxDeliveryDistance(vendorAddressRequest.getMaxDeliveryDistance());
		vendor.setIsDeliveryEnable(vendorAddressRequest.getIsDeliveryEnable());
		vendor.setPreferredCourier(vendorAddressRequest.getPreferredCourier());
		vendor.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		vendor = vendorRepository.save(vendor);

		// Save Vendor Images
		if (vendorAddressRequest.getImages() != null) {
			for (Images image : vendorAddressRequest.getImages()) {
				System.out.println("mage.getType()>>>" + image.getType());
				boolean isMoved = imageService.moveFilesFromS3(image.getImageId(), vendor.getVendorId(),
						Constant.SOURCE_VENDOR, image.getType());
				if (isMoved) {
					VendorImage vendorImage;
					List<VendorImage> vendorImageList = vendorImageRepository.findByImageImageId(image.getImageId());
					if (vendorImageList != null && vendorImageList.size() > 0) {
						vendorImageList.sort((o1, o2) -> o2.getCreatedAt().compareTo(o1.getCreatedAt()));
						vendorImage = vendorImageList.get(0);
						vendorImageList.remove(vendorImage);
						if (!vendorImageList.isEmpty()) {
							vendorImageRepository.deleteAll(vendorImageList);
						}
					} else {
						vendorImage = new VendorImage();
						vendorImage.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					}
					if (image.getImageId() != null) {
						Images vImage = imageRepository.findByImageId(image.getImageId());
						vendorImage.setImage(vImage);
					}
					if (vendor.getVendorId() != null) {
						Vendor checkVendor = vendorRepository.findByVendorId(vendor.getVendorId());
						vendorImage.setVendor(checkVendor);
					}
					vendorImage.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					vendorImageRepository.save(vendorImage);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}

		}
		logger.info("VendorServiceImpl updateProfile----ends----");
		return ResponseHelper.getSuccessResponse(Constant.VENDOR_PROFILE_UPDATED_SUCCESSFULLY, vendor, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response profileStatusUpdate() throws Exception {
		logger.info("VendorServiceImpl profileStatusUpdate----starts----");
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		vendor.setProfileStatus(true);
		
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl profileStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PROFILE_STATUS_UPDATED, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);

	}
	
	@Override
	public Response addressStatusUpdate() throws Exception {
		logger.info("VendorServiceImpl addressStatusUpdate----starts----");
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		vendor.setAddressStatus(true);
		
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl addressStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ADDRESS_STATUS_UPDATED, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);

	}
	
	@Override
	public Response scheduleStatusUpdate() throws Exception {
		logger.info("VendorServiceImpl scheduleStatusUpdate----starts----");
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		vendor.setScheduleStatus(true);
		
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl scheduleStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.SCHEDULE_STATUS_UPDATED, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);

	}
	
	
	@Override
	public Response getProductCategoryAttribute() throws Exception {
		logger.info("VendorServiceImpl scheduleStatusUpdate----starts----");
		List<ProductCategoryAttribute> productCategoryAttribute = productCategoryAttributeRepository.findAll();
		logger.info("VendorServiceImpl scheduleStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				VendorConverterHelper.getProductAttributeResponseFromEntity(productCategoryAttribute), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response cancelPayment(PaymentRequest paymentRequest) throws Exception {
		logger.info("VendorServiceImpl cancelPayment----starts----"+paymentRequest);
		Discount discount = null;
		Stripe.apiKey = stripeApiKey;
		Map<String, Integer> map = new LinkedHashMap<>();
		Refund refund = null;
		Double value=0.0;
		Double deliveryFee =0.0;
		Orders order = ordersRepository.findOrdersByOrderId(paymentRequest.getOrderId());
		if (order == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (Strings.isNullOrEmpty(order.getTransactionId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.TRANSACTION_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		//Delivery amount return cancel order for seller end logic
		if (order.getDeliveryMode().equals("Delivery")) {
			deliveryFee = setDeliveryFeeOrders(order);
			log.info("deliveryFee for seller cancel order"+deliveryFee);
			value = order.getOrderAmount() + order.getShippingCost() + order.getTotalTax() + deliveryFee;
		} else {
			value = order.getOrderAmount() + order.getShippingCost() + order.getTotalTax();
		}
		if (order.getDiscountAmount() != null) {
			value = value - order.getDiscountAmount();
		}
		log.info("value for seller cancel order"+value);
		long totalAmount = (long) (value * Integer.parseInt(usdToCents));
		log.info("totalAmount value for seller cancel order"+totalAmount);
		refund = Refund.create(RefundCreateParams.builder().setAmount(totalAmount)
			.setPaymentIntent(order.getTransactionId()).build());
		if ( "succeeded".equalsIgnoreCase(refund.getStatus()) ) {
			TransactionStatus transactionStatus = transactionStatusRepository
					.findByTransactionId(order.getTransactionId());
			if (transactionStatus != null) {
				transactionStatus.setPaymentReason(paymentRequest.getReason());
				transactionStatus.setTransactionId(refund.getId());
				transactionStatusRepository.save(transactionStatus);
			}
			order.setOrderStatus(Constant.ORDER_STATUS_CANCELLED);
			order.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			order.setTotalDeliveryCharge(deliveryFee);
			ordersRepository.save(order);
			if ("Shipping".equalsIgnoreCase(order.getDeliveryMode())) {
				ShippoTransactionDetails ShippoTransactionDetail = shippoTransactionDetailsRepository.findByOrderId(paymentRequest.getOrderId().toString());
				if (ShippoTransactionDetail != null && ShippoTransactionDetail.getTransactionObject() != null) {
					HashMap<String, Object> createRefundMap = new HashMap<String, Object>();
					createRefundMap.put("transaction", ShippoTransactionDetail.getTransactionObject());
					createRefundMap.put("async", false);
					Refund refundShippo = Refund.create(createRefundMap);
					ShippoTransactionDetail.setFlex02(null != refundShippo.getStatus() ? refundShippo.getStatus().toString() : "");
				} else {
					ShippoTransactionDetail.setCreatedAt(null);
				}
				shippoTransactionDetailsRepository.save(ShippoTransactionDetail);
			}
			//Discount details fetched based on discountId
			if (order.getParentOrderId() != null && order.getParentOrderId() != 0) {						
				DiscountRedemption discountRedemption = discountRedemptionRepository.findByParentOrderId(order.getParentOrderId());
				if (discountRedemption != null) {
					Integer discountId = discountRedemption.getDiscount().getId();							
					discount = discountRepository.findDiscountById(discountId);
				}						
			}
			
			
			// Cancel Avalara_transaction summary from seller end.
			//cancelAvalaraTransactionSummerSeller(order);
			
			//Update delivery_charge status refund flag.
			// Send mail
			if (order.getDeliveryMode().equals("Delivery")) {
				List<Orders> deliveryList = new ArrayList<Orders>();
				if (order.getDeliveryCharge() != null) {
					int deliveryChargeId = order.getDeliveryCharge().getDeliveryChargeId();
					DeliveryCharge deliveryCharge = deliveryChargeRepository.findByDeliveryChargeId(deliveryChargeId);
					if(deliveryCharge.getIsDelivered()==false && deliveryCharge.getDeliveryChargeRefund()==false) {
					deliveryCharge.setDeliveryChargeRefund(true);
					deliveryCharge.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					deliveryChargeRepository.save(deliveryCharge);
					}
				}
				deliveryList.add(order);
				sendCancelOrderSellerForDeliveryOrder(deliveryList, paymentRequest.getReason(),discount,order);
				sendCancelOrderToBuyerForDeliveryOrder(deliveryList, paymentRequest.getReason(),discount,order);
			}else {
				sendCanceOrderBuyer(order, paymentRequest.getReason(), discount);
				sendCanceOrderToVendor(order, paymentRequest.getReason());
			}
			if(!CommonUtils.IsNullOrEmpty(order.getOrderItems())) {
				for (OrderItem orderItem : order.getOrderItems()) {
					updateOrAddProductUnitCount(orderItem.getProduct(), orderItem.getQuantity());
				}
			}
		} else {
			map.put("key", paymentRequest.getOrderId());
		}
		if(CommonUtils.IsNullOrEmptyMap(map)) {
			logger.info("VendorServiceImpl cancelPayment----ends----");
			return ResponseHelper.getSuccessResponse(Constant.PAYMENT_REFUNDED, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
		} else {
			logger.info("VendorServiceImpl cancelPayment----ends----");
			return ResponseHelper.getSuccessResponse(Constant.PAYMENT_FAILED, map, 200, Constant.RESPONSE_SUCCESS);
		}
	}
	private void sendCancelOrderSellerForDeliveryOrder(List<Orders> deliveryList, String reason, Discount discount,
			Orders order) throws ParseException {
		logger.info("VendorServiceImpl sendCancelOrderSellerForDeliveryOrder----starts----"+deliveryList,reason);
		Double totalAmount = 0.0;
		Long totalOrderAmount = 0L;
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();	
		List<Product> orderItemList = new ArrayList<>();
		BuyerOrderResponse orderMail = new BuyerOrderResponse();
		List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
		mailMap.put("reason", null != reason ? reason : "");
		mailMap.put("sellerName", order.getVendor().getUser().getFirstName()); // Seller Name
		mailMap.put("buyerName", order.getUser().getFirstName());
		mailMap.put("dateOfCancellation", LocalDateTime.now().format(Constant.MAIL_DATE_FORMATTER));		
		mailMap.put("orderNo", order.getOrderId());
		mailMap.put("orderNumber", order.getOrderNumber());		
		mailMap.put("orderItem", order.getOrderItems());
		mailMap.put("vendorName", order.getVendor().getName());
		mailMap.put("placedOn", CommonUtils.convertTimeStamptoStringFormat(order.getOrderDate()));
		mailMap.put("trackingCode", order.getTrackingNumber());
		mailMap.put("deliveryOption", order.getDeliveryOption());
		mailMap.put("deliveryMode", order.getDeliveryMode());
		mailMap.put("timeLine", order.getExpectedScheduleDate());
		mailMap.put("Line1", null != order.getShippingLine1() ? order.getShippingLine1() : "");
		mailMap.put("Line2", null != order.getShippingLine2() ? order.getShippingLine2() : "");
		mailMap.put("city", null != order.getShippingCity() ? order.getShippingCity() : "");
		mailMap.put("zipcode", null != order.getShippingZipcode() ? order.getShippingZipcode() : "");
		mailMap.put("country", null != order.getShippingCountry() ? order.getShippingCountry() : "");
		State state = stateRepository.findStateById(order.getShippingStateId());
		if (state != null) {
			mailMap.put("state", state.getName());
		}	
		
		// product details set logic for all orders
		Double refundTotalAmount = 0.0;
		for (Orders deliveryItems : deliveryList) {
			if(deliveryItems.getOrderId()== order.getOrderId()) {
			if (!CommonUtils.IsNullOrEmpty(deliveryItems.getOrderItems())) {
				for (OrderItem orderItem : deliveryItems.getOrderItems()) {
					if (orderItem != null) {
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						product.setQuantity(orderItem.getQuantity());
						Double productTotalAmount = 0.0;
						productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
						totalAmount = totalAmount + orderItem.getPrice();
						product.setProductTotalAmount(productTotalAmount);
						Double discountAmount = deliveryItems.getDiscountAmount() != null ? deliveryItems.getDiscountAmount() : 0;						
						product.setTax(orderItem.getTax());
						product.setDiscountAmount(discountAmount);				
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						double shippingCostWithTotalAmt = deliveryItems.getOrderAmount() + deliveryItems.getShippingCost();
						if (deliveryItems.getDiscountAmount() != null) {
							shippingCostWithTotalAmt = shippingCostWithTotalAmt - deliveryItems.getDiscountAmount();
						}
						product.setTotalAmount(shippingCostWithTotalAmt + deliveryItems.getTotalTax());
						refundTotalAmount = refundTotalAmount + product.getTotalAmount();
						log.info("refund amount order based:"+refundTotalAmount);
						List<ProductImage> productImageList = new ArrayList<>();							
						productImageList = productImageRepository.findByProductProductIdAndIsActive(orderItem.getProduct().getProductId(), true);							
						product = CommonUtils.productImageURLForMailTemplate(product, productImageList);
						if (discount != null && discount.getName() != null && !discount.getName().isEmpty()) {
							mailMap.put("discountName", discount.getName());
						} else {
							mailMap.put("discountName","");
						}		
						mailMap.put("discountAmount",deliveryItems.getDiscountAmount());
						
						if (deliveryItems.getScheduleDateTime() != null && !deliveryItems.getDeliveryMode().equals("Shipping")) {							
							String[] arr = deliveryItems.getScheduleDateTime().split(" ");
							if(arr.length==1) {
								product.setDeliveryTime(arr[0].toString());
							} else {
								String day = CommonUtils.convertTimeStamptoStringFormat(CommonUtils.stringToTimeStampWithOutTimes(arr[0].toString()));
								product.setDeliveryTime(day+" "+arr[1]+" "+arr[2]+" "+arr[3]+" "+arr[4]+" "+arr[5]);
							}
						}
						
						orderItemList.add(product);
					}
				}
			}
			}
		}
		
		orderMail.setProductList(orderItemList);
		buyerOrder.add(orderMail);
		mailMap.put("buyerOrder", buyerOrder);
		// Delivery charge amount set for seller mail
		if (order.getDeliveryMode().equals("Delivery") && order.getDeliveryCharge() != null) {
			mailMap.put("deliveryFee", order.getDeliveryCharge().getDeliveryChargeAmt());
		}else {
			mailMap.put("deliveryFee",0.0);
		}
		Double deliveryCharge = 0.0;
		if (order.getDeliveryCharge() != null ) {
			deliveryCharge = deliveryCharge + order.getTotalDeliveryCharge();
		}
		log.info("seller refundamount"+refundTotalAmount+deliveryCharge);
		mailMap.put("refundTotalAmount", refundTotalAmount+deliveryCharge);
		
		try {
			Template mailTemplate = config.getTemplate(sellerCancelOrderEmailTemplateDeliveryType);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", order.getVendor().getUser().getEmail());
			notificationMap.put("subject", sellerCancelOrderTemplateSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				log.info("Mail Sending Failed");
			}
		} catch (IOException | TemplateException e) {			
			e.printStackTrace();
		}
		logger.info("VendorServiceImpl sendCancelOrderSellerForDeliveryOrder----ends----");		

		
	}

	private void sendCancelOrderToBuyerForDeliveryOrder(List<Orders> deliveryList, String reason, Discount discount,
			Orders order) throws ParseException {
	logger.info("VendorServiceImpl sendCancelOrderToBuyerForDeliveryOrder----starts----"+deliveryList,reason);
		
		Double orderTotalAmount = 0.0;
		
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();	
		List<Product> orderItemList = new ArrayList<>();
		BuyerOrderResponse orderMail = new BuyerOrderResponse();
		List<BuyerOrderResponse> buyerOrder = new ArrayList<>();
		
		mailMap.put("reason", null != reason ? reason : "");
		mailMap.put("buyerName", order.getUser().getFirstName());
		mailMap.put("dateOfCancellation", LocalDateTime.now().format(Constant.MAIL_DATE_FORMATTER));		
		mailMap.put("orderNo", order.getOrderId());
		mailMap.put("orderNumber", order.getOrderNumber());		
		mailMap.put("orderItem", order.getOrderItems());
		mailMap.put("vendorName", order.getVendor().getName());
		mailMap.put("placedOn", CommonUtils.convertTimeStamptoStringFormat(order.getOrderDate()));
		mailMap.put("trackingCode", order.getTrackingNumber());
		mailMap.put("deliveryOption", order.getDeliveryOption());
		mailMap.put("deliveryMode", order.getDeliveryMode());
		mailMap.put("timeLine", order.getExpectedScheduleDate());
		mailMap.put("Line1", null != order.getShippingLine1() ? order.getShippingLine1() : "");
		mailMap.put("Line2", null != order.getShippingLine2() ? order.getShippingLine2() : "");
		mailMap.put("city", null != order.getShippingCity() ? order.getShippingCity() : "");
		mailMap.put("zipcode", null != order.getShippingZipcode() ? order.getShippingZipcode() : "");
		mailMap.put("country", null != order.getShippingCountry() ? order.getShippingCountry() : "");
		State state = stateRepository.findStateById(order.getShippingStateId());
		if (state != null) {
			mailMap.put("state", state.getName());
		}	
		
		// product details set logic for all orders		
		Double refundTotalAmount = 0.0;
		for (Orders deliveryItems : deliveryList) {
			if (!CommonUtils.IsNullOrEmpty(deliveryItems.getOrderItems())) {
				for (OrderItem orderItem : deliveryItems.getOrderItems()) {
					if (orderItem != null) {
						Double totalAmount = 0.0;
						Product product = new Product();
						product.setProductName(orderItem.getProductName());
						product.setPrice(orderItem.getPrice());
						product.setDeliveryMode(orderItem.getDeliveryMode());
						product.setDeliveryTime(orderItem.getExpectedScheduleDay());
						product.setQuantity(orderItem.getQuantity());
						Double productTotalAmount = 0.0;
						productTotalAmount = orderItem.getQuantity() * orderItem.getPrice();
						totalAmount = totalAmount + orderItem.getPrice();
						product.setProductTotalAmount(productTotalAmount);
						Double discountAmount = deliveryItems.getDiscountAmount() != null ? deliveryItems.getDiscountAmount() : 0;						
						product.setTax(orderItem.getTax());
						product.setDiscountAmount(discountAmount);				
						product.setProductDescription(orderItem.getProduct().getProductDescription());
						if (Strings.isNullOrEmpty(orderItem.getProduct().getProductDescription())) {
							product.setProductDescription("Good");
						}
						double shippingCostWithTotalAmt = deliveryItems.getOrderAmount() + deliveryItems.getShippingCost();
						if (deliveryItems.getDiscountAmount() != null) {
							shippingCostWithTotalAmt = shippingCostWithTotalAmt - deliveryItems.getDiscountAmount();
						}
						product.setTotalAmount(shippingCostWithTotalAmt + deliveryItems.getTotalTax());
						
						refundTotalAmount = refundTotalAmount + product.getTotalAmount();
						log.info("refund amount order based:"+refundTotalAmount);
						List<ProductImage> productImageList = new ArrayList<>();							
						productImageList = productImageRepository.findByProductProductIdAndIsActive(orderItem.getProduct().getProductId(), true);							
						product = CommonUtils.productImageURLForMailTemplate(product, productImageList);
						if (discount != null && discount.getName() != null && !discount.getName().isEmpty()) {
							mailMap.put("discountName", discount.getName());
						} else {
							mailMap.put("discountName","");
						}		
						mailMap.put("discountAmount",deliveryItems.getDiscountAmount());
						
						if (deliveryItems.getScheduleDateTime() != null && !deliveryItems.getDeliveryMode().equals("Shipping")) {							
							String[] arr = deliveryItems.getScheduleDateTime().split(" ");
							if(arr.length==1) {
								product.setDeliveryTime(arr[0].toString());
							} else {
								String day = CommonUtils.convertTimeStamptoStringFormat(CommonUtils.stringToTimeStampWithOutTimes(arr[0].toString()));
								product.setDeliveryTime(day+" "+arr[1]+" "+arr[2]+" "+arr[3]+" "+arr[4]+" "+arr[5]);
							}
						}
						
						orderItemList.add(product);
					}
				}
			}
			//order total amount set
			double totalAmt = deliveryItems.getOrderAmount() + deliveryItems.getShippingCost() + deliveryItems.getTotalTax();
			orderTotalAmount = orderTotalAmount + totalAmt;
			System.out.println("orderTotalAmount"+orderTotalAmount);
		}
		
		orderMail.setProductList(orderItemList);
		buyerOrder.add(orderMail);
		
		mailMap.put("buyerOrder", buyerOrder);
		// Delivery charge amount set for buyer mail
		if (order.getDeliveryMode().equals("Delivery") && order.getDeliveryCharge() != null) {
			mailMap.put("deliveryFee", order.getDeliveryCharge().getDeliveryChargeAmt());
		}else {
			mailMap.put("deliveryFee",0.0);
		}
		Double deliveryCharge = 0.0;
		if (order.getDeliveryCharge() != null ) {
			deliveryCharge = deliveryCharge + order.getTotalDeliveryCharge();
		}
		log.info("buyer refundamount"+refundTotalAmount+deliveryCharge);
		mailMap.put("refundTotalAmount", refundTotalAmount+deliveryCharge);	
		try {
			Template mailTemplate = config.getTemplate(sellerCancelOrderToBuyerTemplateDeliveryType);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", order.getUser().getEmail());
			notificationMap.put("subject", buyerCancelOrderTemplateSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				log.info("Mail Sending Failed");
			}

		} catch (IOException | TemplateException e) {			
			e.printStackTrace();
		}
		logger.info("VendorServiceImpl sendCancelOrderToBuyerForDeliveryOrder----ends----");
		
	}

	private Double setDeliveryFeeOrders(Orders order) {
		Map<Integer,String> resultOrder= new HashMap<>();
		Double deliveryChargeAmount = 0.0; 
		if (order == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (order.getDeliveryCharge() != null) {
			int deliveryChargeId = order.getDeliveryCharge().getDeliveryChargeId();
			List<Orders> orders = ordersRepository.findAllByDeliveryChargeDeliveryChargeId(deliveryChargeId);
			if (orders != null) {
				for (Orders orderDetails : orders) {
					if (order.getOrderId().intValue() != orderDetails.getOrderId().intValue()) {
						if (orderDetails.getOrderStatus().equals("CONFIRMED")) {
							resultOrder.put(orderDetails.getOrderId(), "CONFIRMED");
						} else if (orderDetails.getOrderStatus().equals("DELIVERED")) {
							resultOrder.put(orderDetails.getOrderId(), "DELIVERED");
						} else if (orderDetails.getOrderStatus().equals(Constant.ORDER_STATUS_CANCELLED)) {
							resultOrder.put(orderDetails.getOrderId(), Constant.ORDER_STATUS_CANCELLED);
						}
					}
				}
				if (resultOrder.containsValue("DELIVERED") || resultOrder.containsValue("CONFIRMED")) {
					deliveryChargeAmount = 0.0;
				} else if (resultOrder.containsValue(Constant.ORDER_STATUS_CANCELLED)) {
					deliveryChargeAmount = order.getDeliveryCharge().getDeliveryChargeAmt();
				} else if (orders.size() == 1 && order.getDeliveryCharge().getIsDelivered() == false
						&& order.getDeliveryCharge().getDeliveryChargeRefund() == false) {
					deliveryChargeAmount = order.getDeliveryCharge().getDeliveryChargeAmt();
				}
			}
		}
		return deliveryChargeAmount;
	}

	public void cancelAvalaraTransactionSummerSeller(Orders order) {
		try {
			String transactionCode = String.valueOf(order.getOrderId());
			AvalaraRefundTransactionRequest refundTransactionRequest = AvalaraHelper.buildRefundTxnRequest(order);
			AvalaraCreateTransactionResponse avalaraRefundTransactionResponse = avalaraClient
					.refundTransaction(refundTransactionRequest, Constant.TAX_CALCULATE_COMPANY_NAME, transactionCode);

			AvalaraTxnSummary refundAvalaraTxnSummary = AvalaraHelper
					.createTransactionSummary(avalaraRefundTransactionResponse);
			refundAvalaraTxnSummary.setOrderDate(CommonUtils.convertTimeStamptoStringAvalara(order.getOrderDate()));
			refundAvalaraTxnSummary.setSellerName(order.getVendor().getName());
			refundAvalaraTxnSummary.setSellerState(order.getVendorStateCode());
			refundAvalaraTxnSummary.setOrder(order);
			avalaraTxnSummaryRepository.save(refundAvalaraTxnSummary);
			Set<AvalaraTxnLineSummary> refundLines = AvalaraHelper
					.createTransactionLineSummary(avalaraRefundTransactionResponse, refundAvalaraTxnSummary, order);
			avalaraTxnLineSummaryRepository.saveAll(refundLines);

		} catch (Exception e) {
			logger.error("An error occurred during Avalara transaction cancel from seller end: " + e.getMessage());
		}
	}
	
	public void updateOrAddProductUnitCount(Product product, Integer quantity) {
		logger.info("VendorServiceImpl updateOrAddProductUnitCount----starts----" + product, quantity);
		if (!product.getMadeToOrder()) {
			int totalUnitCount = product.getUnitCount();
			int calculatedCount = totalUnitCount + quantity;
			product.setUnitCount(calculatedCount);
			productRepository.save(product);
		}
		logger.info("VendorServiceImpl updateOrAddProductUnitCount----ends----");
	}
	

	@Async("specificTaskExecutor")
	public void sendCanceOrderBuyer(Orders order, String reason, Discount discount) {
		logger.info("VendorServiceImpl sendCanceOrderBuyer----starts----"+order,reason);
		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();
		mailMap.put("reason", null!=reason?reason : ""); // Seller Name
		mailMap.put("buyerName", order.getUser().getFirstName()); 
		mailMap.put("sellerName", order.getVendor().getUser().getFirstName()); // Seller Name
		mailMap.put("sellerCompanyName", order.getVendor().getName());
		mailMap.put("dateOfCancellation",LocalDateTime.now().format(Constant.MAIL_DATE_FORMATTER));
		mailMap.put("order",order);
		mailMap.put("orderNo", order.getOrderId()); 
		mailMap.put("orderNumber", order.getOrderNumber());
		List<Orders> orderList =new ArrayList<Orders>();
		orderList.add(order);
		mailMap.put("buyerOrder", orderList);
		mailMap.put("orderItem", order.getOrderItems());
		order.getOrderItems().get(0).getVendor().getName();
		
		
		//Added by raja
				Double productTotalAmount = order.getOrderItems().stream().mapToDouble(p->p.getQuantity()*p.getPrice()).sum();
				System.out.println("predectionamount===>"+productTotalAmount);
				mailMap.put("vendorName", order.getVendor().getName());
				mailMap.put("placedOn", CommonUtils.convertTimeStamptoStringFormat(order.getOrderDate()));
				mailMap.put("trackingCode", order.getTrackingNumber());
				mailMap.put("deliveryOption", order.getDeliveryOption());
				mailMap.put("deliveryMode", order.getDeliveryMode());
				mailMap.put("timeLine", order.getExpectedScheduleDate());
				//mailMap.put("vendorAddress", order.getVendor().getAddress().get(0));
				Optional<Address> address = addressRepository.findById(order.getUser().getUserId());
				//mailMap.put("buyerAddress", address.get().getName() + address.get().getLine1()+ address.get().getLine2()+ address.get().getDistrict()+ address.get().getCity()+ address.get().getZipcode());
				mailMap.put("itemSubTotal", productTotalAmount);
				mailMap.put("shippingCost", order.getShippingCost());
				double shippingCostWithTotalAmt = order.getOrderAmount() + order.getShippingCost();
				if (order.getDiscountAmount() != null) {
					shippingCostWithTotalAmt = shippingCostWithTotalAmt - order.getDiscountAmount();
				}
				mailMap.put("shippingCostWithTotalAmt", shippingCostWithTotalAmt + order.getTotalTax());
				mailMap.put("totalTax", order.getTotalTax());

				mailMap.put("Line1", null!=order.getShippingLine1()?order.getShippingLine1():"");
				mailMap.put("Line2", null!=order.getShippingLine2()?order.getShippingLine2():"");
				mailMap.put("city", null!=order.getShippingCity()?order.getShippingCity():"");
				mailMap.put("zipcode", null!=order.getShippingZipcode()?order.getShippingZipcode():"");
				mailMap.put("country", null!=order.getShippingCountry()?order.getShippingCountry():"");
				State state = stateRepository.findStateById(order.getShippingStateId());	
				if(state!=null) {
					mailMap.put("state", state.getName());
				}
				if (discount != null && discount.getName() != null && !discount.getName().isEmpty()) {
					mailMap.put("discountName", discount.getName());
				} else {
					mailMap.put("discountName","");
				}
				mailMap.put("discountAmount",order.getDiscountAmount());
		try {
			//Template mailTemplate = config.getTemplate(sellerCancelOrderTemplate);
			Template mailTemplate = config.getTemplate(sellerCancelOrderFromBuyerTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			//notificationMap.put("userMail","sankaraasn@gmail.com"/*order.getUser().getEmail()*/);
			notificationMap.put("userMail",order.getUser().getEmail());
			//notificationMap.put("subject", sellerCancelOrderTemplateSubject);
			notificationMap.put("subject", sellerCancelOrderFromBuyerTemplateSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				log.info("Mail Sending Failed");
			}

		} catch (IOException | TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Call Mail Service
		logger.info("VendorServiceImpl sendCanceOrderBuyer----ends----");
	}

	
	@Async("specificTaskExecutor")
	public void sendCanceOrderToVendor(Orders order, String reason) {
		logger.info("VendorServiceImpl sendCanceOrderToVendor----starts----"+order,reason);

		Map<String, Object> mailMap = new HashMap<>();
		Map<String, Object> notificationMap = new HashMap<>();
		mailMap.put("reason", null!=reason?reason : ""); // Seller Name
		mailMap.put("sellerName", order.getVendor().getUser().getFirstName()); // Seller Name
		mailMap.put("sellerCompanyName", order.getVendor().getName());
		mailMap.put("dateOfCancellation",LocalDateTime.now().format(Constant.MAIL_DATE_FORMATTER));
		List<Orders> orderList =new ArrayList<Orders>();
		orderList.add(order);
		mailMap.put("buyerOrder", orderList);
		mailMap.put("orderNo", order.getOrderId()); 
		mailMap.put("orderNumber", order.getOrderNumber());
		mailMap.put("orderItem", order.getOrderItems());
		mailMap.put("buyerName", order.getUser().getFirstName() ); 
		
		//Added by raja
		Double productTotalAmount = order.getOrderItems().stream().mapToDouble(p->p.getQuantity()*p.getPrice()).sum();
		System.out.println("predectionamount===>"+productTotalAmount);
		mailMap.put("vendorName", order.getVendor().getName());
		mailMap.put("placedOn", CommonUtils.convertTimeStamptoStringFormat(order.getOrderDate()));
		mailMap.put("trackingCode", order.getTrackingNumber());
		mailMap.put("deliveryOption", order.getDeliveryOption());
		mailMap.put("deliveryMode", order.getDeliveryMode());
		mailMap.put("timeLine", order.getExpectedScheduleDate());
		//mailMap.put("vendorAddress", order.getVendor().getAddress().get(0));
		Optional<Address> address = addressRepository.findById(order.getUser().getUserId());
		//mailMap.put("buyerAddress", address.get().getName() + address.get().getLine1()+ address.get().getLine2()+ address.get().getDistrict()+ address.get().getCity()+ address.get().getZipcode());
		mailMap.put("itemSubTotal", productTotalAmount);
		mailMap.put("shippingCost", order.getShippingCost());
		mailMap.put("shippingCostWithTotalAmt", order.getOrderAmount()+order.getShippingCost()+order.getTotalTax());
		mailMap.put("totalTax", order.getTotalTax());
		
		mailMap.put("Line1", null!=order.getShippingLine1()?order.getShippingLine1():"");
		mailMap.put("Line2", null!=order.getShippingLine2()?order.getShippingLine2():"");
		mailMap.put("city", null!=order.getShippingCity()?order.getShippingCity():"");
		mailMap.put("zipcode", null!=order.getShippingZipcode()?order.getShippingZipcode():"");
		mailMap.put("country", null!=order.getShippingCountry()?order.getShippingCountry():"");
		State state = stateRepository.findStateById(order.getShippingStateId());	
		if(state!=null) {
			mailMap.put("state", state.getName());
		}
		
		try {
			//Template mailTemplate = config.getTemplate(buyerCancelOrderTemplate);
			Template mailTemplate = config.getTemplate(buyerCancelOrdeFromBuyerTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", order.getVendor().getUser().getEmail() );
			notificationMap.put("subject", sellerCancelOrderTemplateSubject);
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				log.info("Mail Sending Failed");
			}

		} catch (IOException | TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("VendorServiceImpl sendCanceOrderToVendor----ends----");
		// Call Mail Service

	}
	
	@Override
	public Response getProductThresholdExceeded() throws Exception {
		logger.info("VendorServiceImpl getProductThresholdExceeded----starts----");
		// TODO Auto-generated method stub
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if(existingVendor!=null) {
			List<Map<String, Object>> productList = productRepository.getProductThresholdExceeded(true,
					existingVendor.getVendorId(),s3BasetUrl+"/"+s3BucketName);
			logger.info("VendorServiceImpl getProductThresholdExceeded----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, productList, 200, Constant.RESPONSE_SUCCESS);
		}else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
	}

	@Override
	public JsonNode TrackOrder(Tracking trackingRequest) throws Exception {
		logger.info("VendorServiceImpl TrackOrder----starts----"+trackingRequest);
		// TODO Auto-generated method stub
		Response res = new Response();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		 String profile = System.getProperty("profile");
		 System.out.println("profile==>"+profile);
		 if("dev".equals(profile)) {
			 trackingRequest.setCarrier(carrier);
			 trackingRequest.setTracking_number(trackingnumber);
		 }
		 String jvalue = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(
				Track.getTrackingInfo(trackingRequest.getCarrier(), trackingRequest.getTracking_number(), shippoKey));
		JsonNode json = mapper.readTree(jvalue);
		logger.info("VendorServiceImpl TrackOrder----ends----");
		return json;
	}
	
	@Override
	public Response getUserById(Integer userId) throws Exception {
		logger.info("VendorServiceImpl getUserById----starts----"+userId);
		User user = userRepository.findByUserId(userId);
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("VendorServiceImpl getUserById----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, user, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response savesubscription(VendorAddressRequest vendorAddressRequest) throws Exception {
		// TODO Auto-generated method stub
		logger.info("VendorServiceImpl savesubscription----starts----"+vendorAddressRequest);
		Stripe.apiKey = stripeApiKey;

		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		
		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

//		if (Strings.isNullOrEmpty(vendorAddressRequest.getCardNumber())) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CARD_NUMBER_IS_REQUIRED,
//					Constant.RESPONSE_EMPTY_DATA, 1001);
//		}
		Vendor vendor = vendorRepository.findByVendorId(existingVendor.getVendorId());

		
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		String CustId ="";Customer customer;
		if(null!=vendor.getCustomerId()) {
			CustId = vendor.getCustomerId();
		}else {
		Map<String, Object> params = new HashMap<>();
		//params.put( "description", "My First Test Customer (created for API docs)");
		params.put( "email",vendor.getUser().getEmail());
		params.put( "name",vendor.getUser().getFirstName());
		customer = Customer.create(params);
		CustId = customer.getId();
		vendor.setCustomerId(CustId);
		vendor = vendorRepository.save(vendor);
		}
		String message ="";
		 try {
		      // Set the default payment method on the customer
		      PaymentMethod pm = PaymentMethod.retrieve(vendorAddressRequest.getStripePaymentMethodId());
		      pm.attach(
		        PaymentMethodAttachParams
		          .builder()
		          .setCustomer(CustId)
		          .build()
		      );
		    } catch (CardException  e) {
		    	e.printStackTrace();
		      // Since it's a decline, CardException will be caught
		      Map<String, String> responseErrorMessage = new HashMap<>();
		      message = e.getLocalizedMessage().split(";")[0];
		      responseErrorMessage.put("message", message);
		      responseErrorMessage.put("getmessage", e.getMessage());
		      responseErrorMessage.put("getCode", e.getCode());
		      responseErrorMessage.put("getDeclineCode", e.getDeclineCode());
		      throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		    }  catch (RateLimitException e) {
		    	// Too many requests made to the API too quickly
		        Map<String, String> responseErrorMessage = new HashMap<>();
			      message = e.getLocalizedMessage().split(";")[0];
			      responseErrorMessage.put("message", message);
			      responseErrorMessage.put("getmessage", e.getMessage());
			      responseErrorMessage.put("getCode", e.getCode());
			      throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		    	} catch (InvalidRequestException e) {
		    	  // Invalid parameters were supplied to Stripe's API
			        Map<String, String> responseErrorMessage = new HashMap<>();
				      message = e.getLocalizedMessage().split(";")[0];
				      responseErrorMessage.put("message", message);
				      responseErrorMessage.put("getmessage", e.getMessage());
				      responseErrorMessage.put("getCode", e.getCode());
				      throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		    	} catch (AuthenticationException e) {
		    	  // Authentication with Stripe's API failed
		    	  // (maybe you changed API keys recently)
			        Map<String, String> responseErrorMessage = new HashMap<>();
				      message = e.getLocalizedMessage().split(";")[0];
				      responseErrorMessage.put("message", message);
				      responseErrorMessage.put("getmessage", e.getMessage());
				      responseErrorMessage.put("getCode", e.getCode());
				      throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		    	} catch (StripeException e) {
		    	  // Display a very generic error to the user, and maybe send
		    	  // yourself an email
			        Map<String, String> responseErrorMessage = new HashMap<>();
				      message = e.getLocalizedMessage().split(";")[0];
				      responseErrorMessage.put("message", message);
				      responseErrorMessage.put("getmessage", e.getMessage());
				      responseErrorMessage.put("getCode", e.getCode());
				      throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		    	} catch (Exception e) {
		    	  // Something else happened, completely unrelated to Stripe
		    	}		
		
		  customer = Customer.retrieve(CustId);
		  
		  CustomerUpdateParams customerUpdateParams = CustomerUpdateParams
			      .builder()
			      .setInvoiceSettings(
			        CustomerUpdateParams
			          .InvoiceSettings.builder()
			          .setDefaultPaymentMethod(vendorAddressRequest.getStripePaymentMethodId())
			          .build())
			      .build();
		    customer.update(customerUpdateParams);
		// Create the subscription
	    SubscriptionCreateParams subCreateParams = SubscriptionCreateParams
	      .builder()
	      .addItem(
	        SubscriptionCreateParams
	          .Item.builder()
	          .setPrice(vendorAddressRequest.getPriceId())  //price id
	          .build())
	      .setCustomer(CustId)
	      .addAllExpand(Arrays.asList("latest_invoice.payment_intent"))
	      .build();

	    Subscription subscription = Subscription.create(subCreateParams);
	    
	    vendor.setCustomerId(CustId);
	    vendor.setPriceId(vendorAddressRequest.getPriceId());
	    vendor.setSubscriptionId(subscription.getId());
	    
		vendorRepository.save(vendor);
		
		userService.sendUserStripeMailToEatzosAdmin(vendor.getUser().getEmail(),vendor.getUser().getMobileNumber(),vendor.getUser().getFirstName());

		logger.info("VendorServiceImpl savesubscription----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PAYMENT_ID_SAVED_SUCCESS,
				Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getProductCategoryAttributeConfiguration() throws Exception {
		logger.info("CacheServiceImpl getProductCategoryAttributeConfiguration----starts----");
		List<ProductAttribute> productCategoryAttribute = productAttributeRepository.findAll();
		logger.info("CacheServiceImpl getProductCategoryAttributeConfiguration----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, productCategoryAttribute, 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response saveMultiAddress(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl saveMultiAddress----starts----"+vendorAddressRequest);
		if(vendorAddressRequest.getId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(vendorAddressRequest.getId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(vendorAddressRequest.getLine1())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.LINE1_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCity())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CITY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getStateId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATE_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCountry())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.COUNTRY_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
	//	List<VendorAddress> oldVendorAddress = vendorAddressRepository.findByVendorVendorId(vendorAddressRequest.getId());
		Address address = new Address();
		address.setLine1(vendorAddressRequest.getLine1());
		address.setLine2(vendorAddressRequest.getLine2());
		address.setCity(vendorAddressRequest.getCity());
		address.setDistrict(vendorAddressRequest.getDistrict());
		address.setStateId(vendorAddressRequest.getStateId());
		address.setZipcode(vendorAddressRequest.getZipcode());
		address.setCountry(vendorAddressRequest.getCountry());
		address.setInstruction(vendorAddressRequest.getInstruction());
		address.setLatitude(vendorAddressRequest.getLatitude());
		address.setLongitude(vendorAddressRequest.getLongitude());
		address.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		// address.setVendor(savedVendor);
		Address savedAddress = addressRepository.save(address);
		VendorAddress vendorAddress = new VendorAddress();
		vendorAddress.setAddress(savedAddress);
		vendorAddress.setVendor(vendor);
		vendorAddress.setType(vendorAddressRequest.getType());
		vendorAddress.setIsActive(true);
		vendorAddress.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		vendorAddressRepository.save(vendorAddress);
		vendor.setAddressStatus(true);
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl saveMultiAddress----ends----");
		return ResponseHelper.getSuccessResponse(Constant.SAVE_VENDOR_ADDRESS,
				Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response updateMultiAddress(VendorAddressRequest vendorAddressRequest) throws Exception {
		logger.info("VendorServiceImpl updateMultiAddress----starts----"+vendorAddressRequest);
		if(vendorAddressRequest.getId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(vendorAddressRequest.getAddressId()==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(vendorAddressRequest.getId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(vendorAddressRequest.getLine1())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.LINE1_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCity())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CITY_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getStateId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATE_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(vendorAddressRequest.getCountry())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.COUNTRY_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Optional<Address> addressId = addressRepository.findById(vendorAddressRequest.getAddressId());
		Address address = addressId.get();
		if(address==null ) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		VendorAddress vendorAddress = vendorAddressRepository.findByAddressId(vendorAddressRequest.getId());
		if (vendorAddress == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(!Strings.isNullOrEmpty(vendorAddress.getType()) && vendorAddress.getType().equals(Constant.PRIMARY)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRIMARY_ADDRESS_CAN_NOT_BE_EDITED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		address.setLine1(vendorAddressRequest.getLine1());
		address.setLine2(vendorAddressRequest.getLine2());
		address.setCity(vendorAddressRequest.getCity());
		address.setDistrict(vendorAddressRequest.getDistrict());
		address.setStateId(vendorAddressRequest.getStateId());
		address.setZipcode(vendorAddressRequest.getZipcode());
		address.setCountry(vendorAddressRequest.getCountry());
		address.setInstruction(vendorAddressRequest.getInstruction());
		address.setLatitude(vendorAddressRequest.getLatitude());
		address.setLongitude(vendorAddressRequest.getLongitude());
		address.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		// address.setVendor(savedVendor);
		addressRepository.save(address);
		vendorAddress.setType(vendorAddressRequest.getType());
		vendorAddress.setIsActive(true);
		vendorAddress.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		vendorAddressRepository.save(vendorAddress);
		logger.info("VendorServiceImpl updateMultiAddress----ends----");
		return ResponseHelper.getSuccessResponse(Constant.SAVE_VENDOR_ADDRESS,
				Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response deleteAddress(Integer addressId) throws Exception {
		logger.info("VendorServiceImpl deleteAddress----starts----");
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if(addressId==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ADDRESS_ID_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		VendorAddress vendorAddress = vendorAddressRepository.findByVendorVendorIdAndAddressId(vendor.getVendorId(), addressId);
		if(vendorAddress==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ADDRESS_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<VendorSchedule> scheduleList = vendorScheduleRepository.findByVendorAddressId(vendorAddress.getId());
		if(!CommonUtils.IsNullOrEmpty(scheduleList) && scheduleList.size()>0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ADDRESS_CAN_NOT_BE_DELETED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		vendorAddressRepository.delete(vendorAddress);
		addressRepository.delete(vendorAddress.getAddress());
		logger.info("VendorServiceImpl deleteAddress----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ADDRESS_DELETED,
				"", 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response updatePaymentMethod(PaymentMethodUpdateRequest paymentUpdateReq) throws Exception {
		logger.info("VendorServiceImpl updatePaymentMethod----starts----" + paymentUpdateReq.toString());
		Stripe.apiKey = stripeApiKey;

		if (StringUtils.isEmpty(paymentUpdateReq.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(paymentUpdateReq.getStripePaymentMethodId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STRIPE_PAYMENT_METHOD_ID_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Vendor vendor = vendorRepository.findByVendorId(paymentUpdateReq.getId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		String CustId = "";
		Customer customer;
		if (null != vendor.getCustomerId()) {
			CustId = vendor.getCustomerId();
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SELLER_CUSTOMER_ID_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		String paymentMethodId = "";
		String message = "";
		try {
			// Set the default payment method on the customer
			PaymentMethod pm = PaymentMethod.retrieve(paymentUpdateReq.getStripePaymentMethodId());
			pm.attach(PaymentMethodAttachParams.builder().setCustomer(CustId).build());
			paymentMethodId = pm.getId().toString();		
			logger.info("Seller default payment method ID: " + paymentMethodId);			
		} catch (CardException e) {
			e.printStackTrace();
			// Since it's a decline, CardException will be caught
			Map<String, String> responseErrorMessage = new HashMap<>();
			message = e.getLocalizedMessage().split(";")[0];
			responseErrorMessage.put("message", message);
			responseErrorMessage.put("getmessage", e.getMessage());
			responseErrorMessage.put("getCode", e.getCode());
			responseErrorMessage.put("getDeclineCode", e.getDeclineCode());
			throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		} catch (RateLimitException e) {
			// Too many requests made to the API too quickly
			Map<String, String> responseErrorMessage = new HashMap<>();
			message = e.getLocalizedMessage().split(";")[0];
			responseErrorMessage.put("message", message);
			responseErrorMessage.put("getmessage", e.getMessage());
			responseErrorMessage.put("getCode", e.getCode());
			throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		} catch (InvalidRequestException e) {
			// Invalid parameters were supplied to Stripe's API
			Map<String, String> responseErrorMessage = new HashMap<>();
			message = e.getLocalizedMessage().split(";")[0];
			responseErrorMessage.put("message", message);
			responseErrorMessage.put("getmessage", e.getMessage());
			responseErrorMessage.put("getCode", e.getCode());
			throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		} catch (AuthenticationException e) {
			// Authentication with Stripe's API failed
			// (maybe you changed API keys recently)
			Map<String, String> responseErrorMessage = new HashMap<>();
			message = e.getLocalizedMessage().split(";")[0];
			responseErrorMessage.put("message", message);
			responseErrorMessage.put("getmessage", e.getMessage());
			responseErrorMessage.put("getCode", e.getCode());
			throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		} catch (StripeException e) {
			// Display a very generic error to the user, and maybe send
			// yourself an email
			Map<String, String> responseErrorMessage = new HashMap<>();
			message = e.getLocalizedMessage().split(";")[0];
			responseErrorMessage.put("message", message);
			responseErrorMessage.put("getmessage", e.getMessage());
			responseErrorMessage.put("getCode", e.getCode());
			throw new BusinessException(Constant.RESPONSE_FAIL, message, responseErrorMessage, 1001);
		} catch (Exception e) {
			// Something else happened, completely unrelated to Stripe
		}

		customer = Customer.retrieve(CustId);

		CustomerUpdateParams customerUpdateParams = CustomerUpdateParams.builder()
				.setInvoiceSettings(CustomerUpdateParams.InvoiceSettings.builder()
						.setDefaultPaymentMethod(paymentUpdateReq.getStripePaymentMethodId()).build())
				.build();
		customer.update(customerUpdateParams);		

		vendor.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		vendorRepository.save(vendor);
		logger.info("VendorServiceImpl updatePaymentMethod----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PAYMENT_METHOD_ID_UPDATED_SUCCESS,
				Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_SUCCESS);
	}
	
}
