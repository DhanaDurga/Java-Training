package com.eatzos.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.AvalaraHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.model.AvalaraTxnSummary;
import com.eatzos.model.User;
import com.eatzos.model.Vendor;
import com.eatzos.repository.AvalaraTxnLineSummaryRepository;
import com.eatzos.repository.AvalaraTxnSummaryRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.request.Pagination;
import com.eatzos.response.AvalaraTransactionSummaryResponse;
import com.eatzos.service.AvalaraReportingService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;

@Service
public class AvalaraReportingServiceImpl implements AvalaraReportingService {
	private static final Logger logger = LoggerFactory.getLogger(AvalaraReportingServiceImpl.class);

	@Autowired
	private AvalaraTxnSummaryRepository avalaraTxnSummaryRepository;

	@Autowired
	private AvalaraTxnLineSummaryRepository avalaraTxnLineSummaryRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private VendorRepository vendorRepository;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;

	@Override
	public Response getReportWithFilter(String orderFromDate, String orderToDate, String transferFromDate,
			String transferToDate, String vendorId, String paymentStatus, Boolean isFilter, Pagination pagination,
			String sortKey, String sortOrder, String orderStatus) {
		logger.info("AvalaraReportingServiceImpl getReportWithFilter----starts----");
		Boolean isFilterFlag = isFilter != null ? isFilter : false;
		long totalCount = 0;
		int offset = 0;
		int limit = Constant.DEFAULT_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		Sort sort = makeSortOrder(sortKey, sortOrder);
		Pageable paging = PageRequest.of(offset, limit, sort);

		List<AvalaraTxnSummary> avalaraTxnSummaries = new ArrayList<>();
		if (isFilterFlag) {
			if (orderFromDate != null && orderToDate != null && transferFromDate != null && transferToDate != null
					&& paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(orderFromDate, orderToDate,
								transferFromDate, transferToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository
						.countByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(orderFromDate,
								orderToDate, transferFromDate, transferToDate, paymentStatus, orderStatus);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndOrderOrderStatus(
						orderFromDate, orderToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndOrderOrderStatus(
						orderFromDate, orderToDate, paymentStatus, orderStatus);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(
						transferFromDate, transferToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(
						transferFromDate, transferToDate, paymentStatus, orderStatus);
			} else if (paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndOrderOrderStatus(paymentStatus,
						orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndOrderOrderStatus(paymentStatus, orderStatus);
			} else if (orderFromDate != null && orderToDate != null && transferFromDate != null
					&& transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndTaxDepositDateBetween(orderFromDate,
						orderToDate, transferFromDate, transferToDate, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndTaxDepositDateBetween(orderFromDate,
						orderToDate, transferFromDate, transferToDate);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatus(orderFromDate,
						orderToDate, paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatus(orderFromDate, orderToDate,
						paymentStatus);
			} else if (orderFromDate != null && orderToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndOrderOrderStatus(orderFromDate, orderToDate, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndOrderOrderStatus(orderFromDate,
						orderToDate, orderStatus);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatus(transferFromDate,
						transferToDate, paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatus(transferFromDate,
						transferToDate, paymentStatus);
			} else if (transferFromDate != null && transferToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndOrderOrderStatus(transferFromDate,
						transferToDate, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndOrderOrderStatus(transferFromDate,
						transferToDate, orderStatus);
			} else if (orderFromDate != null && orderToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetween(orderFromDate, orderToDate,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetween(orderFromDate, orderToDate);
			} else if (transferFromDate != null && transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetween(transferFromDate, transferToDate,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetween(transferFromDate, transferToDate);
			} else if (paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatus(paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatus(paymentStatus);
			} else if (orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderOrderStatus(orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderOrderStatus(orderStatus);
			} else {
				logger.info("No search parameters provided.");
			}

		} else {
			avalaraTxnSummaries = avalaraTxnSummaryRepository.findAll(paging);
			totalCount = avalaraTxnSummaryRepository.count();
		}
		List<AvalaraTransactionSummaryResponse> avalaraTransactionSummaryResponses = new ArrayList<>();
		if (avalaraTxnSummaries.size() > 0) {
			avalaraTxnSummaries.forEach(avalaraTxnSummary -> {
				AvalaraTransactionSummaryResponse avalaraTransactionSummaryResponse = AvalaraHelper
						.makeAvalaraTxnSummaryResponse(avalaraTxnSummary);
				avalaraTransactionSummaryResponses.add(avalaraTransactionSummaryResponse);
			});
		}
		logger.info("AvalaraReportingServiceImpl getReportWithFilter----ends----");
		return ResponseHelper.getSuccessResponse(Constant.RESPONSE_SUCCESS,
				AvalaraHelper.getResponseListFromEntity(avalaraTransactionSummaryResponses, totalCount), 200,
				Constant.RESPONSE_SUCCESS);
	}

	private Sort makeSortOrder(String sortKey, String sortOrder) {
		Sort sort;
		if (!Strings.isNullOrEmpty(sortKey)) {
			if ("desc".equalsIgnoreCase(sortOrder)) {
				sort = Sort.by(sortKey).descending();
			} else {
				sort = Sort.by(sortKey).ascending();
			}
		} else {
			sort = Sort.by(Constant.AVALARA_TAXSUMMARY_ID).descending();
		}
		return sort;
	}
	
	
	@Override
	public Response getReportWithFilterVendor(String orderFromDate, String orderToDate, String transferFromDate,
			String transferToDate, String vendorId, String paymentStatus, Boolean isFilter, Pagination pagination,
			String sortKey, String sortOrder, String orderStatus) throws Exception {
		logger.info("AvalaraReportingServiceImpl getReportWithFilterVendor----starts----");
		
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null || vendor.getVendorId() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		String vendorIdStr= String.valueOf(vendor.getVendorId());
		
		Boolean isFilterFlag = isFilter != null ? isFilter : false;
		long totalCount = 0;
		int offset = 0;
		int limit = Constant.DEFAULT_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		Sort sort = makeSortOrder(sortKey, sortOrder);
		Pageable paging = PageRequest.of(offset, limit, sort);

		List<AvalaraTxnSummary> avalaraTxnSummaries = new ArrayList<>();
		if (isFilterFlag) {
			if (orderFromDate != null && orderToDate != null && transferFromDate != null && transferToDate != null
					&& paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,
								transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository
						.countByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate,
								orderToDate, transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						orderFromDate, orderToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						orderFromDate, orderToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(paymentStatus,
						orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(paymentStatus, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && transferFromDate != null
					&& transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, transferFromDate, transferToDate,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, transferFromDate, transferToDate,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,
						paymentStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, orderStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, paymentStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,vendorIdStr,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(transferFromDate, transferToDate,vendorIdStr,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(transferFromDate, transferToDate,vendorIdStr);
			} else if (paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndLinesMerchantSellerIdentifier(paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndLinesMerchantSellerIdentifier(paymentStatus,vendorIdStr);
			} else if (orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderOrderStatusAndLinesMerchantSellerIdentifier(orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderOrderStatusAndLinesMerchantSellerIdentifier(orderStatus,vendorIdStr);
			} else {
				logger.info("No search parameters provided.");
			}

		} else {
			avalaraTxnSummaries = avalaraTxnSummaryRepository.findByLinesMerchantSellerIdentifier(vendorIdStr,paging);
			totalCount = avalaraTxnSummaryRepository.countByLinesMerchantSellerIdentifier(vendorIdStr);
		}
		List<AvalaraTransactionSummaryResponse> avalaraTransactionSummaryResponses = new ArrayList<>();
		if (avalaraTxnSummaries.size() > 0) {
			avalaraTxnSummaries.forEach(avalaraTxnSummary -> {
				AvalaraTransactionSummaryResponse avalaraTransactionSummaryResponse = AvalaraHelper
						.makeAvalaraTxnSummaryResponse(avalaraTxnSummary);
				avalaraTransactionSummaryResponses.add(avalaraTransactionSummaryResponse);
			});
		}
		logger.info("AvalaraReportingServiceImpl getReportWithFilterVendor----ends----");
		return ResponseHelper.getSuccessResponse(Constant.RESPONSE_SUCCESS,
				AvalaraHelper.getResponseListFromEntity(avalaraTransactionSummaryResponses, totalCount), 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public void getReportWithFilterExport(HttpServletResponse response, String orderFromDate, String orderToDate, String transferFromDate,
			String transferToDate, String vendorId, String paymentStatus, Boolean isFilter, Pagination pagination,
			String sortKey, String sortOrder, String orderStatus,Boolean allTaxFlag) {

		logger.info("AvalaraReportingServiceImpl getReportWithFilterExport----starts----");
		Boolean isFilterFlag = isFilter != null ? isFilter : false;
		Boolean isAllTaxFlag = allTaxFlag != null ? allTaxFlag : false;
		long totalCount = 0;
		int offset = 0;
		int limit = Constant.DEFAULT_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		Sort sort = makeSortOrder(sortKey, sortOrder);
		Pageable paging = PageRequest.of(offset, limit, sort);

		List<AvalaraTxnSummary> avalaraTxnSummaries = new ArrayList<>();
		if (isFilterFlag) {
			if (orderFromDate != null && orderToDate != null && transferFromDate != null && transferToDate != null
					&& paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(orderFromDate, orderToDate,
								transferFromDate, transferToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository
						.countByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(orderFromDate,
								orderToDate, transferFromDate, transferToDate, paymentStatus, orderStatus);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndOrderOrderStatus(
						orderFromDate, orderToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndOrderOrderStatus(
						orderFromDate, orderToDate, paymentStatus, orderStatus);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(
						transferFromDate, transferToDate, paymentStatus, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatus(
						transferFromDate, transferToDate, paymentStatus, orderStatus);
			} else if (paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndOrderOrderStatus(paymentStatus,
						orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndOrderOrderStatus(paymentStatus, orderStatus);
			} else if (orderFromDate != null && orderToDate != null && transferFromDate != null
					&& transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndTaxDepositDateBetween(orderFromDate,
						orderToDate, transferFromDate, transferToDate, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndTaxDepositDateBetween(orderFromDate,
						orderToDate, transferFromDate, transferToDate);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatus(orderFromDate,
						orderToDate, paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatus(orderFromDate, orderToDate,
						paymentStatus);
			} else if (orderFromDate != null && orderToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndOrderOrderStatus(orderFromDate, orderToDate, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndOrderOrderStatus(orderFromDate,
						orderToDate, orderStatus);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatus(transferFromDate,
						transferToDate, paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatus(transferFromDate,
						transferToDate, paymentStatus);
			} else if (transferFromDate != null && transferToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndOrderOrderStatus(transferFromDate,
						transferToDate, orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndOrderOrderStatus(transferFromDate,
						transferToDate, orderStatus);
			} else if (orderFromDate != null && orderToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetween(orderFromDate, orderToDate,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetween(orderFromDate, orderToDate);
			} else if (transferFromDate != null && transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetween(transferFromDate, transferToDate,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetween(transferFromDate, transferToDate);
			} else if (paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatus(paymentStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatus(paymentStatus);
			} else if (orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderOrderStatus(orderStatus, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderOrderStatus(orderStatus);
			} else {
				logger.info("No search parameters provided.");
			}
		} else if (isAllTaxFlag) {
			avalaraTxnSummaries = (List<AvalaraTxnSummary>) avalaraTxnSummaryRepository.findAll();
		} else {
			avalaraTxnSummaries = avalaraTxnSummaryRepository.findAll(paging);
			totalCount = avalaraTxnSummaryRepository.count();
		}		
		avalaraTxnSummariesToCSV(response,avalaraTxnSummaries);	
	}

	private void avalaraTxnSummariesToCSV(HttpServletResponse httpResponse, List<AvalaraTxnSummary> avalaraTxnSummaries) {
		logger.info("AvalaraReportingServiceImpl avalaraTxnSummariesToCSV----starts----"+httpResponse,avalaraTxnSummaries);
		try (CSVPrinter csvPrinter = new CSVPrinter(httpResponse.getWriter(), CSVFormat.DEFAULT.withHeader(
				"Seller Name","Seller State", "Order Id", "Order Date", "Order Status","Order Amount","Tax Amount","Avalara Transaction ID","Avalara Transfer Status","Avalara Transfer Date"));) {
			for (AvalaraTxnSummary avalaraTxnSummary : avalaraTxnSummaries) {
				List<Object> data = Arrays.asList(avalaraTxnSummary.getSellerName(),avalaraTxnSummary.getSellerState(),avalaraTxnSummary.getOrder().getOrderId(),avalaraTxnSummary.getOrderDate(),avalaraTxnSummary.getOrder().getOrderStatus(),avalaraTxnSummary.getTotalAmount(),avalaraTxnSummary.getTotalTax(),avalaraTxnSummary.getTxnId(),avalaraTxnSummary.getPaymentStatus(),avalaraTxnSummary.getTaxDepositDate());				
				csvPrinter.printRecord(data);
			}
			httpResponse.setContentType("text/csv");
			httpResponse.setHeader("Content-Disposition", "attachment; file=" + getFileName("csv"));
			csvPrinter.flush();
			logger.info("AvalaraReportingServiceImpl avalaraTxnSummariesToCSV----ends----");
		} catch (Exception e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Writing CSV error!", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}	
	}
	
	private String getFileName(String extn) {
		logger.info("AvalaraReportingServiceImpl getFileName----starts----" + extn);
		String todayDate = "";
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddYYYY");
		todayDate = simpleDateFormat.format(date);
		logger.info("AvalaraReportingServiceImpl getFileName----ends----");
		return "avalara_tax_report_admin" + todayDate + "." + extn;
	}

	@Override
	public void getReportWithFilterVendorExport(HttpServletResponse response, String orderFromDate, String orderToDate,
			String transferFromDate, String transferToDate, String vendorId, String paymentStatus, Boolean isFilter,
			Pagination pagination, String sortKey, String sortOrder, String orderStatus,Boolean allTaxFlag) throws Exception {
		logger.info("AvalaraReportingServiceImpl getReportWithFilterVendorExport----starts----");
		
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null || vendor.getVendorId() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		String vendorIdStr= String.valueOf(vendor.getVendorId());
		
		Boolean isFilterFlag = isFilter != null ? isFilter : false;
		Boolean isAllTaxFlag = allTaxFlag != null ? allTaxFlag : false;
		long totalCount = 0;
		int offset = 0;
		int limit = Constant.DEFAULT_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		Sort sort = makeSortOrder(sortKey, sortOrder);
		Pageable paging = PageRequest.of(offset, limit, sort);

		List<AvalaraTxnSummary> avalaraTxnSummaries = new ArrayList<>();
		if (isFilterFlag) {
			if (orderFromDate != null && orderToDate != null && transferFromDate != null && transferToDate != null
					&& paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,
								transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository
						.countByOrderDateBetweenAndTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate,
								orderToDate, transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						orderFromDate, orderToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						orderFromDate, orderToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(
						transferFromDate, transferToDate, paymentStatus, orderStatus,vendorIdStr);
			} else if (paymentStatus != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(paymentStatus,
						orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndOrderOrderStatusAndLinesMerchantSellerIdentifier(paymentStatus, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && transferFromDate != null
					&& transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, transferFromDate, transferToDate,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, transferFromDate, transferToDate,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,
						paymentStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository
						.findByOrderDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(orderFromDate,
						orderToDate, orderStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndPaymentStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, paymentStatus,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null && orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndOrderOrderStatusAndLinesMerchantSellerIdentifier(transferFromDate,
						transferToDate, orderStatus,vendorIdStr);
			} else if (orderFromDate != null && orderToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,vendorIdStr,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderDateBetweenAndLinesMerchantSellerIdentifier(orderFromDate, orderToDate,vendorIdStr);
			} else if (transferFromDate != null && transferToDate != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(transferFromDate, transferToDate,vendorIdStr,
						paging);
				totalCount = avalaraTxnSummaryRepository.countByTaxDepositDateBetweenAndLinesMerchantSellerIdentifier(transferFromDate, transferToDate,vendorIdStr);
			} else if (paymentStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByPaymentStatusAndLinesMerchantSellerIdentifier(paymentStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByPaymentStatusAndLinesMerchantSellerIdentifier(paymentStatus,vendorIdStr);
			} else if (orderStatus != null) {
				avalaraTxnSummaries = avalaraTxnSummaryRepository.findByOrderOrderStatusAndLinesMerchantSellerIdentifier(orderStatus,vendorIdStr, paging);
				totalCount = avalaraTxnSummaryRepository.countByOrderOrderStatusAndLinesMerchantSellerIdentifier(orderStatus,vendorIdStr);
			} else {
				logger.info("No search parameters provided.");
			}

		} else if(isAllTaxFlag) {
			avalaraTxnSummaries = avalaraTxnSummaryRepository.findByLinesMerchantSellerIdentifier(vendorIdStr);
		}else {
			avalaraTxnSummaries = avalaraTxnSummaryRepository.findByLinesMerchantSellerIdentifier(vendorIdStr,paging);
			totalCount = avalaraTxnSummaryRepository.countByLinesMerchantSellerIdentifier(vendorIdStr);
		}
		avalaraTxnSummariesToCSVforVendor(response,avalaraTxnSummaries);
		
	}

	private void avalaraTxnSummariesToCSVforVendor(HttpServletResponse httpResponse,
			List<AvalaraTxnSummary> avalaraTxnSummaries) {
		logger.info("AvalaraReportingServiceImpl avalaraTxnSummariesToCSVforVendor----starts----"+httpResponse,avalaraTxnSummaries);
		try (CSVPrinter csvPrinter = new CSVPrinter(httpResponse.getWriter(), CSVFormat.DEFAULT.withHeader(
				"Order Id", "Order Date", "Order Status","Order Total","Tax Collected","Tax Deposited Status","Tax Deposit Date"));) {
			for (AvalaraTxnSummary avalaraTxnSummary : avalaraTxnSummaries) {
				List<Object> data = Arrays.asList(avalaraTxnSummary.getOrder().getOrderId(),avalaraTxnSummary.getOrderDate(),avalaraTxnSummary.getOrder().getOrderStatus(),avalaraTxnSummary.getTotalAmount(),avalaraTxnSummary.getTotalTax(),avalaraTxnSummary.getPaymentStatus(),avalaraTxnSummary.getTaxDepositDate());				
				csvPrinter.printRecord(data);
			}
			httpResponse.setContentType("text/csv");
			httpResponse.setHeader("Content-Disposition", "attachment; file=" + getFileNameVendor("csv"));
			csvPrinter.flush();
			logger.info("AvalaraReportingServiceImpl avalaraTxnSummariesToCSVforVendor----ends----");
		} catch (Exception e) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Writing CSV error!", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}	
		
	}

	private String getFileNameVendor(String extn) {
		logger.info("AvalaraReportingServiceImpl getFileNameVendor----starts----" + extn);
		String todayDate = "";
		Date date = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddYYYY");
		todayDate = simpleDateFormat.format(date);
		logger.info("AvalaraReportingServiceImpl getFileNameVendor----ends----");
		return "avalara_tax_report_vendor" + todayDate + "." + extn;
	}
}
