package com.eatzos.service.impl;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.mail.internet.InternetAddress;

import com.eatzos.request.*;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.AmazonClient;
import com.eatzos.helper.MultipartImage;
import com.eatzos.helper.NotificationHelper;
import com.eatzos.helper.ProductConverterHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.model.ActiveProductLog;
import com.eatzos.model.Category;
import com.eatzos.model.DeliveryTypeDAO;
import com.eatzos.model.Images;
import com.eatzos.model.Product;
import com.eatzos.model.ProductAuditTrail;
import com.eatzos.model.ProductImage;
import com.eatzos.model.ShipmentProgressDtlDAO;
import com.eatzos.model.SubCategory;
import com.eatzos.model.Uom;
import com.eatzos.model.User;
import com.eatzos.model.UserImage;
import com.eatzos.model.Vendor;
import com.eatzos.model.VendorImage;
import com.eatzos.repository.ActiveProductLogRepository;
import com.eatzos.repository.CategoryRepository;
import com.eatzos.repository.DeliveryTypeRepository;
import com.eatzos.repository.ImageRepository;
import com.eatzos.repository.ProductAuditTrailRepository;
import com.eatzos.repository.ProductImageRepository;
import com.eatzos.repository.ProductRepository;
import com.eatzos.repository.ShipmentProgressDtlRepository;
import com.eatzos.repository.ShippingConfigDtlRepository;
import com.eatzos.repository.SubCategoryRepository;
import com.eatzos.repository.UomRepository;
import com.eatzos.repository.UserImageRepository;
import com.eatzos.repository.UserRepository;
import com.eatzos.repository.VendorImageRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.response.ProductResponse;
import com.eatzos.response.VendorProductResponse;
import com.eatzos.service.ImageService;
import com.eatzos.service.ProductService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Service(value = "productService")
public class ProductServiceImpl implements ProductService {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	
	@Value("${mail.productInactivateTemplate.template}")
	private String productInactivateTemplate;
	
	@Value("${mail.productActivateTemplate.template}")
	private String productActivateTemplate;

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private ActiveProductLogRepository activeProductLogRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private SubCategoryRepository subCategoryRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private UomRepository uomRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	NotificationHelper notificationHelper;

	@Autowired
	private ImageService imageService;

	@Autowired
	private UserService userService;

	@Autowired
	AmazonClient amazonClient;

	@Autowired
	private ShippingConfigDtlRepository shippingConfigDtlRepository;

	@Autowired
	private VendorImageRepository vendorImageRepository;
	
	@Value("${s3.tile.folder}")
	private String tileFolder;
	
	@Value("${mail.admin.user}")
	private String adminUser;
	
	@Value("${mail.eatzos.support.user}")
	private String eatzosSupport;
	
	@Value("${seller.order.preparation.time}")
	private Integer preparationTimeLimit;
	
	@Value("${mail.ProductPendingTemplate.template}")
	private String productPendingTemplate;

	@Value("${mail.ProductPendingSubject.subject}")
	private String productPendingSubject;
	
	@Autowired
	private Configuration config;

	@Autowired
	ProductImageRepository productImageRepository;
	
	@Autowired
	ProductAuditTrailRepository productAuditTrailRepository;

	@Autowired
	ImageRepository imageRepository;

	@Autowired
	ShipmentProgressDtlRepository shipmentProgressDtlRepository;

	@Autowired
	DeliveryTypeRepository deliveryTypeRepository;

	@Value("${s3.product.folder}")
	private String productFolder;

	@Value("${s3.image.folder}")
	private String imageFolder;
	
	@Autowired
	private UserImageRepository userImageRepository;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;
	
	@Override
	public Response save(ProductSaveRequest productRequest) throws Exception {
		logger.info("ProductServiceImpl save----starts----"+productRequest);
		Product product = new Product();
		Product existingProduct = null;
		boolean imgFlag = false;
		if (productRequest == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_REQUEST, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(productRequest.getProductName())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(productRequest.getUomId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.UOM_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (StringUtils.isEmpty(productRequest.getVendorId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		} else {
			User accessUser = authenticationConfig.getUserByAccessToken();
			Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
			if (existingVendor != null
					&& CommonUtils.integersCompare(existingVendor.getVendorId(), productRequest.getVendorId()) != 0) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		}

		if (productRequest.getUnitCount() == 0 && productRequest.getMadeToOrder() == false) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.QUANTITY_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (productRequest.getPreparationTime() == null || StringUtils.isEmpty(productRequest.getPreparationTime())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PREPARATION_TIME_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (productRequest.getPreparationTime() != 0 && preparationTimeLimit <= productRequest.getPreparationTime()) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PREPARATION_TIME_LIMIT,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		List<Product> productList = null;

		if (productRequest.getProductId() == null) {
			productList = productRepository.findByProductNameAndVendorVendorId(productRequest.getProductName(),
					productRequest.getVendorId());
		} else {
			productList = productRepository.checkAlreadyExists(productRequest.getProductName(),
					productRequest.getProductId(), productRequest.getVendorId());

		}

		if (productList != null && !productList.isEmpty()) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_EXISTS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		} else {
			product.setProductId(productRequest.getProductId());
		}
		if (productRequest.getProductId() == null) {
			product.setApprovalStatus(Constant.PRODUCT_APPROVAL_STATUS_PENDING);
		} else {
			existingProduct = productRepository.findByProductId(productRequest.getProductId());
			if(existingProduct!=null) {
				if(!CommonUtils.IsNullOrEmpty(productRequest.getProductImages()) || !existingProduct.getProductName().equals(productRequest.getProductName())
						 || !existingProduct.getProductDescription().equals(productRequest.getProductDescription())) {
					product.setApprovalStatus(Constant.PRODUCT_APPROVAL_STATUS_PENDING);
				} else {
					product.setApprovalStatus(existingProduct.getApprovalStatus());
				}
			}
		}
		product.setProductId(productRequest.getProductId());

		product.setProductName(productRequest.getProductName());
		product.setProductDescription(productRequest.getProductDescription());
		product.setIsDeliverable(productRequest.getIsDeliverable());
		product.setPrice(productRequest.getPrice());
		product.setUnitCount(productRequest.getUnitCount());
		product.setMadeToOrder(productRequest.getMadeToOrder());
		if (productRequest.getPreparationTime() != null) {
			product.setPreparationTime(productRequest.getPreparationTime());
		}
		product.setStatus(productRequest.getStatus());
		product.setIsListingFeePaid(false);
		product.setAttributes(productRequest.getAttributes());
		product.setLowThreshold(productRequest.getLowThreshold());
		product.setWeight(productRequest.getWeight());
		product.setWidth(productRequest.getWidth());
		product.setLength(productRequest.getLength());
		product.setHeight(productRequest.getHeight());
		product.setMaxUnitCount(productRequest.getMaxUnitCount());
		if (productRequest.getListingFee() != null && productRequest.getListingFee() > 0) {
			product.setIsListingFeePaid(true);
		}

		product.setPaidAt(CommonUtils.GetCurrentTimeStamp());
		if (productRequest.getMadeToOrder()) {
			if (productRequest.getPreparationTime() == null) {
				product.setPreparationTime(24);
			}
		}
		Optional<Category> category = categoryRepository.findById(productRequest.getCategoryId());
		Optional<SubCategory> subCategory = subCategoryRepository.findById(productRequest.getSubCategoryId());
		Optional<Uom> uom = uomRepository.findById(productRequest.getUomId());
		Optional<Vendor> vendor = vendorRepository.findById(productRequest.getVendorId());
		if (category.isPresent()) {
			product.setCategory(category.get());
		}
		if (subCategory.isPresent()) {
			product.setSubCategory(subCategory.get());
		}
		if (uom.isPresent()) {
			product.setUom(uom.get());
		}
		if (vendor.isPresent()) {
			product.setVendor(vendor.get());
		}

		Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
		if (productRequest.getProductId() == null) {
			product.setCreatedAt(currentTime);
		} else {
			Product oldProduct = productRepository.findByProductId(productRequest.getProductId());
			product.setCreatedAt(oldProduct.getCreatedAt());
		}
		product.setUpdatedAt(currentTime);
		product = productRepository.save(product);

		List<DeliveryTypeDAO> DeliveryTypeDAOList = new ArrayList<>();

		if (productRequest.getDeliveryType().size() > 0) {
			for (DeliveryType dt : productRequest.getDeliveryType()) {
				DeliveryTypeDAO deliveryTypeDAO = new DeliveryTypeDAO();
				deliveryTypeDAO.setDeliveryTypeid(dt.getDeliveryTypeid());
				deliveryTypeDAO.setType(dt.getType());
				deliveryTypeDAO.setDescription(dt.getDescription());
				deliveryTypeDAO.setIsselected(dt.getIsselected());
				deliveryTypeDAO.setPid(product.getProductId());
				DeliveryTypeDAOList.add(deliveryTypeDAO);
			}
		}
		DeliveryTypeDAOList = deliveryTypeRepository.saveAll(DeliveryTypeDAOList);

		List<Integer> ids = new LinkedList();
		DeliveryTypeDAOList.stream().forEach((e) -> {
			if (e.getType().equalsIgnoreCase("S")) {
				ids.add(e.getDeliveryTypeid());
			}
		});

		List<ShipmentProgressDtlDAO> ShipmentProgressDtlDAOList = new ArrayList<>();
		for (DeliveryType dt : productRequest.getDeliveryType()) {
			if (dt.getType().equalsIgnoreCase("S") && dt.getIsselected() == 0) {
				List<ShipmentProgressDtlDAO> shipment = shipmentProgressDtlRepository
						.findByDelid(dt.getDeliveryTypeid());
				if (!CommonUtils.IsNullOrEmpty(shipment)) {
					shipmentProgressDtlRepository.deleteAll(shipment);
				}
			} else if (dt.getType().equalsIgnoreCase("S") && !CommonUtils.IsNullOrEmpty(dt.getInShipment())
					&& dt.getIsselected() == 1) {
				for (ShipmentProgressDtl shipmentProgressDtl : dt.getInShipment()) {
					ShipmentProgressDtlDAO shipmentProgressDtlDAO = new ShipmentProgressDtlDAO();
					shipmentProgressDtlDAO.setShipmentProgressDtlId(shipmentProgressDtl.getShipmentProgressDtlId());
					shipmentProgressDtlDAO.setBoxType(shipmentProgressDtl.getBoxType());
					shipmentProgressDtlDAO.setCarrier(shipmentProgressDtl.getCarrier());
					shipmentProgressDtlDAO.setCostPerBox(shipmentProgressDtl.getCostPerBox());
					shipmentProgressDtlDAO.setUnitCountPerBox(shipmentProgressDtl.getUnitCountPerBox());
					shipmentProgressDtlDAO.setWeightPerBox(shipmentProgressDtl.getWeightPerBox());
					shipmentProgressDtlDAO.setDelid(ids.get(0));
					ShipmentProgressDtlDAOList.add(shipmentProgressDtlDAO);
				}
			}
		}
		if (!CommonUtils.IsNullOrEmpty(ShipmentProgressDtlDAOList)) {
			ShipmentProgressDtlDAOList = shipmentProgressDtlRepository.saveAll(ShipmentProgressDtlDAOList);
		}
		ProductSaveRequest res = new ProductSaveRequest();
		BeanUtils.copyProperties(product, res);

		if (productRequest.getStatus()) {
			saveActiveProductLog(product, Constant.PRODUCT_ACTIVE);
		}
		if (product.getProductId() != null) {
			updateProductCode(product.getVendor().getVendorId(), product.getCategory().getCategoryId(),
					product.getSubCategory().getSubCategoryId(), product);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (productRequest.getProductImages() != null) {
			for (ImagesRequest imageRequest : productRequest.getProductImages()) {
				boolean isMoved = imageService.moveFilesFromS3(imageRequest.getImageId(), product.getProductId(),
						Constant.SOURCE_PRODUCT, null);
				if (isMoved) {
					imgFlag = true;
					ProductImage productImages = new ProductImage();
					Images image = imageRepository.findByImageId(imageRequest.getImageId());
					productImages.setImage(image);
					productImages.setProduct(product);
					productImages.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					productImages.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					productImageRepository.save(productImages);
					// Upload Tile Image to S3
					uploadTileImage(imageRequest.getUrl(), product.getProductId(), image.getImageId());

				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}

		}
		
		if (productRequest.getProductId() == null) {
			updateProductAuditTrail(product, "Product Saved", false, true, product.getVendor().getName());
			if(imgFlag) {
				updateProductAuditTrail(product, "Product Image Uploaded", imgFlag, false, product.getVendor().getName());
			}
		} else if(existingProduct!=null) {
			if(!existingProduct.getProductName().equals(productRequest.getProductName())
					 || !existingProduct.getProductDescription().equals(productRequest.getProductDescription())) {
				updateProductAuditTrail(product, "Product Updated", imgFlag, true, product.getVendor().getName());
			}
			if(!CommonUtils.IsNullOrEmpty(productRequest.getProductImages())) {
				updateProductAuditTrail(product, "Product Image ReUploaded", imgFlag, true, product.getVendor().getName());
			}
		}
		if(!Strings.isNullOrEmpty(product.getApprovalStatus()) &&product.getApprovalStatus().equals(Constant.PRODUCT_APPROVAL_STATUS_PENDING)) {
			sendProductPendingMail(product);
		}
		logger.info("ProductServiceImpl save----ends----");
		return ResponseHelper.getSuccessResponse(Constant.PRODUCT_SAVED, res, 200, Constant.RESPONSE_SUCCESS);

	}
	
	public void updateProductAuditTrail(Product product,String message,boolean img,boolean value,String name) throws Exception {
		logger.info("ProductServiceImpl updateProductAuditTrail----starts----");
		ProductAuditTrail ProductAuditTrail = new ProductAuditTrail(); 
		ProductAuditTrail.setComments(message);
		ProductAuditTrail.setImgUpdate(img);
		ProductAuditTrail.setProduct(product);
		ProductAuditTrail.setProductupdate(value);
		ProductAuditTrail.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
		ProductAuditTrail.setUpdatedBy(name);
		productAuditTrailRepository.save(ProductAuditTrail);
		logger.info("ProductServiceImpl updateProductAuditTrail----ends----");
	}

	public void uploadTileImage(String imageUrl, Integer productId, Integer imageId) throws Exception {
		logger.info("ProductServiceImpl uploadTileImage----starts----"+imageUrl,productId,imageId);
		BufferedImage image = null;
		String tilePath = null;
		UUID uuid = UUID.randomUUID();

		URL url = new URL(imageUrl);
		image = ImageIO.read(url);
		BufferedImage tempImg = null;
		tempImg = resizeImage(image, 100, 100);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(tempImg, "jpg", baos);
		baos.flush();

		String fileName = Paths.get((url).getPath()).getFileName().toString();
		String ext = FilenameUtils.getExtension(fileName);
		tilePath = imageFolder + productId + "/" + tileFolder + uuid;
		MultipartFile resizeMultipartFile = new MultipartImage(baos.toByteArray(), fileName, fileName, ext, 100);
		String tileUrl = amazonClient.uploadFile(resizeMultipartFile, tilePath, uuid + "." + ext);
		System.out.println(tileUrl);
		logger.info("ProductServiceImpl uploadTileImage----ends----");
	}

	public static BufferedImage resizeImage(final Image img, int width, int height) {
		logger.info("ProductServiceImpl resizeImage----starts----"+img,width,height);
		final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		final Graphics2D graphics2D = bufferedImage.createGraphics();
		graphics2D.setComposite(AlphaComposite.Src);
		// below three lines are for RenderingHints for better image quality at cost of
		// higher processing time
		graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics2D.drawImage(img, 0, 0, width, height, null);
		graphics2D.dispose();
		logger.info("ProductServiceImpl resizeImage----ends----");
		return bufferedImage;
	}

	@Override
	public Response getAll() throws Exception {
		logger.info("ProductServiceImpl getAll----starts----");
		int activeCount = 0;
		int inActiveCount = 0;
		int outOfStockCount = 0;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		System.out.println("vendorId:" + vendor.getVendorId());

		List<Product> list = new ArrayList<>();
		Iterable<Product> productList = productRepository.findByVendorVendorId(vendor.getVendorId());
		if (productList == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		for (Product product : productList) {
			if (product.getStatus()) {
				activeCount = activeCount + 1;
			} else {
				inActiveCount = inActiveCount + 1;
			}
			if (product.getIsOutOfStock()) {
				outOfStockCount = outOfStockCount + 1;
			}
			List<ProductImage> productImageList = productImageRepository
					.findByProductProductIdAndIsActive(product.getProductId(), true);
			product.setProductImage(productImageList);
			list.add(product);
		}
		List<ProductResponse> convertedProduct = ProductConverterHelper.getResponseListFromEntity(list);
		VendorProductResponse vendorProductResponse = new VendorProductResponse();
		vendorProductResponse.setProduct(convertedProduct);
		vendorProductResponse.setActiveCount(activeCount);
		vendorProductResponse.setInActiveCount(inActiveCount);
		vendorProductResponse.setOutOfStockCount(outOfStockCount);
		logger.info("ProductServiceImpl getAll----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getByProductId(Integer id) throws Exception {
		logger.info("ProductServiceImpl getByProductId----starts----"+id);
		List<DeliveryTypeDAO> DeliveryTypeDAOList = new LinkedList<>();
		List<ShipmentProgressDtlDAO> ShipmentProgressDtlDAOlst = new ArrayList<>();

		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		Product product = productRepository.findByProductId(id);
		DeliveryTypeDAOList = deliveryTypeRepository.findByPid(product.getProductId());
		List<Integer> ids = new LinkedList();
		DeliveryTypeDAOList.stream().forEach((e) -> {
			if (e.getType().equalsIgnoreCase("S")) {
				ids.add(e.getDeliveryTypeid());
			}
		});
		if (!ids.isEmpty()) {
			ShipmentProgressDtlDAOlst = shipmentProgressDtlRepository.findAll(ids.get(0));
		}

		if (existingVendor != null && product != null
				&& CommonUtils.integersCompare(existingVendor.getVendorId(), product.getVendor().getVendorId()) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		List<ProductImage> productImageList = new ArrayList<>();

		if (product == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		productImageList = productImageRepository.findByProductProductIdAndIsActive(product.getProductId(), true);
		product.setProductImage(productImageList);
		logger.info("ProductServiceImpl getByProductId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA,
				ProductConverterHelper.getResponseFromEntity(product, DeliveryTypeDAOList, ShipmentProgressDtlDAOlst),
				200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response updateStatus(ProductUpdateRequest productReq) throws Exception {
		logger.info("ProductServiceImpl updateStatus----starts----"+productReq);
		if (StringUtils.isEmpty(productReq.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(productReq.getStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		Product product = productRepository.findByProductId(productReq.getId());
		if (existingVendor != null && product != null
				&& CommonUtils.integersCompare(existingVendor.getVendorId(), product.getVendor().getVendorId()) != 0) {
			System.out.println(" existingVendor.getVendorId()>>" + existingVendor.getVendorId());
			System.out.println(" product.getVendorId()>>" + product.getVendor().getVendorId());
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		int count = 0;
		if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_ACTIVE)) {
			assert product != null;
			count = productRepository.updateStatus(true, product.getProductId(), CommonUtils.GetCurrentTimeStamp());
			saveActiveProductLog(product, Constant.PRODUCT_ACTIVE);
		} else if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
			assert product != null;
			count = productRepository.updateStatus(false, product.getProductId(), CommonUtils.GetCurrentTimeStamp());
			saveActiveProductLog(product, Constant.PRODUCT_INACTIVE);
		} else if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_OUT_OF_STOCK)) {
			assert product != null;
			count = productRepository.updateOutOfStock(true, product.getProductId(), CommonUtils.GetCurrentTimeStamp());
		} else if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_AVAILABLE)) {
			assert product != null;
			count = productRepository.updateOutOfStock(false, product.getProductId(),
					CommonUtils.GetCurrentTimeStamp());
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (count == 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("ProductServiceImpl updateStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response adminUpdateStatus(ProductUpdateRequest productReq) throws Exception {
		logger.info("ProductServiceImpl adminUpdateStatus----starts----"+productReq);
		if (StringUtils.isEmpty(productReq.getId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(productReq.getStatus())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STATUS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Product product = productRepository.findByProductId(productReq.getId());
		if (product == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_ACTIVE)) {
			assert product != null;
			product.setStatus(true);
			product.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			product.setInactivateReason(productReq.getActivateReason());
			product.setInactiveBy(Constant.ADMIN);
			productRepository.save(product);
			sendProductactivateMail(product);
			saveActiveProductLog(product, Constant.PRODUCT_ACTIVE);
		} else if (productReq.getStatus().equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
			assert product != null;
			product.setStatus(false);
			product.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
			product.setInactivateReason(productReq.getInactivateReason());
			product.setInactiveBy(Constant.ADMIN);
			productRepository.save(product);
			sendProductInactivateMail(product);
			saveActiveProductLog(product, Constant.PRODUCT_INACTIVE);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("ProductServiceImpl adminUpdateStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.STATUS_UPDATED, "", 200, Constant.RESPONSE_SUCCESS);
	}

	public void saveActiveProductLog(Product product, String flag) throws Exception {
		logger.info("ProductServiceImpl saveActiveProductLog----starts----"+product,flag);
		if (!flag.equals(Constant.PRODUCT_ACTIVE)) {
			ActiveProductLog activeProductLog = activeProductLogRepository
					.findByProductProductIdAndToDate(product.getProductId(), null);
			if (activeProductLog != null) {
				activeProductLog.setToDate(CommonUtils.GetCurrentTimeStampFormat());
				activeProductLogRepository.save(activeProductLog);
			}
		} else {
			ActiveProductLog activeProductLog = activeProductLogRepository
					.findByProductProductIdAndToDate(product.getProductId(), null);
			if (activeProductLog == null) {
				activeProductLog = new ActiveProductLog();
				activeProductLog.setFromDate(CommonUtils.GetCurrentTimeStampFormat());
				activeProductLog.setProduct(product);
				activeProductLog.setStatus(true);
				activeProductLogRepository.save(activeProductLog);
			}
		}
		logger.info("ProductServiceImpl saveActiveProductLog----ends----");
	}

	@Override
	public Response getAllByVendorId(Integer vendorId) throws Exception {
		logger.info("ProductServiceImpl getAllByVendorId----starts----"+vendorId);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor != null && CommonUtils.integersCompare(existingVendor.getVendorId(), vendorId) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(vendorId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<Product> list = new ArrayList<>();
		Iterable<Product> productList = productRepository.findByVendorVendorId(vendorId);
		productList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("ProductServiceImpl getAllByVendorId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.VENDOR_PRODUCT_FETCHED, list, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Product updateProductCode(Integer vendorId, Integer categoryId, Integer subCategoryId, Product product)
			throws Exception {
		logger.info("ProductServiceImpl updateProductCode----starts----"+vendorId,categoryId,subCategoryId,product);
		Optional<Vendor> vendor = vendorRepository.findById(vendorId);
		Category category = categoryRepository.findByCategoryId(categoryId);
		SubCategory subCategory = subCategoryRepository.findBySubCategoryId(subCategoryId);

		if (category != null && subCategory != null && vendor.isPresent()) {
			String productCode = CommonUtils.generateProductCode(vendor.get().getName(), category.getCategoryName(),
					subCategory.getSubCategoryName(), product.getProductId());

			product.setProductCode(productCode);
			productRepository.save(product);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		logger.info("ProductServiceImpl updateProductCode----starts----");
		return product;
	}

	@Override
	public Response getAllByCategoryId(Integer categoryId) throws Exception {
		logger.info("ProductServiceImpl getAllByCategoryId----starts----"+categoryId);
		if (StringUtils.isEmpty(categoryId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CATEGORY_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<Product> list = new ArrayList<>();
		Iterable<Product> productList = productRepository.findByCategoryCategoryId(categoryId);
		productList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CATEGORY_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("ProductServiceImpl updateProductCode----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response getAllBySubCategoryId(Integer subCategoryId) throws Exception {
		logger.info("ProductServiceImpl getAllBySubCategoryId----starts----"+subCategoryId);
		if (StringUtils.isEmpty(subCategoryId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SUB_CATEGORY_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		List<Product> list = new ArrayList<>();
		Iterable<Product> productList = productRepository.findBySubCategorySubCategoryId(subCategoryId);
		productList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SUB_CATEGORY_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("ProductServiceImpl getAllBySubCategoryId----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);
	}

	@SuppressWarnings("unused")
	public Response searchByProduct(String productName, Integer vendorId, Integer categoryId, Integer subCategoryId,
			Integer limit, Integer offset) throws Exception {
		logger.info("ProductServiceImpl searchByProduct----starts----"+productName,vendorId,categoryId,subCategoryId,limit,offset);
		User accessUser = userService.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor != null && CommonUtils.integersCompare(existingVendor.getVendorId(), vendorId) != 0) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(productName) && StringUtils.isEmpty(categoryId) && StringUtils.isEmpty(subCategoryId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SEARCH_CREDENTIALS_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(vendorId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Page<Product> productList = null;
		List<Product> productLists = null;
		if (!StringUtils.isEmpty(limit) && !StringUtils.isEmpty(offset)) {

			PageRequest.of(offset, limit);
//			 productList = productRepository.searchByProduct(productName,
//			 categoryId,subCategoryId,vendorId, pageable);
			if (null == productList || productList.isEmpty()) {// TODO This needs to be looked as it is always true.
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			logger.info("ProductServiceImpl searchByProduct----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, productList, 200, Constant.RESPONSE_SUCCESS);
		} else {
			// productLists = productRepository.searchByProduct(productName,
			// categoryId,subCategoryId,vendorId);
			if (null == productLists || productLists.isEmpty()) { // TODO This needs to be looked as it is always true.
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			logger.info("ProductServiceImpl searchByProduct----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, productLists, 200, Constant.RESPONSE_SUCCESS);

		}

	}

	@Override
	public Response getAllProduct() throws Exception {
		logger.info("ProductServiceImpl getAllProduct----starts----");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		System.out.println("vendorId:" + vendor.getVendorId());

		List<Product> list = new ArrayList<>();
		Iterable<Product> productList = productRepository.findByVendorVendorId(vendor.getVendorId());
		productList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("ProductServiceImpl getAllProduct----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);

	}
	
	@Override
	public Response getProductByStatus(String status, String searchString, Pagination pagination) throws Exception {
		logger.info("ProductServiceImpl getProductByStatus----starts----"+status,searchString,pagination);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		int offset = 0;
		int limit = Constant.DEFAULT_PAGINATION_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}
		if (vendor != null) {
			Pageable paging = PageRequest.of(offset, limit);

			List<Product> list = new ArrayList<>();
			Iterable<Product> productList = null;
			if (searchString != null) {
				if (status.equalsIgnoreCase(Constant.PRODUCT_ACTIVE)) {
					productList = productRepository.searchByProductActive(vendor.getVendorId(), true,
							searchString.toLowerCase(), offset, limit,Constant.PRODUCT_APPROVAL_STATUS_APPROVED);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_PENDING)) {
					productList = productRepository.searchByProductActive(vendor.getVendorId(), true,
							searchString.toLowerCase(), offset, limit,Constant.PRODUCT_APPROVAL_STATUS_PENDING);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
					productList = productRepository.searchByProductInActive(vendor.getVendorId(), false,
							searchString.toLowerCase(), offset, limit);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_OUT_OF_STOCK)) {
					productList = productRepository.searchByProductActiveAndIsOutOfStock(vendor.getVendorId(), true,
							searchString.toLowerCase(), offset, limit, true);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_APPROVAL_STATUS_REJECTED)) {
					productList = productRepository.searchByProductActive(vendor.getVendorId(), true,
							searchString.toLowerCase(), offset, limit,Constant.PRODUCT_APPROVAL_STATUS_REJECTED);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			} else {
				if (status.equalsIgnoreCase(Constant.PRODUCT_ACTIVE)) {
					productList = productRepository
							.findByVendorVendorIdAndApprovalStatusAndStatusOrderByCreatedAtDesc(vendor.getVendorId(),Constant.PRODUCT_APPROVAL_STATUS_APPROVED, true, paging);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_PENDING)) {
					productList = productRepository
							.findByVendorVendorIdAndApprovalStatusAndStatusOrderByCreatedAtDesc(vendor.getVendorId(),Constant.PRODUCT_APPROVAL_STATUS_PENDING, true, paging);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
					productList = productRepository
							.findByVendorVendorIdAndStatusOrderByCreatedAtDesc(vendor.getVendorId(), false, paging);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_OUT_OF_STOCK)) {
					productList = productRepository.findByVendorVendorIdAndStatusAndIsOutOfStockOrderByCreatedAtDesc(
							vendor.getVendorId(), true, true, paging);
				} else if (status.equalsIgnoreCase(Constant.PRODUCT_APPROVAL_STATUS_REJECTED)) {
					productList = productRepository.findByVendorVendorIdAndApprovalStatusAndStatusOrderByCreatedAtDesc(
							vendor.getVendorId(),Constant.PRODUCT_APPROVAL_STATUS_REJECTED, true, paging);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}
			for (Product product : productList) {
				List<ProductImage> productImageList = productImageRepository
						.findByProductProductIdAndIsActive(product.getProductId(), true);
				product.setProductImage(productImageList);
				List<DeliveryTypeDAO> deliveryTypeList = deliveryTypeRepository.findByPid(product.getProductId());

				for (DeliveryTypeDAO d : deliveryTypeList) {
					if (d.getType().equalsIgnoreCase("S") && d.getIsselected() == 1) {
						List<ShipmentProgressDtlDAO> shipmentProgressDtlList = new ArrayList<>();
						shipmentProgressDtlList = shipmentProgressDtlRepository.findAll(d.getDeliveryTypeid());
						d.setInShipment(shipmentProgressDtlList);
					}
				}

				product.setDeliveryTypeList(deliveryTypeList);
				list.add(product);
			}
			// productList.iterator().forEachRemaining(list::add);
			List<ProductResponse> convetedProduct = ProductConverterHelper.getResponseListFromEntity(list);
			VendorProductResponse vendorProductResponse = new VendorProductResponse();
			// vendorProductResponse.setStripePaymentMethodId(vendor.getStripePaymentMethodId());
			// vendorProductResponse.setStripeAccountId(vendor.getStripeAccountId());
			vendorProductResponse.setCardNumber(vendor.getCardNumber());
			vendorProductResponse.setProduct(convetedProduct);
			// vendorProductResponse.setProductList(list);
			vendorProductResponse.setActiveCount(productRepository
					.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(),Constant.PRODUCT_APPROVAL_STATUS_APPROVED, true));
			vendorProductResponse.setPendingCount(productRepository
					.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(), Constant.PRODUCT_APPROVAL_STATUS_PENDING, true));
			vendorProductResponse.setInActiveCount(productRepository
					.countByVendorVendorIdAndStatus(vendor.getVendorId(), false));
			vendorProductResponse.setOutOfStockCount(productRepository
					.countByVendorVendorIdAndStatusAndIsOutOfStock(vendor.getVendorId(), true, true));
			vendorProductResponse.setRejectedCount(productRepository
					.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(),Constant.PRODUCT_APPROVAL_STATUS_REJECTED, true));
			if (CommonUtils.IsNullOrEmpty(list)) {
				logger.info("ProductServiceImpl getProductByStatus----ends----");
				return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
						Constant.RESPONSE_SUCCESS);
			}
			logger.info("ProductServiceImpl getProductByStatus----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

	}

	@Override
	public Response getCountByStatus(String status) throws Exception {
		logger.info("ProductServiceImpl getCountByStatus----starts----"+status);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentUserName = authentication.getName();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		Map<String, Integer> map = new HashMap<>();
		int count = 0;
		if (status.equalsIgnoreCase(Constant.PRODUCT_ACTIVE) || status.equalsIgnoreCase(Constant.PRODUCT_INACTIVE)
				|| status.equalsIgnoreCase(Constant.PRODUCT_OUT_OF_STOCK)) {
			if (status.equalsIgnoreCase(Constant.PRODUCT_ACTIVE)) {
				count = productRepository.countByVendorVendorIdAndStatus(vendor.getVendorId(), true);

			} else if (status.equalsIgnoreCase(Constant.PRODUCT_INACTIVE)) {
				count = productRepository.countByVendorVendorIdAndStatus(vendor.getVendorId(), false);

			} else {
				count = productRepository.countByVendorVendorIdAndIsOutOfStock(vendor.getVendorId(), true);

			}
			map.put("count", count);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		logger.info("ProductServiceImpl getCountByStatus----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, map, 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response gethippingConfigDtl() throws Exception {
		// TODO Auto-generated method
		logger.info("ProductServiceImpl gethippingConfigDtl----starts----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, shippingConfigDtlRepository.findAll(), 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getVendorDtl(Integer vendorId) throws Exception {
		logger.info("ProductServiceImpl getVendorDtl----starts----"+vendorId);
//		if (StringUtils.isEmpty(vendorId)) {
//			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_ID_IS_REQUIRED,
//					Constant.RESPONSE_EMPTY_DATA, 1001);
//		}
		List<Product> list = new ArrayList<>();
		Map<String,Object> vendordtl = new LinkedHashMap<String,Object>();
		Iterable<Product> productList = productRepository.findByVendorVendorIdAndApprovalStatusAndStatus(vendorId,Constant.PRODUCT_APPROVAL_STATUS_APPROVED, true);
		productList.iterator().forEachRemaining(list::add);
		Vendor vendor= vendorRepository.findByVendorId(vendorId);
		setVendorLogo(vendor);
		setUserImage(vendor.getUser());
		if (vendor.getUser() != null && vendor.getUser().getUserImage() != null
				&& vendor.getUser().getUserImage().getImage() != null) {
			vendor.setLogo(vendor.getUser().getUserImage().getImage().getUrl() != null
					? vendor.getUser().getUserImage().getImage().getUrl()
					: "");
		} else {
			vendor.setLogo("");
		}
		
		for (Product product : list) {
			if (product != null) {
				product.setVendorId(product.getVendor().getVendorId());
				setProductImageUrl(product);

				List<DeliveryTypeDAO> deliveryTypeList = deliveryTypeRepository.findByPid(product.getProductId());
				for (DeliveryTypeDAO d : deliveryTypeList) {
					if (d.getType().equalsIgnoreCase("S") && d.getIsselected() == 1) {
						List<ShipmentProgressDtlDAO> shipmentProgressDtlList = shipmentProgressDtlRepository.findAll(d.getDeliveryTypeid());
						d.setInShipment(shipmentProgressDtlList);
					}
				}

				product.setDeliveryTypeList(deliveryTypeList);
			}
		}
		vendordtl.put("vendor", vendor);
		vendordtl.put("product", list);
		logger.info("ProductServiceImpl getVendorDtl----ends----");
		return ResponseHelper.getSuccessResponse(Constant.VENDOR_PRODUCT_FETCHED, vendordtl, 200, Constant.RESPONSE_SUCCESS);
	}

	private void setUserImage(User user) {
		logger.info("ProductServiceImpl setUserImage----starts----" + user);
		UserImage userImages = userImageRepository.findByUserUserIdAndStatus(user.getUserId(), true);		
		if (userImages != null) {
			user.setUserImage(userImages);
		}
		logger.info("ProductServiceImpl setUserImage----ends----");
	}
	
		private void setProductImageUrl(Product product) {
			logger.info("ProductServiceImpl setProductImageUrl----starts----"+product);
			List<ProductImage> images = productImageRepository.findByProductProductIdAndIsActive(product.getProductId(),
					true);
			Assert.notNull(images, "Could not find images for".concat(product.getProductName()));
			if (images.size() > 0) {
				product.setImageURL(images.get(0).getImage().getUrl());
			}
			logger.info("ProductServiceImpl setProductImageUrl----ends----");
		}	
		
		private void setVendorLogo(Vendor vendor) {
			logger.info("ProductServiceImpl setVendorLogo----starts----"+vendor);
			List<VendorImage> vendorImages = vendorImageRepository.findByVendorVendorIdAndIsActive(vendor.getVendorId(),
					true);
			Assert.notNull(vendorImages, "Could not find the images for".concat(vendor.getName()));
			if (vendorImages.size() > 0) {
				VendorImage image = vendorImages.get(0);
				if (image != null && image.getImage() != null) {
					//vendor.setLogo(image.getImage().getUrl());
				}
			}
			vendor.setVendorImage(vendorImages);
			logger.info("ProductServiceImpl setVendorLogo----ends----");
		}
		
		@Async("specificTaskExecutor")
		public void sendProductPendingMail(Product product) {
			logger.info("OrderServiceImpl sendOrderShipmentMail----starts----");
			try {
				
				Map<String, Object> mailMap = new HashMap<>();
				Map<String, Object> notificationMap = new HashMap<>();
				mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
				// mailMap.put("name", user.getFirstName()+" "+user.getLastName());
				Template mailTemplate = config.getTemplate(productPendingTemplate);
				String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
				// Call Mail Service
				notificationMap.put("userMail",adminUser);//adminUser
				notificationMap.put("cc",eatzosSupport);
				// notificationMap.put("userMail", user.getEmail());
				notificationMap.put("subject", product.getProductName()+" "+productPendingSubject);
				notificationMap.put("html", html);
				boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
				if (!isMailSent) {
//				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SERVER_ERROR, Constant.RESPONSE_EMPTY_DATA,
//						500);
					System.out.println("Mail Sending Failed");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
				logger.info(CommonUtils.getStracktraceTostring(e));
			}
			logger.info("OrderServiceImpl sendOrderShipmentMail----ends----");
		}

	@Override
	public Response getProductInventory(ProductInventoryRequest productInventoryRequest, Pagination pagination) {
		logger.info("ProductServiceImpl getProductInventory----starts----");
		
		String currentUserName = authenticationConfig.getLoginUserMail();
		User user = userRepository.findByEmail(currentUserName);
		Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
		int offset = 0;
		int limit = Constant.DEFAULT_LIMIT;
		if (pagination != null) {
			offset = pagination.getOffset();
			limit = pagination.getLimit();
		}

		if (vendor != null) {
			Pageable paging = PageRequest.of(offset, limit);
			List<Product> list = new ArrayList<>();
			Iterable<Product> productList;

			String searchString = productInventoryRequest.getSearchString();
			Boolean status = productInventoryRequest.getStatus();
			String approvalStatus = productInventoryRequest.getApprovalStatus();
			Boolean outOfStock = productInventoryRequest.getOutOfStock();

			boolean isApprovalStatusPresent = Constant.PRODUCT_APPROVAL_STATUS_APPROVED.equalsIgnoreCase(approvalStatus)
					|| Constant.PRODUCT_APPROVAL_STATUS_PENDING.equalsIgnoreCase(approvalStatus)
					|| Constant.PRODUCT_APPROVAL_STATUS_REJECTED.equalsIgnoreCase(approvalStatus);
			if (searchString != null) {
				if (isApprovalStatusPresent) {
					productList = productRepository.searchByProductActive(vendor.getVendorId(), status,
							searchString.toLowerCase(), offset, limit, approvalStatus);
				} else if (status.equals(false)) {
					productList = productRepository.searchByProductInActive(vendor.getVendorId(), false,
							searchString.toLowerCase(), offset, limit);
				} else if (outOfStock.equals(true)) {
					productList = productRepository.searchByProductActiveAndIsOutOfStock(vendor.getVendorId(), status,
							searchString.toLowerCase(), offset, limit, true);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			} else {
				if (isApprovalStatusPresent) {
					productList = productRepository
							.findByVendorVendorIdAndApprovalStatusAndStatusOrderByCreatedAtDesc(vendor.getVendorId(), approvalStatus, status, paging);
				} else if (status != null && status.equals(false)) {
					productList = productRepository
							.findByVendorVendorIdAndStatusOrderByCreatedAtDesc(vendor.getVendorId(), false, paging);
				} else if (outOfStock != null && outOfStock.equals(true) && status != null) {
					productList = productRepository.findByVendorVendorIdAndStatusAndIsOutOfStockOrderByCreatedAtDesc(
							vendor.getVendorId(), status, true, paging);
				} else {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PRODUCT_INVALID_STATUS,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
			}

			for (Product product : productList) {
				List<ProductImage> productImageList = productImageRepository.findByProductProductIdAndIsActive(product.getProductId(), true);
				product.setProductImage(productImageList);
				List<DeliveryTypeDAO> deliveryTypeList = deliveryTypeRepository.findByPid(product.getProductId());

				for (DeliveryTypeDAO d : deliveryTypeList) {
					if (d.getType().equalsIgnoreCase("S") && d.getIsselected() == 1) {
						List<ShipmentProgressDtlDAO> shipmentProgressDtlList = shipmentProgressDtlRepository.findAll(d.getDeliveryTypeid());
						d.setInShipment(shipmentProgressDtlList);
					}
				}

				product.setDeliveryTypeList(deliveryTypeList);
				list.add(product);
			}

			List<ProductResponse> convertedProduct = ProductConverterHelper.getResponseListFromEntity(list);
			VendorProductResponse vendorProductResponse = new VendorProductResponse();
			vendorProductResponse.setCardNumber(vendor.getCardNumber());
			vendorProductResponse.setProduct(convertedProduct);
			int activeCount = productRepository.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(), Constant.PRODUCT_APPROVAL_STATUS_APPROVED, true);
			vendorProductResponse.setActiveCount(activeCount);
			int pendingCount = productRepository.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(), Constant.PRODUCT_APPROVAL_STATUS_PENDING, true);
			vendorProductResponse.setPendingCount(pendingCount);
			int inActiveCount = productRepository.countByVendorVendorIdAndStatus(vendor.getVendorId(), false);
			vendorProductResponse.setInActiveCount(inActiveCount);
			int outOfStockCount = productRepository.countByVendorVendorIdAndStatusAndIsOutOfStock(vendor.getVendorId(), true, true);
			vendorProductResponse.setOutOfStockCount(outOfStockCount);
			int rejectedCount = productRepository.countByVendorVendorIdAndApprovalStatusAndStatus(vendor.getVendorId(), Constant.PRODUCT_APPROVAL_STATUS_REJECTED, true);
			vendorProductResponse.setRejectedCount(rejectedCount);
			if (CommonUtils.IsNullOrEmpty(list)) {
				logger.info("ProductServiceImpl getProductByStatus----ends----");
				return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
						Constant.RESPONSE_SUCCESS);
			}
			logger.info("ProductServiceImpl getProductByStatus----ends----");
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, vendorProductResponse, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
	}
	
	@Async("specificTaskExecutor")
	public void sendProductInactivateMail(Product product) {
		logger.info("AdminServiceImpl sendProductInactivateMail----starts----");
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("sellerName", product.getVendor().getName());
			mailMap.put("productName", product.getProductName());
			mailMap.put("inActiveReason", product.getInactivateReason());
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			Template mailTemplate = config.getTemplate(productInactivateTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", product.getVendor().getUser().getEmail());
			notificationMap.put("subject", "Attention - " + product.getProductName() + " has been inactivated for "
					+ product.getVendor().getName());
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			logger.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("AdminServiceImpl sendProductInactivateMail----ends----");
	}
	
	@Async("specificTaskExecutor")
	public void sendProductactivateMail(Product product) {
		logger.info("AdminServiceImpl sendProductactivateMail----starts----");
		try {
			Map<String, Object> mailMap = new HashMap<>();
			Map<String, Object> notificationMap = new HashMap<>();
			mailMap.put("sellerName", product.getVendor().getName());
			mailMap.put("productName", product.getProductName());			
			mailMap.put("eatzosInfo", Constant.EATZOS_INFO);
			Template mailTemplate = config.getTemplate(productActivateTemplate);
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(mailTemplate, mailMap);
			notificationMap.put("userMail", product.getVendor().getUser().getEmail());
			notificationMap.put("subject", "Attention - " + product.getProductName() + " has been activated for "
					+ product.getVendor().getName());
			notificationMap.put("html", html);
			boolean isMailSent = notificationHelper.sendNotification(Constant.NOTIFICATION_MAIL_TYPE, notificationMap);
			if (!isMailSent) {
				System.out.println("Mail Sending Failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			logger.info(CommonUtils.getStracktraceTostring(e));
		}
		logger.info("AdminServiceImpl sendProductactivateMail----ends----");
	}
}
