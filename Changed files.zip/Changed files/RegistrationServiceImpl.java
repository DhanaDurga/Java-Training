package com.eatzos.service.impl;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eatzos.request.RegistrationSignupRequest;
import com.eatzos.service.VendorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.util.StringUtils;

import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.NotificationHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.model.Config;
import com.eatzos.model.Images;
import com.eatzos.model.Registration;
import com.eatzos.model.Role;
import com.eatzos.model.User;
import com.eatzos.model.UserImage;
import com.eatzos.model.UserRole;
import com.eatzos.repository.ImageRepository;
import com.eatzos.repository.RegistrationRepository;
import com.eatzos.repository.RoleRepository;
import com.eatzos.repository.UserImageRepository;
import com.eatzos.repository.UserRepository;
import com.eatzos.repository.UserRoleRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.service.CacheService;
import com.eatzos.service.ImageService;
import com.eatzos.service.RegistrationService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;

import freemarker.template.Configuration;
import freemarker.template.Template;

@Service(value = "registrationService")
public class RegistrationServiceImpl implements RegistrationService {
	
	private static final Logger logger = LoggerFactory.getLogger(RegistrationServiceImpl.class);

	@Autowired
	private RegistrationRepository registrationRepository;
	
	@Autowired
	private Configuration config;
	
	@Autowired
	NotificationHelper notificationHelper;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private RoleRepository rolesRepository;

	@Autowired
	private UserRoleRepository userRolesRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private CacheService cacheService;
	
	@Autowired
	private TokenStore tokenStore;
	
	@Value("${mail.newUer.subject}")
	private String newUerSubject;

	@Value("${mail.newUer.template}")
	private String newUerTemplate;

	@Value("${mail.newUer.link}")
	private String newUerPwdLink;
	
	@Value("${mail.header.image}")
	private String mailHeaderImage;
	
	@Value("${buyer.domain.reset.password.url}")
	private String buyerDomainResetPasswordUrl;

	@Autowired
	private VendorService vendorService;
	
	@Autowired
	private UserImageRepository userImageRepository;
	
	@Autowired
	private ImageRepository imageRepository;
	
	@Autowired
	private ImageService imageService;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;
	
	@Override
	public Response saveRegistration(Registration registration) throws Exception {
		logger.info("RegistrationServiceImpl saveRegistration----starts----"+registration);
		
		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

		if (StringUtils.isEmpty(registration.getEmail())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registrationList = registrationRepository.findByEmail(registration.getEmail());
		User userList = userRepository.findByEmail(registration.getEmail());
		if (registrationList != null || userList != null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_ID_ALREADY_EXISTS,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if(registration.getMobile().length()==0) {
			registration.setMobile(null);
		}
		// registration.setPassword(bcryptEncoder.encode(registration.getPassword()));
		Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
		registration.setMobileOTP(CommonUtils.getRandomNumber());
		registration.setOtpCreatedAt(currentTime);
		
		registration.setEmailFailureAttempt(0);
		registration.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
		registration.setVerificationCodeCreatedAt(currentTime);
		registration.setCreatedAt(currentTime);
		registration.setUpdatedAt(currentTime);

		registration = registrationRepository.save(registration);

		// Send registration email code
		userService.sendVerificationCode(registration.getEmail(), registration.getEmailVerificationCode(),
				registration.getFirstName());
		if (!Strings.isNullOrEmpty(registration.getFrom()) && registration.getFrom().equalsIgnoreCase(Constant.SELLER)) {
		userService.sendUserRegisterMailToEatzosAdmin(registration.getEmail(), registration.getMobile(),registration.getFirstName());
		}
		
		if (registration.getMobile() != null && registration.getMobile().length()>0) {
			// Send registration mobile OTP
			userService.sendVerificationOTP(registration.getMobile(), registration.getMobileOTP());
		}
		logger.info("RegistrationServiceImpl saveRegistration----ends----");
		return ResponseHelper.getSuccessResponse("", registration, 200, Constant.RESPONSE_SUCCESS);
	}

	public boolean saveUser(Registration registration, String password) throws Exception {
		logger.info("RegistrationServiceImpl saveUser----starts----"+registration,password);
		User user = new User();
		Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
		user.setFirstName(registration.getFirstName());
		user.setLastName(registration.getLastName());
		user.setEmail(registration.getEmail());
		user.setMobileNumber(registration.getMobile());
		user.setPassword(bcryptEncoder.encode(password));
		user.setStatus(Constant.STATUS_ACTIVE);
		// user.setMobileOTP(CommonUtils.getRandomNumber());
		user.setMobileOTP(registration.getMobileOTP());
		user.setVerificationCodeCreatedAt(currentTime);
		user.setCreatedAt(currentTime);
		user.setUpdatedAt(currentTime);

		user = userRepository.save(user);
		if (user.getUserId() != null) {
			UserRole userRole = new UserRole();
			userRole.setUser(user);
			Role role = rolesRepository.findByRoleId(2);
			if (role != null) {
				userRole.setRoles(role);
			}
			userRolesRepository.save(userRole);
			logger.info("RegistrationServiceImpl saveUser----ends----");
			return true;
		}
		logger.info("RegistrationServiceImpl saveUser----ends----");
		return false;

	}

	@Override
	public Response updatePassword(String email, String password) throws Exception {
		logger.info("RegistrationServiceImpl updatePassword----starts----"+email,password);
		if (StringUtils.isEmpty(password)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.PASSWORD_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(email)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Registration registration = registrationRepository.findByEmail(email);

		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.EMAIL_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (registration.getIsEmailVerified()) {

			boolean isUserSaved = saveUser(registration, password);
			if (isUserSaved) {
				registrationRepository.delete(registration);
				logger.info("RegistrationServiceImpl updatePassword----ends----");
				return ResponseHelper.getSuccessResponse(Constant.PASSWORD_CHANGED, Constant.RESPONSE_EMPTY_DATA, 200,
						Constant.RESPONSE_SUCCESS);
			} else {
				logger.info("RegistrationServiceImpl updatePassword----ends----");
				throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.EMAIL_NOT_VERIFIED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
		} else {
			logger.info("RegistrationServiceImpl updatePassword----ends----");
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_NOT_VERIFIED, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_SUCCESS);

		}

	}

	@Override
	public Response checkEmailAvailability(String email) throws Exception {
		logger.info("RegistrationServiceImpl checkEmailAvailability----starts----"+email);
		if (StringUtils.isEmpty(email)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByEmail(email);
		User user = userRepository.findByEmail(email);

		if (registration == null && user == null) {
			logger.info("RegistrationServiceImpl checkEmailAvailability----ends----");
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_AVAILABLE, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_SUCCESS);

		} else {
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_ID_ALREADY_EXISTS, Constant.RESPONSE_EMPTY_DATA,
					200, Constant.RESPONSE_SUCCESS);
		}
	}

	@Override
	public Response resendCode(String email) throws Exception {
		logger.info("RegistrationServiceImpl resendCode----starts----"+email);
		if (StringUtils.isEmpty(email)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByEmail(email);
		if (registration == null) {
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_SUCCESS);
		}

		Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
		Integer configValue = Integer.valueOf(config.getValue());
		boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getVerificationCodeCreatedAt(),
				configValue);
		if (!isCodeExpired) {

			userService.sendVerificationCode(registration.getEmail(), registration.getEmailVerificationCode(),
					registration.getEmail());

		} else {
			registration.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
			Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
			registration.setVerificationCodeCreatedAt(currentTime);
			registration.setUpdatedAt(currentTime);

			registration = registrationRepository.save(registration);

			// Send registration email code
			userService.sendVerificationCode(registration.getEmail(), registration.getEmailVerificationCode(),
					registration.getEmail());
		}
		logger.info("RegistrationServiceImpl resendCode----ends----");
		return ResponseHelper.getSuccessResponse(Constant.EMAIL_RESEND, Constant.RESPONSE_EMPTY_DATA, 200,
				Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response resendOTP(String mobile) throws Exception {
		logger.info("RegistrationServiceImpl resendOTP----starts----"+mobile);
		if (StringUtils.isEmpty(mobile)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MOBILE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByMobile(mobile);
		if (registration == null) {
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_SUCCESS);
		}
		
		Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
		Integer configValue = Integer.valueOf(config.getValue());
		boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getOtpCreatedAt(),
				configValue);
		
		if (!isCodeExpired) {
			userService.sendVerificationOTP(registration.getMobile(), registration.getMobileOTP());
		} else {
			registration.setMobileOTP(CommonUtils.getRandomNumber());
			Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
			registration.setOtpCreatedAt(currentTime);
			registration.setUpdatedAt(currentTime);
			registration = registrationRepository.save(registration);
			// Send registration email code
			userService.sendVerificationOTP(registration.getMobile(), registration.getMobileOTP());
		}
		logger.info("RegistrationServiceImpl resendOTP----ends----");
		return ResponseHelper.getSuccessResponse(Constant.MOBILE_OTP_RESEND, Constant.RESPONSE_EMPTY_DATA, 200,
				Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response updateUserDetails(Registration registration, String status,HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("RegistrationServiceImpl updateUserDetails----starts----"+registration,status,request,response);
		// TODO Auto-generated method stub
		User user = new User();
		user = userRepository.findById(registration.getId()).orElse(user);
		switch (status) {
		case "user":
			user.setFirstName(registration.getFirstName());
			user.setLastName(registration.getLastName());
			user = userRepository.save(user);
			UserImage userImages = userImageRepository.findByUserUserIdAndStatus(user.getUserId(), true);
			if (userImages != null) {
				user.setUserImage(userImages);
			}

			String authHeader = request.getHeader("Authorization");
			if (authHeader != null) {
//				Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//				org.springframework.security.core.userdetails.User userDetails = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
				String tokenValue = authHeader.replace("Bearer", "").trim();
				OAuth2AccessToken accessToken = tokenStore.readAccessToken(tokenValue);
				final Map<String, Object> additionalInfo = new HashMap<String, Object>();
				
				additionalInfo.put("role", authenticationConfig.getAuthorities());
		        com.eatzos.model.Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
						        
		        additionalInfo.put("userId", user.getUserId().toString());
		        additionalInfo.put("firstName", user.getFirstName());
		        additionalInfo.put("lastName", user.getLastName());
		    	additionalInfo.put("email", user.getEmail());
		    	additionalInfo.put("mobile", user.getMobile());
		    	additionalInfo.put("userImage",user.getUserImage());
		    	if(vendor!=null) {
		        	additionalInfo.put("vendorId", vendor.getVendorId().toString());
		        }else {
		        	additionalInfo.put("vendorId", "");
		        }
		    	additionalInfo.put("status",Constant.RESPONSE_SUCCESS);
		        additionalInfo.put("code", 200);
		        additionalInfo.put("data", Constant.RESPONSE_EMPTY_DATA);
		    	additionalInfo.put("message", "");
		        
		        ((DefaultOAuth2AccessToken) accessToken)
		                .setAdditionalInformation(additionalInfo);
			}
			break;

		case "email":
			Registration registrationList = registrationRepository.findByEmail(registration.getEmail());
			User userList = userRepository.findByEmail(registration.getEmail());
			if (userList != null) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_ID_ALREADY_EXISTS,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}
			
			if (registrationList != null && registrationList.getUpdateFlag()) {
				registrationList.setMobileOTP(CommonUtils.getRandomNumber());
				registrationList.setMobile(CommonUtils.getRandomNumberString());
				registrationList.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
				registrationList.setEmailFailureAttempt(0);
				registrationList.setIsEmailVerified(true);
				registrationList.setUpdateFlag(true);
				Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
				registrationList.setOtpCreatedAt(currentTime);
				registrationList.setVerificationCodeCreatedAt(currentTime);
				registrationList.setCreatedAt(currentTime);
				registrationList.setUpdatedAt(currentTime);
				registrationList = registrationRepository.save(registrationList);
				userService.sendVerificationCode(registrationList.getEmail(), registrationList.getEmailVerificationCode(),registrationList.getFirstName()+" "+registrationList.getLastName());
				break;
			}
			registration.setMobileOTP(CommonUtils.getRandomNumber());
			registration.setMobile(CommonUtils.getRandomNumberString());
			registration.setEmail(registration.getEmail());
			registration.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
			registration.setEmailFailureAttempt(0);
			registration.setIsEmailVerified(true);
			registration.setUpdateFlag(true);
			Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
			registration.setOtpCreatedAt(currentTime);
			registration.setVerificationCodeCreatedAt(currentTime);
			registration.setCreatedAt(currentTime);
			registration.setUpdatedAt(currentTime);
			registration = registrationRepository.save(registration);
			// Send registration email code
			userService.sendVerificationCode(registration.getEmail(), registration.getEmailVerificationCode(),registration.getFirstName()+" "+registration.getLastName());
			break;

		case "mobile":
			Registration regNumberList = registrationRepository.findByMobile(registration.getMobile());
			User userDetails = userRepository.findByUserIdAndMobile(registration.getId(),registration.getMobile());
			if(userDetails != null && userDetails.getStatus().equals(1)) {
				throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MOBILE_ALREADY_VERIFIED,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			}			
			if (regNumberList != null && regNumberList.getUpdateFlag()) {				
				regNumberList.setMobileOTP(CommonUtils.getRandomNumber());
				regNumberList.setMobile(registration.getMobile());
				regNumberList.setIsMobileVerified(true);
				regNumberList.setUpdateFlag(true);
				regNumberList.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
				regNumberList.setEmail("" + CommonUtils.getRandomNumber());
				regNumberList.setEmailFailureAttempt(0);
				Timestamp currentTimeStamp = CommonUtils.GetCurrentTimeStamp();
				regNumberList.setOtpCreatedAt(currentTimeStamp);
				regNumberList.setVerificationCodeCreatedAt(currentTimeStamp);
				regNumberList.setCreatedAt(currentTimeStamp);
				regNumberList.setUpdatedAt(currentTimeStamp);
				regNumberList = registrationRepository.save(regNumberList);
				userService.sendVerificationOTP(regNumberList.getMobile(), regNumberList.getMobileOTP());
				break;
			}
			registration.setMobileOTP(CommonUtils.getRandomNumber());
			registration.setMobile(registration.getMobile());
			registration.setIsMobileVerified(true);
			registration.setUpdateFlag(true);
			registration.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
			registration.setEmail("" + CommonUtils.getRandomNumber());
			registration.setEmailFailureAttempt(0);
			Timestamp currentTimeStamp = CommonUtils.GetCurrentTimeStamp();
			registration.setOtpCreatedAt(currentTimeStamp);
			registration.setVerificationCodeCreatedAt(currentTimeStamp);
			registration.setCreatedAt(currentTimeStamp);
			registration.setUpdatedAt(currentTimeStamp);
			registration = registrationRepository.save(registration);
			// Send registration mobile OTP
			userService.sendVerificationOTP(registration.getMobile(), registration.getMobileOTP());
			break;
		case "userImage":			
			if (registration.getImages() != null) {
				Images images = registration.getImages();
				if (images != null) {
					boolean isMoved = imageService.moveFilesFromS3(images.getImageId(), registration.getId(),
							Constant.IMAGE_USER_PHOTO_TYPE, Constant.IMAGE_USER_PHOTO_TYPE);
					if (isMoved) {
						UserImage userImage;
						List<UserImage> userImageList = userImageRepository
								.findByImageImageIdAndStatus(images.getImageId(), true);
						if (userImageList != null && userImageList.size() > 0) {
							userImageList.sort((o1, o2) -> o2.getCreatedAt().compareTo(o1.getCreatedAt()));
							userImage = userImageList.get(0);
							userImageList.remove(userImage);
							if (!userImageList.isEmpty()) {
								userImageRepository.deleteAll(userImageList);
							}
						} else {
							userImage = new UserImage();
							userImage.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
						}
						if (images.getImageId() != null) {
							Images uImage = imageRepository.findByImageId(images.getImageId());
							userImage.setImage(uImage);
						}
						if (registration.getId() != null) {
							User checkUser = userRepository.findByUserId(registration.getId());
							userImage.setUser(checkUser);
						}
						userImage.setStatus(true);
						userImage.setUserId(registration.getId());
						userImage.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
						userImageRepository.save(userImage);
						user.setUserImage(userImage);
					} else {
						throw new BusinessException(Constant.RESPONSE_FAIL, Constant.SYSTEM_ERROR,
								Constant.RESPONSE_EMPTY_DATA, 1001);
					}
				}
			}
			break;
		}
		logger.info("RegistrationServiceImpl updateUserDetails----ends----");
		return ResponseHelper.getSuccessResponse("", user, 200, Constant.RESPONSE_SUCCESS);
	}


	@Override
	public Response verifyEmail(String email, String code) {
		logger.info("RegistrationServiceImpl verifyEmail----starts----"+email,code);
		if (StringUtils.isEmpty(code)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(email)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByEmail(email);
		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.EMAIL_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (registration.getEmailVerificationCode().equalsIgnoreCase(code)) {
			if (registration.getIsEmailVerified()) {
				return ResponseHelper.getSuccessResponse(Constant.EMAIL_ALREADY_VERIFIED, Constant.RESPONSE_EMPTY_DATA,
						200, Constant.RESPONSE_SUCCESS);

			} else {
				Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
				if (config == null) {
					throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				Integer configValue = Integer.valueOf(config.getValue());

				boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getVerificationCodeCreatedAt(),
						configValue);
				if (isCodeExpired) {
					return ResponseHelper.getSuccessResponse(Constant.CODE_EXPIRED, Constant.RESPONSE_EMPTY_DATA, 200,
							Constant.RESPONSE_SUCCESS);
				}

				if (registration.getStatus() == Constant.STATUS_BLOCKED) {
					return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_BLOCKED, Constant.RESPONSE_EMPTY_DATA,
							200, Constant.RESPONSE_SUCCESS);
				}

				registration.setIsEmailVerified(true);
				registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				registrationRepository.save(registration);

				return ResponseHelper.getSuccessResponse(Constant.EMAIL_VERIFIED,
						Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_SUCCESS);
			}

		} else {

			Config config = cacheService.findByName(Constant.EMAIL_ATTEMPT);
			if (config == null) {
				logger.info("RegistrationServiceImpl verifyEmail----ends----");
				throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			} else {
				Integer configValue = Integer.valueOf(config.getValue());
				if (registration.getEmailFailureAttempt() < configValue) {

					registration.setEmailFailureAttempt(registration.getEmailFailureAttempt() + 1);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyEmail----ends----");
					return ResponseHelper.getSuccessResponse(Constant.INVALID_CODE, Constant.RESPONSE_EMPTY_DATA, 200,
							Constant.RESPONSE_SUCCESS);

				} else {
					registration.setStatus(Constant.STATUS_BLOCKED);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyEmail----ends----");
					return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_BLOCKED, Constant.RESPONSE_EMPTY_DATA,
							200, Constant.RESPONSE_SUCCESS);
				}
			}
		}

	}
	
	@Override
	public Response verifyUpdateEmail(String email, String code,Integer userId) throws Exception {
		logger.info("RegistrationServiceImpl verifyUpdateEmail----starts----"+email,code,userId);
		if (StringUtils.isEmpty(code)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(email)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (StringUtils.isEmpty(userId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByEmail(email);
		User user = userRepository.findByUserId(userId);
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.EMAIL_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (registration.getEmailVerificationCode().equalsIgnoreCase(code)) {
				Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
				if (config == null) {
					throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				Integer configValue = Integer.valueOf(config.getValue());
				boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getVerificationCodeCreatedAt(),
						configValue);
				if (isCodeExpired) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_EXPIRED,
							Constant.RESPONSE_EMPTY_DATA, 1501);
				}

				if (registration.getStatus() == Constant.STATUS_BLOCKED) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_BLOCKED,
							Constant.RESPONSE_EMPTY_DATA, 1502);
				}

				registration.setIsEmailVerified(true);
				registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				registrationRepository.save(registration);

				if (null != user) {
					if (null != user.getEmail()) {
						if (!registration.getEmail().equals(user.getEmail())) {
							Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
							user.setEmail(registration.getEmail());
							user.setStatus(Constant.STATUS_ACTIVE);
							user.setVerificationCodeCreatedAt(currentTime);
							user.setUpdatedAt(currentTime);
							user = userRepository.save(user);
						}
					}
				}

				if (registration.getEmail().equals(user.getEmail())) {
					registrationRepository.delete(registration);
				}

		} else {

			Config config = cacheService.findByName(Constant.EMAIL_ATTEMPT);
			if (config == null) {
				logger.info("RegistrationServiceImpl verifyUpdateEmail----ends----");
				throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			} else {
				Integer configValue = Integer.valueOf(config.getValue());
				if (registration.getEmailFailureAttempt() < configValue) {

					registration.setEmailFailureAttempt(registration.getEmailFailureAttempt() + 1);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyUpdateEmail----ends----");
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_CODE,
							Constant.RESPONSE_EMPTY_DATA, 1503);

				} else {
					registration.setStatus(Constant.STATUS_BLOCKED);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyUpdateEmail----ends----");
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_BLOCKED,
							Constant.RESPONSE_EMPTY_DATA, 1502);
				}
			}
		}
		logger.info("RegistrationServiceImpl verifyUpdateEmail----ends----");
		return ResponseHelper.getSuccessResponse(Constant.EMAIL_VERIFIED,
				Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_SUCCESS);

	}

	@Override
	public Response verifyMobile(String mobile, Integer code) throws Exception {
		logger.info("RegistrationServiceImpl verifyMobile----starts----"+mobile,code);
		if (StringUtils.isEmpty(code)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(mobile)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MOBILE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByMobile(mobile);
		User user = userRepository.findByEmail(mobile);

		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.MOBILE_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (registration.getMobileOTP().intValue() == code.intValue()) {
			if (registration.getIsMobileVerified()) {
				return ResponseHelper.getSuccessResponse(Constant.MOBILE_ALREADY_VERIFIED, Constant.RESPONSE_EMPTY_DATA,
						200, Constant.RESPONSE_SUCCESS);

			} else {

				Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
				if (config == null) {
					throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				Integer configValue = Integer.valueOf(config.getValue());
				boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getOtpCreatedAt(),
						configValue);
				if (isCodeExpired) {
					return ResponseHelper.getSuccessResponse(Constant.CODE_EXPIRED, Constant.RESPONSE_EMPTY_DATA, 200,
							Constant.RESPONSE_SUCCESS);
				}

				if (registration.getStatus() == Constant.STATUS_BLOCKED) {
					return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_BLOCKED, Constant.RESPONSE_EMPTY_DATA,
							200, Constant.RESPONSE_SUCCESS);
				}
				registration.setIsMobileVerified(true);
				registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				registrationRepository.save(registration);

				if (null != user) {
					if (null != user.getMobile()) {
						if (!registration.getEmail().equals(user.getMobile())) {
							Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
							user.setEmail(registration.getMobile());
							user.setIsMobileVerified(true);
							user.setStatus(Constant.STATUS_ACTIVE);
							user.setMobileOTP(registration.getMobileOTP());
							user.setVerificationCodeCreatedAt(currentTime);
							user.setCreatedAt(currentTime);
							user.setUpdatedAt(currentTime);
							user = userRepository.save(user);
						}
					}
				}
				
				return ResponseHelper.getSuccessResponse(Constant.MOBILE_VERIFIED, Constant.RESPONSE_EMPTY_DATA, 200,
						Constant.RESPONSE_SUCCESS);

			}

		} else {

			Config config = cacheService.findByName(Constant.MOBILE_ATTEMPT);
			if (config == null) {
				logger.info("RegistrationServiceImpl verifyMobile----ends----");
				throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			} else {
				Integer configValue = Integer.valueOf(config.getValue());
				if (registration.getMobileFailureAttempt() < configValue) {

					registration.setMobileFailureAttempt(registration.getMobileFailureAttempt() + 1);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyMobile----ends----");
					return ResponseHelper.getSuccessResponse(Constant.INVALID_CODE, Constant.RESPONSE_EMPTY_DATA, 200,
							Constant.RESPONSE_SUCCESS);

				} else {
					registration.setStatus(Constant.STATUS_BLOCKED);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyMobile----ends----");
					return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_BLOCKED, Constant.RESPONSE_EMPTY_DATA,
							200, Constant.RESPONSE_SUCCESS);
				}
			}
		}
	}

	@Override
	public Response verifyUpdateMobile(String mobile, Integer code,Integer userId,HttpServletRequest request) throws Exception {
		logger.info("RegistrationServiceImpl verifyUpdateMobile----starts----"+mobile,code,userId,request);
		if (StringUtils.isEmpty(code)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (StringUtils.isEmpty(mobile)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.MOBILE_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		
		if (StringUtils.isEmpty(userId)) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USER_ID_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		Registration registration = registrationRepository.findByMobile(mobile);
		User user = userRepository.findByUserId(userId);
		
		if (user == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.USERID_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}

		if (registration == null) {
			throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.MOBILE_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (registration.getMobileOTP().intValue() == code.intValue()) {
				Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
				if (config == null) {
					throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				Integer configValue = Integer.valueOf(config.getValue());
				boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getOtpCreatedAt(),
						configValue);
				if (isCodeExpired) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.CODE_EXPIRED,
							Constant.RESPONSE_EMPTY_DATA, 1501);
				}

				if (registration.getStatus() == Constant.STATUS_BLOCKED) {
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_BLOCKED,
							Constant.RESPONSE_EMPTY_DATA, 1502);
				}
				registration.setIsMobileVerified(true);
				registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
				registrationRepository.save(registration);

				if (null != user) {
							Timestamp currentTime = CommonUtils.GetCurrentTimeStamp();
							user.setMobile(registration.getMobile());
							user.setIsMobileVerified(true);
							user.setStatus(Constant.STATUS_ACTIVE);
							user.setMobileOTP(registration.getMobileOTP());
							user.setVerificationCodeCreatedAt(currentTime);
							user.setUpdatedAt(currentTime);
							user = userRepository.save(user);
							
							String authHeader = request.getHeader("Authorization");
							if (authHeader != null) {
								Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
								org.springframework.security.core.userdetails.User userDetails = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
								String tokenValue = authHeader.replace("Bearer", "").trim();
								OAuth2AccessToken accessToken = tokenStore.readAccessToken(tokenValue);
								final Map<String, Object> additionalInfo = new HashMap<String, Object>();
								
								additionalInfo.put("role", userDetails.getAuthorities());
						        com.eatzos.model.Vendor vendor = vendorRepository.findByUserUserId(user.getUserId());
						        
						        additionalInfo.put("userId", user.getUserId().toString());
						        additionalInfo.put("firstName", user.getFirstName());
						        additionalInfo.put("lastName", user.getLastName());
						    	additionalInfo.put("email", user.getEmail());
						    	additionalInfo.put("mobile", user.getMobile());
						    	if(vendor!=null) {
						        	additionalInfo.put("vendorId", vendor.getVendorId().toString());
						        }else {
						        	additionalInfo.put("vendorId", "");
						        }
						    	additionalInfo.put("status",Constant.RESPONSE_SUCCESS);
						        additionalInfo.put("code", 200);
						        additionalInfo.put("data", Constant.RESPONSE_EMPTY_DATA);
						    	additionalInfo.put("message", "");
						        
						        ((DefaultOAuth2AccessToken) accessToken)
						                .setAdditionalInformation(additionalInfo);
							}
				}
				
				if (registration.getMobile().equals(user.getMobile())) {
					registrationRepository.delete(registration);
				}
				
				return ResponseHelper.getSuccessResponse(Constant.MOBILE_VERIFIED, Constant.RESPONSE_EMPTY_DATA, 200,
						Constant.RESPONSE_SUCCESS);
		} else {

			Config config = cacheService.findByName(Constant.MOBILE_ATTEMPT);
			if (config == null) {
				logger.info("RegistrationServiceImpl verifyUpdateMobile----ends----");
				throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
						Constant.RESPONSE_EMPTY_DATA, 1001);
			} else {
				Integer configValue = Integer.valueOf(config.getValue());				
				if (registration.getMobileFailureAttempt() < configValue) {

					registration.setMobileFailureAttempt(registration.getMobileFailureAttempt() + 1);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyUpdateMobile----ends----");
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_CODE,
							Constant.RESPONSE_EMPTY_DATA, 1503);

				} else {
					registration.setStatus(Constant.STATUS_BLOCKED);
					registration.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					logger.info("RegistrationServiceImpl verifyUpdateMobile----ends----");
					throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ACCOUNT_BLOCKED,
							Constant.RESPONSE_EMPTY_DATA, 1502);
				}
			}
		}
	}
	
	@Override
	public Response verifyRegisterEmail(Registration registrationReq) throws Exception {
		logger.info("RegistrationServiceImpl verifyRegisterEmail----starts----");
		Map<String,String> map = new LinkedHashMap<>();
		if (Strings.isNullOrEmpty(registrationReq.getEmail())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		User userCheck = userRepository.findByEmail(registrationReq.getEmail());
		if (userCheck != null) {
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_ID_ALREADY_EXISTS,
					Collections.<String, Object>emptyMap(), 200, Constant.RESPONSE_FAIL);
		}
		Registration registration = registrationRepository.findByEmail(registrationReq.getEmail());
		if (registration == null) {
			Registration reg = new Registration();
			reg.setEmail(registrationReq.getEmail());
			reg.setEmailFailureAttempt(0);
			reg.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
			reg.setVerificationCodeCreatedAt(CommonUtils.GetCurrentTimeStamp());
			reg.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			registrationRepository.save(reg);
			userService.sendVerificationCode(reg.getEmail(), reg.getEmailVerificationCode(),
					reg.getEmail());
			return ResponseHelper.getSuccessResponse(Constant.REGISTRATION_VERIFICATION_CODE_SENT, map, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			if (!registration.getIsEmailVerified()) {
				Config config = cacheService.findByName(Constant.OTP_EXPIRED_MINS);
				if (config == null) {
					throw new BusinessException(Constant.RESPONSE_SUCCESS, Constant.SYSTEM_ERROR,
							Constant.RESPONSE_EMPTY_DATA, 1001);
				}
				Integer configValue = Integer.valueOf(config.getValue());
				boolean isCodeExpired = CommonUtils.validateCodeExpired(registration.getVerificationCodeCreatedAt(),
						configValue);
				if (isCodeExpired) {
					registration.setEmailFailureAttempt(0);
					registration.setEmailVerificationCode("" + CommonUtils.getRandomNumber());
					registration.setVerificationCodeCreatedAt(CommonUtils.GetCurrentTimeStamp());
					registration.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					registrationRepository.save(registration);
					userService.sendVerificationCode(registration.getEmail(), registration.getEmailVerificationCode(),
							registration.getEmail());
				}
				logger.info("RegistrationServiceImpl verifyRegisterEmail----ends----");
				return ResponseHelper.getSuccessResponse(Constant.REGISTRATION_VERIFICATION_CODE_SENT, map, 200,
						Constant.RESPONSE_SUCCESS);
			} else {
				map.put("emailVerified", "true");
				logger.info("RegistrationServiceImpl verifyRegisterEmail----ends----");
				return ResponseHelper.getSuccessResponse(Constant.REGISTRATION_EMAIL_VERIFIED, map, 200,
						Constant.RESPONSE_SUCCESS);
			}
		}
	}
	
	
	@Override
	public Response signUp(RegistrationSignupRequest signupRequest) throws Exception {
		logger.info("RegistrationServiceImpl verifyRegisterEmail----starts----");
		Map<String,String> map = new LinkedHashMap<>();
		if (Strings.isNullOrEmpty(signupRequest.getEmail())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.EMAIL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		User userCheck = userRepository.findByEmail(signupRequest.getEmail());
		if (userCheck != null) {
			return ResponseHelper.getSuccessResponse(Constant.EMAIL_ID_ALREADY_EXISTS,
					Collections.<String, Object>emptyMap(), 1001, Constant.RESPONSE_FAIL);
		}
		Registration registration = registrationRepository.findByEmail(signupRequest.getEmail());
		if (registration == null) {
			return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_NOT_FOUND,
					Collections.<String, Object>emptyMap(), 1001, Constant.RESPONSE_FAIL);
		} 
		
		map.put("emailVerified", String.valueOf(registration.getIsEmailVerified()));
		if(Strings.isNullOrEmpty(signupRequest.getFirstName())) {
			return ResponseHelper.getSuccessResponse(Constant.FIRST_NAME_REQUIRED, Collections.<String, Object>emptyMap(), 1001,
					Constant.RESPONSE_FAIL);
		}
		if(Strings.isNullOrEmpty(signupRequest.getLastName())) {
			return ResponseHelper.getSuccessResponse(Constant.LAST_NAME_REQUIRED, Collections.<String, Object>emptyMap(), 1001,
					Constant.RESPONSE_FAIL);
		}
		if(Strings.isNullOrEmpty(signupRequest.getPassword())) {
			return ResponseHelper.getSuccessResponse(Constant.PASSWORD_IS_REQUIRED, Collections.<String, Object>emptyMap(), 1001,
					Constant.RESPONSE_FAIL);
		}
		if(!Strings.isNullOrEmpty(registration.getEmail())) {
			map.put("email", registration.getEmail());
		}
		registration.setFirstName(signupRequest.getFirstName());
		registration.setLastName(signupRequest.getLastName());
		if (registration.getIsEmailVerified()) {
			User user = new User();
			user.setFirstName(registration.getFirstName());
			user.setLastName(registration.getLastName());
			user.setEmail(registration.getEmail());
			user.setEmailVerified(true);
			user.setIsMobileVerified(false);
			user.setPassword(bcryptEncoder.encode(signupRequest.getPassword()));
			user.setStatus(Constant.STATUS_ACTIVE);
			user.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			user = userRepository.save(user);
			if (user.getUserId() != null) {
				UserRole userRole = new UserRole();
				userRole.setUser(user);
				Role role = rolesRepository.findByRoleId(2);
				if (role != null) {
					userRole.setRoles(role);
				}
				userRolesRepository.save(userRole);
			}
			if (!Strings.isNullOrEmpty(signupRequest.getFrom()) && signupRequest.getFrom().equalsIgnoreCase(Constant.SELLER)) {
				userService.sendUserRegisterMailToEatzosAdmin(registration.getEmail(), registration.getMobile(), registration.getFirstName());
				String vendorName = registration.getFirstName() + " " + registration.getLastName();
				vendorService.sendVendorRegMail(registration.getEmail(), registration.getFirstName(), vendorName);
			}
			registrationRepository.delete(registration);
			logger.info("RegistrationServiceImpl verifyRegisterEmail----ends----");
			return ResponseHelper.getSuccessResponse(Constant.REGISTRATION_COMPLETED, map, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			logger.info("RegistrationServiceImpl verifyRegisterEmail----ends----");
			return ResponseHelper.getSuccessResponse(Constant.REGISTRATION_EMAIL_NOT_VERIFIED, Collections.emptyMap(), 1001,
					Constant.RESPONSE_FAIL);
		}
	}
}
