package com.eatzos.service.impl;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.amazonaws.util.StringUtils;
import com.eatzos.config.AuthenticationConfig;
import com.eatzos.exception.BusinessException;
import com.eatzos.helper.PaymentConverterHelper;
import com.eatzos.helper.ResponseHelper;
import com.eatzos.model.BuyerPayment;
import com.eatzos.model.Orders;
import com.eatzos.model.SellerPayment;
import com.eatzos.model.TransactionStatus;
import com.eatzos.model.User;
import com.eatzos.model.Vendor;
import com.eatzos.repository.BuyerPaymentRepository;
import com.eatzos.repository.OrdersRepository;
import com.eatzos.repository.SellerPaymentRepository;
import com.eatzos.repository.TransactionStatusRepository;
import com.eatzos.repository.UserRepository;
import com.eatzos.repository.VendorRepository;
import com.eatzos.request.BuyerPaymentRequest;
import com.eatzos.request.CustomAccountPaymentRequest;
import com.eatzos.request.PaymentRequest;
import com.eatzos.request.SellerPaymentRequest;
import com.eatzos.service.PaymentService;
import com.eatzos.service.UserService;
import com.eatzos.util.CommonUtils;
import com.eatzos.util.Constant;
import com.eatzos.util.Response;
import com.google.common.base.Strings;
import com.stripe.Stripe;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.exception.StripeException;
import com.stripe.model.Account;
import com.stripe.model.AccountLink;
import com.stripe.model.LoginLink;
import com.stripe.model.Plan;
import com.stripe.model.PlanCollection;
import com.stripe.model.Transfer;
import com.stripe.model.checkout.Session;
import com.stripe.param.AccountCreateParams;
import com.stripe.param.checkout.SessionCreateParams;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(value = "paymentService")
public class PaymentServiceImpl implements PaymentService {

	private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);
	
	@Value("${stripe.api}")
	private String stripeApiKey;
	
	@Autowired
	private SellerPaymentRepository sellerPaymentRepository;
	
	@Autowired
	private TransactionStatusRepository transactionStatusRepository;
	
	@Autowired
	private BuyerPaymentRepository buyerPaymentRepository;
	
	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private UserRepository userRepository;
	
	@Value("${transaction.currency.type}")
	private String currencyType;
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	@Autowired
	private UserService userService;
	
	@Value("${transaction.charge}")
	private String transactionCharge;
	
	@Autowired
	private AuthenticationConfig authenticationConfig;
	
	@Override
	public Response saveSellerPayment(SellerPaymentRequest sellerPaymentRequest) throws Exception {
		logger.info("PaymentServiceImpl saveSellerPayment----starts----"+sellerPaymentRequest);
		SellerPayment sellerPayment = new SellerPayment();
		Vendor vendor = vendorRepository.findByVendorId(sellerPaymentRequest.getVendorId());
		if(vendor==null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		sellerPayment.setAmount(sellerPaymentRequest.getAmount());
		sellerPayment.setPaymentReason(sellerPaymentRequest.getPaymentReason());
		sellerPayment.setTransactionDate(CommonUtils.stringToTimestampConversion(CommonUtils.convertStringToTimestamp(sellerPaymentRequest.getTransactionDate())));
		sellerPayment.setTransactionId(sellerPaymentRequest.getTransactionId());
		sellerPayment.setVendor(vendor);
		sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		sellerPayment = sellerPaymentRepository.save(sellerPayment);
		vendor.setIsSubscriptionPaid(false);
		if(sellerPaymentRequest.getAmount()!=null && sellerPaymentRequest.getAmount()>0)  {
			vendor.setIsSubscriptionPaid(true);
			vendorRepository.save(vendor);
		}
		logger.info("PaymentServiceImpl saveSellerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseFromSellerEntity(sellerPayment), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response saveBuyerPayment(BuyerPaymentRequest buyerPaymentRequest) throws Exception {
		logger.info("PaymentServiceImpl saveBuyerPayment----starts----"+buyerPaymentRequest);
		BuyerPayment buyerPayment = new BuyerPayment();
		User user = userRepository.findByUserId(buyerPaymentRequest.getUserId());
        if (user == null) {
            throw new BusinessException(Constant.RESPONSE_FAIL, Constant.USERID_NOT_FOUND,
                    Constant.RESPONSE_EMPTY_DATA, 1001);
        }
		buyerPayment.setAmount(buyerPaymentRequest.getAmount());
		buyerPayment.setStripeId(buyerPaymentRequest.getStripeId());
		buyerPayment.setTransactionDate(CommonUtils.stringToTimestampConversion(CommonUtils.convertStringToTimestamp(buyerPaymentRequest.getTransactionDate())));
		buyerPayment.setTransactionId(buyerPaymentRequest.getTransactionId());
		buyerPayment.setUser(user);
		buyerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
		buyerPayment = buyerPaymentRepository.save(buyerPayment);
		logger.info("PaymentServiceImpl saveBuyerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseFromBuyerEntity(buyerPayment), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getAllBuyerPayment() throws Exception {
		logger.info("PaymentServiceImpl getAllBuyerPayment----starts----");
		List<BuyerPayment> list = new ArrayList<>();
		Iterable<BuyerPayment> buyerPaymentList = buyerPaymentRepository.findAll();
		buyerPaymentList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);
		}
		logger.info("PaymentServiceImpl getAllBuyerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseListFromBuyerEntity(list), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getAllSellerPayment() throws Exception {
		logger.info("PaymentServiceImpl getAllSellerPayment----starts----");
		List<SellerPayment> list = new ArrayList<>();
		Iterable<SellerPayment> sellerPaymentList = sellerPaymentRepository.findAll();
		sellerPaymentList.iterator().forEachRemaining(list::add);
		if (CommonUtils.IsNullOrEmpty(list)) {
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, list, 200, Constant.RESPONSE_SUCCESS);
		}
		logger.info("PaymentServiceImpl getAllSellerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseListFromSellerEntity(list), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getSellerPayment(Integer id) throws Exception {
		logger.info("PaymentServiceImpl getSellerPayment----starts----"+id);
		List<SellerPayment> sellerPayment = sellerPaymentRepository.findByVendorVendorId(id);
		if (CommonUtils.IsNullOrEmpty(sellerPayment)) {
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, sellerPayment, 200, Constant.RESPONSE_SUCCESS);
		}
		logger.info("PaymentServiceImpl getSellerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseListFromSellerEntity(sellerPayment), 200, Constant.RESPONSE_SUCCESS);
	}
	
	@Override
	public Response getBuyerPayment(Integer id) throws Exception {
		logger.info("PaymentServiceImpl getBuyerPayment----starts----"+id);
		List<BuyerPayment> buyerPayment = buyerPaymentRepository.findByUserUserId(id);
		if (CommonUtils.IsNullOrEmpty(buyerPayment)) {
			return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, buyerPayment, 200, Constant.RESPONSE_SUCCESS);
		}
		logger.info("PaymentServiceImpl getBuyerPayment----ends----");
		return ResponseHelper.getSuccessResponse(Constant.FETCH_DATA, PaymentConverterHelper.getResponseListFromBuyerEntity(buyerPayment), 200, Constant.RESPONSE_SUCCESS);
	}

	@Override
	public Response createCustomAccount(CustomAccountPaymentRequest customAccountPaymentRequest) throws Exception {
		logger.info("PaymentServiceImpl createCustomAccount----starts----"+customAccountPaymentRequest);
		Map<String, String> map = new HashMap<String, String>();
		Stripe.apiKey = stripeApiKey;
		 AccountLink accountLink = null;
		 String accountId = null;
		User accessUser = userService.getUserByAccessToken();
		if(Strings.isNullOrEmpty(customAccountPaymentRequest.getReturnUrl())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.RETURN_URL_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(Strings.isNullOrEmpty(customAccountPaymentRequest.getRefreshUrl())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.REFRESH_URL_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		} 
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Strip Cusstomer Id", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(vendor.getPaymentStatus()) {
			map.put("url", "");
			map.put("status", "Account already added");
			 return ResponseHelper.getSuccessResponse("Account already added", map, 200, Constant.RESPONSE_SUCCESS);
		}
		if(Strings.isNullOrEmpty(vendor.getStripeAccountId())) {
			try {
				
			Map<String, Object> cardPayments = new HashMap<>();
			cardPayments.put(Constant.REQUESTED, true);
			Map<String, Object> transfers = new HashMap<>();
			transfers.put(Constant.REQUESTED, true);
			Map<String, Object> capabilities = new HashMap<>();
			capabilities.put(Constant.CARD_PAYMENTS, cardPayments);
			capabilities.put(Constant.TRANSFERS, transfers);
			Map<String, Object> params = new HashMap<>();
			params.put(Constant.TYPE, AccountCreateParams.Type.EXPRESS);
			params.put(Constant.COUNTRY, Constant.US);
			params.put(Constant.EMAIL, vendor.getUser().getEmail());
			params.put(Constant.CAPABILITIES, capabilities);

			Account account = Account.create(params);
			if(account!=null) {
				accountId = account.getId();
				vendor.setStripeAccountId(account.getId());
				vendorRepository.save(vendor);
			}
			}  catch (CardException e) {
				e.printStackTrace();
			} catch (InvalidRequestException e) {
				e.printStackTrace();
			}	catch (StripeException e) {
				e.printStackTrace();
			}
		} else {
			accountId = vendor.getStripeAccountId();
		}

		if(accountId!=null) {
			try {
				
			Map<String, Object> params2 = new HashMap<>();
			params2.put(Constant.ACCOUNT, accountId);
			params2.put(Constant.REFRESH_URL, customAccountPaymentRequest.getRefreshUrl());
			params2.put(Constant.RETURN_URL, customAccountPaymentRequest.getReturnUrl());
			params2.put(Constant.TYPE, "account_onboarding");
			accountLink = AccountLink.create(params2);
			if (accountLink != null) {
				map.put("url", accountLink.getUrl());
			}
			}  catch (CardException e) {
				e.printStackTrace();
			} catch (InvalidRequestException e) {
				e.printStackTrace();
			}	catch (StripeException e) {
				e.printStackTrace();
			}
		}
		logger.info("PaymentServiceImpl createCustomAccount----ends----");
		return ResponseHelper.getSuccessResponse("Account Link done", map, 200, Constant.RESPONSE_SUCCESS);

	}
	
	@Override
	public Response dailyScheduler() throws ParseException, StripeException {
		logger.info("PaymentServiceImpl dailyScheduler----starts----");
		//Timestamp orderDate = CommonUtils.stringToTimeStamp(CommonUtils.previousDateWithTimeStamp());
		//ordersRepository.findAllByOrderDateLessThanEqualAndVendorStripeAccountId(orderDate, "acct_1Igi4P4JoWYNRnCG");
		List<Orders> orderList = ordersRepository.findByVendorVendorIdAndPaidToSeller(106,false);
		for (Orders order : orderList) {
				boolean flag = makePayment(order);
				if (flag) {
					order.setPaidToSeller(true);
					order.setUpdatedAt(CommonUtils.GetCurrentTimeStamp());
					ordersRepository.save(order);
					logger.info("PaymentServiceImpl dailyScheduler----ends----");
					return ResponseHelper.getSuccessResponse(Constant.PAYMENT_SUCCESS, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
				}
		}
				return ResponseHelper.getSuccessResponse(Constant.PAYMENT_FAILED, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);
		 
	}
	
	public boolean makePayment(Orders order) throws StripeException {
		logger.info("PaymentServiceImpl makePayment----starts----"+order);
		Stripe.apiKey = stripeApiKey;
		boolean flag = false;
		if (order.getVendor() == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (Strings.isNullOrEmpty(order.getVendor().getStripeAccountId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Strip Cusstomer Id", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		try {
			Map<String, Object> params = new HashMap<>();
			Double commissionAmount = Double.parseDouble(transactionCharge);
			Double totalAmount = order.getOrderAmount() * ((100F-commissionAmount) /100F);
			int transactionAmount = (int)Math.round(totalAmount*100);
			
			params.put("amount", transactionAmount);
			params.put("currency", Constant.CURRENCY_TYPE);
			params.put("destination", order.getVendor().getStripeAccountId());
			Transfer transfer = Transfer.create(params);
			if(transfer!=null) {
				SellerPayment sellerPayment = new SellerPayment();
				sellerPayment.setAmount(Double.valueOf(transfer.getAmount()));
				if(Strings.isNullOrEmpty(transfer.getDescription()) ) {
					transfer.setDescription(Constant.PAYMENT_SUCCESS);
				}
				sellerPayment.setPaymentReason(transfer.getDescription());
				Instant instant = Instant.ofEpochSecond(transfer.getCreated());
				Timestamp transactionDate = Timestamp.from(instant);
				sellerPayment.setTransactionDate(transactionDate);
				sellerPayment.setTransactionId(transfer.getId());
				sellerPayment.setVendor(order.getVendor());
				sellerPayment.setOrder(order);
				sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				sellerPayment = sellerPaymentRepository.save(sellerPayment);
				
				TransactionStatus transactionStatus = new TransactionStatus();
				transactionStatus.setStatusCode(200);
				transactionStatus.setMessage(Constant.RESPONSE_SUCCESS);
				transactionStatus.setTransactionType(Constant.PAY_OUT);
				//transactionStatus.setVendor(order.getVendor());
				transactionStatusRepository.save(transactionStatus);
				flag = true;
			}
		} catch (CardException e) {
			TransactionStatus transactionStatus = new TransactionStatus();
			transactionStatus.setStatusCode(e.getStatusCode());
			transactionStatus.setMessage(e.getMessage());
			transactionStatus.setTransactionType(Constant.PAY_OUT);
			//transactionStatus.setVendor(order.getVendor());
			transactionStatusRepository.save(transactionStatus);
		} catch (InvalidRequestException e) {
			TransactionStatus transactionStatus = new TransactionStatus();
			transactionStatus.setStatusCode(e.getStatusCode());
			transactionStatus.setMessage(e.getMessage());
			//transactionStatus.setVendor(order.getVendor());
			transactionStatus.setTransactionType(Constant.PAY_OUT);
			transactionStatusRepository.save(transactionStatus);
			logger.info("Stripe account ID --->"+order.getVendor().getStripeAccountId());
			logger.info("Vendor ID --->"+order.getVendor().getVendorId());
			logger.info("User ID --->"+order.getUser().getUserId());
		} catch (StripeException e) {
			TransactionStatus transactionStatus = new TransactionStatus();
			transactionStatus.setStatusCode(e.getStatusCode());
			transactionStatus.setMessage(e.getMessage());
			//transactionStatus.setVendor(order.getVendor());
			transactionStatus.setTransactionType(Constant.PAY_OUT);
			transactionStatusRepository.save(transactionStatus);
		}
		logger.info("PaymentServiceImpl makePayment----ends----");
		return flag;
	}
	
	@Override
	public Response retriveCustomAccount() throws Exception {
		logger.info("PaymentServiceImpl retriveCustomAccount----starts----");
		Map<String, Object> map = new HashMap<String, Object>();
		Stripe.apiKey = stripeApiKey;
		Account account = null;
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Strip Cusstomer Id", Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(!vendor.getPaymentStatus()) {
			map.put("account", "");
			return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_NOT_FOUND, map, 200, Constant.RESPONSE_SUCCESS);
		}
		if(Strings.isNullOrEmpty(vendor.getStripeAccountId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STRIPE_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		account = Account.retrieve(vendor.getStripeAccountId());
		if(account!=null) {
			if(account.getExternalAccounts()!=null && account.getExternalAccounts().getData()!=null) {
				map.put("account", account.getExternalAccounts().getData());
			}
		}
		
		logger.info("PaymentServiceImpl retriveCustomAccount----ends----");
		return ResponseHelper.getSuccessResponse(Constant.ACCOUNT_RETRIVED, map, 200, Constant.RESPONSE_SUCCESS);

	}

	@Override
	public Response updateCustomAccount(CustomAccountPaymentRequest customAccountPaymentRequest) throws Exception {
		logger.info("PaymentServiceImpl updateCustomAccount----starts----"+customAccountPaymentRequest);
		Map<String, String> map = new HashMap<String, String>();
		Stripe.apiKey = stripeApiKey;
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if(Strings.isNullOrEmpty(vendor.getStripeAccountId())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.STRIPE_ID_IS_REQUIRED, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Account account = Account.retrieve(vendor.getStripeAccountId());

		if(account!=null) {
			try {
				Map<String, Object> params = new HashMap<>();
				LoginLink loginLink = LoginLink.createOnAccount(account.getId(), params, null);
				if (loginLink != null) {
					map.put("url", loginLink.getUrl()+"#/account");
				}
				}  catch (CardException e) {
					e.printStackTrace();
				} catch (InvalidRequestException e) {
					e.printStackTrace();
				}	catch (StripeException e) {
					e.printStackTrace();
				}
			
		}
		logger.info("PaymentServiceImpl updateCustomAccount----ends----");
		return ResponseHelper.getSuccessResponse("Account Link updated", map, 200, Constant.RESPONSE_SUCCESS);

	}
	
	@Override
	public Response stripeStatusUpdate(boolean status) throws Exception {
		logger.info("PaymentServiceImpl stripeStatusUpdate----starts----" + status);
		Stripe.apiKey = stripeApiKey;
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		if (Strings.isNullOrEmpty(vendor.getStripeAccountId())) {
			vendor.setPaymentStatus(false);
		}
		Account account = Account.retrieve(vendor.getStripeAccountId());
		if (account != null) {
			String cardPayments = account.getCapabilities().getCardPayments();
			String transfers = account.getCapabilities().getTransfers();
			if (!StringUtils.isNullOrEmpty(cardPayments) && !StringUtils.isNullOrEmpty(transfers)
					&& cardPayments.equalsIgnoreCase("active") && transfers.equalsIgnoreCase("active")) {
				vendor.setPaymentStatus(true);
			} else {
				vendor.setPaymentStatus(false);
			}
		} else {
			vendor.setPaymentStatus(false);
		}
		vendorRepository.save(vendor);
		logger.info("PaymentServiceImpl stripeStatusUpdate----ends----");
		if (vendor.getPaymentStatus()) {
			return ResponseHelper.getSuccessResponse(Constant.UPDATE_VENDOR, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_SUCCESS);
		} else {
			return ResponseHelper.getSuccessResponse(Constant.UPDATE_VENDOR, Constant.RESPONSE_EMPTY_DATA, 200,
					Constant.RESPONSE_FAIL);
		}
	}
	
	/*@Override
	public Response stripeStatusUpdate(boolean status) throws Exception {
		logger.info("PaymentServiceImpl stripeStatusUpdate----starts----"+status);
		User accessUser = userService.getUserByAccessToken();
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		vendor.setPaymentStatus(true);
		
		vendorRepository.save(vendor);
		logger.info("PaymentServiceImpl stripeStatusUpdate----ends----");
		return ResponseHelper.getSuccessResponse(Constant.UPDATE_VENDOR, Constant.RESPONSE_EMPTY_DATA, 200, Constant.RESPONSE_SUCCESS);

	}*/
	
	public TransactionStatus makeUnpaidSellerPayment(Orders order) {
		logger.info("PaymentServiceImpl makeUnpaidSellerPayment----starts----"+order);
		SellerPayment sellerPayment = new SellerPayment();
		TransactionStatus transactionStatus = new TransactionStatus();
		Stripe.apiKey = stripeApiKey;
		boolean flag = false;
		int transactionAmount = 0;

		if(order.getVendor() != null && !Strings.isNullOrEmpty(order.getVendor().getStripeAccountId()) ) {
			try {
				Map<String, Object> params = new HashMap<>();
				Double commissionAmount = Double.parseDouble(transactionCharge);
				Double totalAmount = order.getOrderAmount() * ((100F-commissionAmount) /100F);
				transactionAmount = (int) Math.round(totalAmount * 100); // Stripe will expect Original Value*100
				params.put("amount", transactionAmount);
				params.put("currency", currencyType);
				params.put("destination", order.getVendor().getStripeAccountId());
				Transfer transfer = Transfer.create(params);
				if (transfer != null) {
					// log.info("Payment Success :: " + order.getVendorId());
					sellerPayment.setAmount(Double.valueOf(transfer.getAmount()));
					if (Strings.isNullOrEmpty(transfer.getDescription())) {
						transfer.setDescription(Constant.PAYMENT_SUCCESS);
					}
					sellerPayment.setPaymentReason(transfer.getDescription());
					Instant instant = Instant.ofEpochSecond(transfer.getCreated());
					sellerPayment.setTransactionDate(Timestamp.from(instant));
					sellerPayment.setTransactionId(transfer.getId());
					sellerPayment.setVendor(order.getVendor());
					sellerPayment.setOrder(order);
					sellerPayment.setTransactionType(Constant.TRANSFERS);
					sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
					sellerPayment = sellerPaymentRepository.save(sellerPayment);

					transactionStatus.setStatusCode(Constant.STATUS_CODE_SUCCESS);
					transactionStatus.setMessage(Constant.RESPONSE_SUCCESS);
					transactionStatus.setTransactionType(Constant.PAY_OUT);
					transactionStatusRepository.save(transactionStatus);
					flag = true;
				} else {
					log.info("Stripe Call Failed");
				
					// ToDO In case of Failover case
					transactionStatus.setStatusCode(Constant.STATUS_CODE_SERVER_ERROR);
					transactionStatus.setMessage(Constant.SERVER_ERROR);
					transactionStatus.setTransactionType(Constant.PAY_OUT);
					transactionStatusRepository.save(transactionStatus);
				}
			} catch (CardException e) {

				log.error("CardException ::" + e.getMessage());
			
				sellerPayment.setAmount(Double.valueOf(transactionAmount));
				sellerPayment.setPaymentReason(Constant.EXCEPTION_OCCUR_IN_SCHEDULER);
				sellerPayment.setVendor(order.getVendor());
				sellerPayment.setOrder(order);
				sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				sellerPayment.setTransactionType(Constant.TRANSFERS);
				sellerPayment.setFailedPayoutCount(order.getFailedPayoutCount());
				sellerPayment.setTransactionDate(CommonUtils.GetCurrentTimeStamp());
				sellerPayment = sellerPaymentRepository.save(sellerPayment);

				transactionStatus.setStatusCode(e.getStatusCode());
				transactionStatus.setMessage(e.getMessage());
				transactionStatus.setTransactionType(Constant.PAY_OUT);
				transactionStatusRepository.save(transactionStatus);

			} catch (InvalidRequestException e) {

				log.error("InvalidRequestException ::" + e.getMessage());

				sellerPayment.setAmount(Double.valueOf(transactionAmount));
				sellerPayment.setPaymentReason(Constant.EXCEPTION_OCCUR_IN_SCHEDULER);
				sellerPayment.setVendor(order.getVendor());
				sellerPayment.setOrder(order);
				sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				sellerPayment.setTransactionType(Constant.TRANSFERS);
				sellerPayment.setFailedPayoutCount(order.getFailedPayoutCount());
				sellerPayment.setTransactionDate(CommonUtils.GetCurrentTimeStamp());
				sellerPayment = sellerPaymentRepository.save(sellerPayment);

				transactionStatus.setStatusCode(e.getStatusCode());
				transactionStatus.setMessage(e.getMessage());
				transactionStatus.setTransactionType(Constant.PAY_OUT);
				transactionStatusRepository.save(transactionStatus);
			} catch (StripeException e) {

				log.error("StripeException ::" + e.getMessage());

				sellerPayment.setAmount(Double.valueOf(transactionAmount));
				sellerPayment.setPaymentReason(Constant.EXCEPTION_OCCUR_IN_SCHEDULER);
				sellerPayment.setVendor(order.getVendor());
				sellerPayment.setOrder(order);
				sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
				sellerPayment.setTransactionType(Constant.TRANSFERS);
				sellerPayment.setFailedPayoutCount(order.getFailedPayoutCount());
				sellerPayment.setTransactionDate(CommonUtils.GetCurrentTimeStamp());
				sellerPayment = sellerPaymentRepository.save(sellerPayment);

				transactionStatus.setStatusCode(e.getStatusCode());
				transactionStatus.setMessage(e.getMessage());
				transactionStatus.setTransactionType(Constant.PAY_OUT);
				transactionStatusRepository.save(transactionStatus);
			} catch (Exception ex) {
				log.error("StripeException ::" + ex.getMessage());
			
				transactionStatus.setStatusCode(Constant.STATUS_CODE_SERVER_ERROR);
				transactionStatus.setMessage(ex.getMessage());
				transactionStatus.setTransactionType(Constant.PAY_OUT);
				transactionStatusRepository.save(transactionStatus);

			} 
			logger.info("PaymentServiceImpl makeUnpaidSellerPayment----ends----");
			transactionStatus.setFlag(flag);
			return transactionStatus;
		}else {
			log.info("Vendor Not Mapped / Vendor StripeId Not Maped==>"+
					(order.getVendor()!=null?order.getVendor().getVendorId():order.getOrderId()) );

			sellerPayment.setAmount(Double.valueOf(transactionAmount));
			sellerPayment.setPaymentReason(Constant.EXCEPTION_OCCUR_IN_SCHEDULER);
			sellerPayment.setVendor(order.getVendor());
			sellerPayment.setOrder(order);
			sellerPayment.setCreatedAt(CommonUtils.GetCurrentTimeStamp());
			sellerPayment.setTransactionType(Constant.TRANSFERS);
			sellerPayment.setFailedPayoutCount(order.getFailedPayoutCount());
			sellerPayment.setTransactionDate(CommonUtils.GetCurrentTimeStamp());
			sellerPayment = sellerPaymentRepository.save(sellerPayment);

			transactionStatus.setStatusCode(Constant.STATUS_CODE_SERVER_ERROR);
			transactionStatus.setMessage(Constant.STRIPE_ID_IS_REQUIRED);
			transactionStatus.setTransactionType(Constant.PAY_OUT);
			transactionStatusRepository.save(transactionStatus);
			logger.info("PaymentServiceImpl makeUnpaidSellerPayment----ends----");
			transactionStatus.setFlag(flag);
			return transactionStatus;
		}

	}

	@Override
	public Response PayUnpaidSellers(PaymentRequest paymentRequest) throws Exception {
		// TODO Auto-generated method stub
		logger.info("PaymentServiceImpl PayUnpaidSellers----starts----"+paymentRequest);
		Optional<Orders> optionalOrder = ordersRepository.findByVendorVendorIdAndOrderIdAndPaidToSellerAndFailedPayoutCount(paymentRequest.getVendorId(),
				paymentRequest.getOrderId(),false,3		);

		if(optionalOrder.isPresent()) {
			log.info("Payment initiated for Vendor--->"+optionalOrder.get().getVendor().getVendorId() );
			TransactionStatus paymentFlag=makeUnpaidSellerPayment(optionalOrder.get());

			if(!paymentFlag.isFlag())
				return ResponseHelper.getSuccessResponse(paymentFlag.getMessage(), Constant.RESPONSE_EMPTY_DATA, 500,
						Constant.RESPONSE_SUCCESS);
			else {
				Orders order =optionalOrder.get();
				order.setPaidToSeller(true);
				ordersRepository.save(order);
				logger.info("PaymentServiceImpl PayUnpaidSellers----ends----");
				return ResponseHelper.getSuccessResponse(Constant.PAYMENT_SUCCESS, Constant.RESPONSE_EMPTY_DATA, 200,
						Constant.RESPONSE_SUCCESS);

			}

		}else {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.ORDER_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}

	}
	
	@Override
	public Response createCustomAccountTest() throws Exception {
		// TODO Auto-generated method stub
		logger.info("PaymentServiceImpl createCustomAccountTest----starts----");
		try {
			Stripe.apiKey = "sk_test_51ILqK9KbtLQQMQOde7DYg5Zzqx7PPw0twCQ6V3hle4W1vTWvrQaLLfMqIR9s1HOivd1MPLdnuRyMDYQtaILB0pib00znowJEOS";
			List<Object> lineItems = new ArrayList<>();
			Map<String, Object> lineItem1 = new HashMap<>();
			lineItem1.put("price", "price_1KqcR4KbtLQQMQOdULZZ2xGf");
			lineItem1.put("quantity", 1);
			lineItems.add(lineItem1);
			Map<String, Object> params = new HashMap<>();
			params.put("success_url", "https://seller-dev.eatzos.com/#/vendor-profile?status=success&tab=" + "ca"
					+ "&session_id={CHECKOUT_SESSION_ID}");
			params.put("cancel_url", "https://seller-dev.eatzos.com/#/vendor-profile?status=success&tab=" + "ca"
					+ "&session_id={CHECKOUT_SESSION_ID}");
			params.put("line_items", lineItems);
			params.put("mode", "subscription");
			Session session = Session.create(params);
			logger.info("session.getSuccessUrl()---->" + session.getSuccessUrl());
			logger.info("PaymentServiceImpl createCustomAccountTest----ends----");
		} catch (CardException e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Response getsubscription() throws Exception {
		logger.info("PaymentServiceImpl getsubscription----starts----");
		// TODO Auto-generated method stub
		Response res = new Response();
		User accessUser = authenticationConfig.getUserByAccessToken();
		Vendor existingVendor = vendorRepository.findByUserUserId(accessUser.getUserId());
		if (existingVendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.INVALID_ACCESS, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		Vendor vendor = vendorRepository.findByVendorId(existingVendor.getVendorId());
		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.VENDOR_NOT_FOUND, Constant.RESPONSE_EMPTY_DATA,
					1001);
		}
		
		Map<String,String> value = new LinkedHashMap<String,String>();
		value.put("priceId", vendor.getPriceId());
		value.put("customerId", vendor.getCustomerId());
		value.put("subscriptionId", vendor.getSubscriptionId());
		
		res.setCode(200);
		res.setData(value);
		logger.info("PaymentServiceImpl getsubscription----ends----");
		return res;
	}	
	
	@Override
	public Response createSession(CustomAccountPaymentRequest customAccountPaymentRequest) throws Exception {
		// TODO Auto-generated method stub
		logger.info("PaymentServiceImpl createSession----starts----"+customAccountPaymentRequest);
		Map<String, String> map = new HashMap<String, String>();
		Stripe.apiKey = stripeApiKey;
		AccountLink accountLink = null;
		String accountId = null;
		User accessUser = userService.getUserByAccessToken();
		if (Strings.isNullOrEmpty(customAccountPaymentRequest.getReturnUrl())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.RETURN_URL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (Strings.isNullOrEmpty(customAccountPaymentRequest.getRefreshUrl())) {
			throw new BusinessException(Constant.RESPONSE_FAIL, Constant.REFRESH_URL_IS_REQUIRED,
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());

		if (vendor == null) {
			throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Strip Cusstomer Id",
					Constant.RESPONSE_EMPTY_DATA, 1001);
		}
		if (vendor.getPaymentStatus()) {
			map.put("url", "");
			map.put("status", "Account already added");
			return ResponseHelper.getSuccessResponse("Account already added", map, 200, Constant.RESPONSE_SUCCESS);
		}
		if (Strings.isNullOrEmpty(vendor.getStripeAccountId())) {
			try {
				List<Object> lineItems = new ArrayList<>();
				Map<String, Object> lineItem1 = new HashMap<>();
				lineItem1.put("price", customAccountPaymentRequest.getPriceId());
				lineItem1.put("quantity", 1);
				lineItems.add(lineItem1);
				Map<String, Object> params = new HashMap<>();
				params.put("success_url", customAccountPaymentRequest.getReturnUrl());
				params.put("cancel_url", customAccountPaymentRequest.getRefreshUrl());
				params.put("line_items", lineItems);
				params.put("mode", "subscription");
				Session account = Session.create(params);

				map.put("url", account.getUrl());
				map.put("status", "payment url");
				
//				Account account = Account.create(params);
				if (account != null) {
					accountId = account.getId();
					vendor.setStripeAccountId(account.getId());
					vendorRepository.save(vendor);
				}
			} catch (CardException e) {
				e.printStackTrace();
			} catch (InvalidRequestException e) {
				e.printStackTrace();
			} catch (StripeException e) {
				e.printStackTrace();
			}
		} else {
			accountId = vendor.getStripeAccountId();
		}
		logger.info("PaymentServiceImpl createSession----ends----");
		return ResponseHelper.getSuccessResponse("Account Link done", map, 200, Constant.RESPONSE_SUCCESS);

	}

	
	
	@Override
	public Response getsubscription(String id) throws Exception {
		logger.info("PaymentServiceImpl getsubscription----starts----"+id);
		// TODO Auto-generated method stub
		Response res = new Response();
		try {
			User accessUser = userService.getUserByAccessToken();
			Stripe.apiKey = stripeApiKey;
			Map<String, String> output = new LinkedHashMap<String, String>();

//			Session session = Session.retrieve(id);
//			Vendor vendor = vendorRepository.findByUserUserId(accessUser.getUserId());
//			Map<String, String> output = new LinkedHashMap<String, String>();
//			if (vendor == null) {
//				throw new BusinessException(Constant.RESPONSE_FAIL, "Invalid Session Id",
//						Constant.RESPONSE_EMPTY_DATA, 1001);
//			}
//			if (session != null && session.getCustomer() !=null) {
//				//accountId = account.getId();
//				vendor.setStripeAccountId(session.getCustomer());
//				vendorRepository.save(vendor);
//			}
//			
			
			SessionCreateParams params =
					  SessionCreateParams.builder()
					    .addLineItem(
					      SessionCreateParams.LineItem.builder()
					        .setName("Kavholm rental")
					        .setAmount(1000L)
					        .setCurrency("usd")
					        .setQuantity(1L)
					        .build())
					    .setPaymentIntentData(
					      SessionCreateParams.PaymentIntentData.builder()
					        .setApplicationFeeAmount(123L)
					        .setTransferData(
					          SessionCreateParams.PaymentIntentData.TransferData.builder()
					            .setDestination("acct_1KvbR53dEnz5yoOZ")
					            .build())
					        .build())
					    .setMode(SessionCreateParams.Mode.PAYMENT)
					    .setSuccessUrl("https://example.com/success")
					    .setCancelUrl("https://example.com/cancel")
					    .build();

					Session session = Session.create(params);

			
			if(null!=session.getCustomer()) {
				logger.info("session.getSuccessUrl()---->" + session.getId());
				logger.info("session.getCustomer()---->" + session.getCustomer());
				logger.info("session.getSubscription()---->" + session.getSubscription());
				output.put("customerId", session.getCustomer());
				output.put("subscription", session.getSubscription());
				output.put("sessionId", session.getId());
				output.put("url", session.getUrl());
			}else {
				logger.info("session.getSuccessUrl()---->" + session.getId());
				logger.info("session.getCustomer()---->" + session.getCustomer());
				logger.info("session.getSubscription()---->" + session.getSubscription());
				output.put("customerId", "");
				output.put("subscription","" );
				output.put("sessionId", session.getId());
				output.put("url", session.getUrl());
			}
	
			res.setCode(200);
			res.setData(output);
			logger.info("session.getSuccessUrl()---->" + session.getSuccessUrl());
		} catch (CardException e) {
			e.printStackTrace();
		}
		logger.info("PaymentServiceImpl getsubscription----ends----");
		return res;
	}

	@Override
	public Response getplan() throws Exception {
		logger.info("PaymentServiceImpl getplan----starts----");
		// TODO Auto-generated method stub
		Response res = new Response();
		Stripe.apiKey = stripeApiKey;
		Map<String, Object> params = new HashMap<>();
		params.put("limit", 7);
		params.put("active", true);
		PlanCollection plans = Plan.list(params);	
		res.setCode(200);
		res.setData(plans.getData());
		logger.info("PaymentServiceImpl getplan----ends----");
		return res;
	}

}